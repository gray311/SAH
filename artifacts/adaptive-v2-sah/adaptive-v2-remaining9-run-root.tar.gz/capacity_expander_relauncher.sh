#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
CURRENT=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
LOG=$RUN/capacity_expander_relauncher.log
LOCK=$RUN/capacity_expander_relauncher.lock
POLL_SECONDS=30

exec 8>"$LOCK"
if ! flock -n 8; then
  printf '[%s] [capacity-relauncher] EXIT reason=already_running\n' "$(date -Is)" >> "$LOG"
  exit 0
fi
printf '%s\n' "$$" > "$RUN/capacity_expander_relauncher.pid"

log() {
  printf '[%s] [capacity-relauncher] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

audit_count() {
  local current_count run_count
  current_count=$(find "$CURRENT" -name v2_audit_complete.json 2>/dev/null | wc -l)
  run_count=$(find "$RUN" -name v2_audit_complete.json 2>/dev/null | wc -l)
  echo $((current_count + run_count))
}

read_live_pid() {
  local path=$1 pid
  [ -s "$path" ] || return 1
  pid=$(tr -d '[:space:]' < "$path")
  [[ "$pid" =~ ^[0-9]+$ ]] || return 1
  kill -0 "$pid" 2>/dev/null || return 1
  printf '%s\n' "$pid"
}

trap 'log "STOP signal=TERM mutation=none"; exit 143' TERM
trap 'log "STOP signal=INT mutation=none"; exit 130' INT
trap 'log "STOP signal=HUP mutation=none"; exit 129' HUP

log "START poll_seconds=$POLL_SECONDS policy=relaunch_expander_after_supervisor_recovery"
last_supervisor=
while true; do
  audits=$(audit_count)
  if [ "$audits" -eq 165 ]; then
    log "COMPLETE audited_rounds=165 action=exit_without_signaling"
    exit 0
  fi

  supervisor=$(read_live_pid "$RUN/recovery_supervisor.pid" || true)
  if [ -z "$supervisor" ]; then
    sleep "$POLL_SECONDS"
    continue
  fi
  if [ "$supervisor" != "$last_supervisor" ]; then
    log "OBSERVE supervisor_pid=$supervisor audited_rounds=$audits"
    last_supervisor=$supervisor
  fi

  expander=$(read_live_pid "$RUN/capacity_expander.pid" || true)
  if [ -z "$expander" ]; then
    log "RELAUNCH supervisor_pid=$supervisor action=start_capacity_expander"
    setsid bash "$RUN/capacity_expander.sh" >> "$RUN/capacity_expander.stdout.log" 2>&1 &
    launched=$!
    log "RELAUNCHED pid=$launched supervisor_pid=$supervisor"
    sleep 5
  fi
  sleep "$POLL_SECONDS"
done
