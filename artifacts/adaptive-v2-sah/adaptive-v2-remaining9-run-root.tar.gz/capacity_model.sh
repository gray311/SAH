#!/usr/bin/env bash
set -euo pipefail
umask 027

if [ "$#" -ne 3 ]; then
  echo "usage: $0 GPU PORT MANAGER_PID" >&2
  exit 2
fi

GPU=$1
PORT=$2
MANAGER_PID=$3
ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
export TMPDIR=$ROOT/.tmp_adaptive_v2
VLLM=/home/nli61/.conda/envs/vllm-serve/bin/vllm
MODEL=/data/models/Qwen3.5-9B
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
LOG=$RUN/capacity_gpu${GPU}_model.log
SERVER_LOG=$RUN/logs/vllm-capacity-gpu${GPU}.log
LIFECYCLE=$RUN/capacity_lifecycle.jsonl
READY=$RUN/capacity_gpu${GPU}.ready
SERVICE_PID=
OWNED_GPU_PIDS=
LAST_CO_OCCUPANTS=
EXIT_REASON=running
CLEANUP_STARTED=0

mkdir -p "$RUN/logs" "$TMPDIR"

log() {
  printf '[%s] [capacity-model-gpu%s] %s\n' "$(date -Is)" "$GPU" "$*" | tee -a "$LOG"
}

event() {
  "$PYTHON" - "$LIFECYCLE" "$@" <<'PY'
import datetime
import json
import sys
from pathlib import Path

path, name, *pairs = sys.argv[1:]
row = {"time": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "event": name}
for pair in pairs:
    key, raw = pair.split("=", 1)
    try:
        row[key] = json.loads(raw)
    except Exception:
        row[key] = raw
with Path(path).open("a") as handle:
    handle.write(json.dumps(row) + "\n")
PY
}

gpu_pids() {
  nvidia-smi -i "$GPU" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null \
    | sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p'
}

assert_gpu_free() {
  local occupants
  occupants=$(gpu_pids || true)
  if [ -n "$occupants" ]; then
    log "REFUSE gpu_not_free pids=${occupants//$'\n'/,}"
    event capacity_model_start_refused "gpu=$GPU" "port=$PORT" \
      "reason=gpu_not_free" "pids=${occupants//$'\n'/,}"
    return 1
  fi
}

assert_port_free() {
  "$PYTHON" - "$PORT" <<'PY'
import socket
import sys

sock = socket.socket()
try:
    sock.bind(("127.0.0.1", int(sys.argv[1])))
finally:
    sock.close()
PY
}

pid_descends_from() {
  local candidate=$1 ancestor=$2 parent
  for _ in $(seq 1 64); do
    [ "$candidate" = "$ancestor" ] && return 0
    [[ "$candidate" =~ ^[1-9][0-9]*$ ]] || return 1
    [ "$candidate" -gt 1 ] || return 1
    parent=$(ps -o ppid= -p "$candidate" 2>/dev/null | tr -d ' ')
    [[ "$parent" =~ ^[1-9][0-9]*$ ]] || return 1
    [ "$parent" != "$candidate" ] || return 1
    candidate=$parent
  done
  return 1
}

verify_gpu_ownership() {
  local pid owner co_occupants=
  while read -r pid; do
    [ -n "$pid" ] || continue
    owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
    if [ "$owner" = "nli61" ] && pid_descends_from "$pid" "$SERVICE_PID"; then
      case ";$OWNED_GPU_PIDS;" in
        *";$pid;"*) ;;
        *) OWNED_GPU_PIDS="${OWNED_GPU_PIDS}${OWNED_GPU_PIDS:+;}${pid}" ;;
      esac
      continue
    fi
    co_occupants="${co_occupants}${pid}:${owner};"
  done < <(gpu_pids)
  if [ "$co_occupants" != "$LAST_CO_OCCUPANTS" ]; then
    if [ -n "$co_occupants" ]; then
      log "COOCCUPANCY occupants=$co_occupants action=continue_own_run_untouched"
      event capacity_gpu_cooccupancy "gpu=$GPU" "port=$PORT" \
        "occupants=$co_occupants" "action=continue_own_run_untouched"
    elif [ -n "$LAST_CO_OCCUPANTS" ]; then
      log "COOCCUPANCY CLEARED"
      event capacity_gpu_cooccupancy_cleared "gpu=$GPU" "port=$PORT"
    fi
    LAST_CO_OCCUPANTS=$co_occupants
  fi
}

stop_service() {
  [ -n "$SERVICE_PID" ] || return 0
  kill -0 "$SERVICE_PID" 2>/dev/null || return 0
  kill -TERM -- "-$SERVICE_PID" 2>/dev/null || kill -TERM "$SERVICE_PID" 2>/dev/null || true
  for _ in $(seq 1 30); do
    kill -0 "$SERVICE_PID" 2>/dev/null || return 0
    sleep 1
  done
  log "ESCALATE owned_service pid=$SERVICE_PID"
  kill -KILL -- "-$SERVICE_PID" 2>/dev/null || kill -KILL "$SERVICE_PID" 2>/dev/null || true
}

cleanup() {
  local code=$? pid owned_remaining=
  [ "$CLEANUP_STARTED" -eq 0 ] || exit "$code"
  CLEANUP_STARTED=1
  trap - EXIT INT TERM HUP
  rm -f "$READY"
  event capacity_model_stop_requested "gpu=$GPU" "port=$PORT" \
    "pid=${SERVICE_PID:-}" "reason=$EXIT_REASON"
  stop_service
  sleep 3
  IFS=';' read -r -a owned_array <<< "$OWNED_GPU_PIDS"
  for pid in "${owned_array[@]:-}"; do
    [ -n "$pid" ] || continue
    kill -0 "$pid" 2>/dev/null && owned_remaining="${owned_remaining}${pid};"
  done
  if [ -n "$owned_remaining" ]; then
    event capacity_model_cleanup_incomplete "gpu=$GPU" "remaining=$owned_remaining"
    log "CLEANUP INCOMPLETE owned_remaining=$owned_remaining"
    exit 5
  fi
  event capacity_model_exit "gpu=$GPU" "port=$PORT" "exit_code=$code" \
    "reason=$EXIT_REASON" "gpu_cleanup=true"
  log "EXIT code=$code reason=$EXIT_REASON gpu_cleanup=true"
  exit "$code"
}

trap cleanup EXIT
trap 'EXIT_REASON=terminated; exit 143' TERM
trap 'EXIT_REASON=interrupted; exit 130' INT
trap 'EXIT_REASON=hup; exit 129' HUP

assert_gpu_free || { EXIT_REASON=gpu_not_free; exit 4; }
assert_port_free || { EXIT_REASON=port_not_free; exit 4; }
event capacity_model_start "gpu=$GPU" "port=$PORT" "manager_pid=$MANAGER_PID" \
  "startup_gpu_empty=true" "late_gpu_cooccupancy_policy=continue_own_run_untouched"
log "START Qwen3.5-9B gpu=$GPU port=$PORT"

setsid env \
  CUDA_VISIBLE_DEVICES="$GPU" \
  TMPDIR="$TMPDIR" \
  VLLM_USE_FLASHINFER_SAMPLER=0 \
  HF_HOME="$ROOT/.hf_cache" \
  "$VLLM" serve "$MODEL" \
  --host 127.0.0.1 \
  --port "$PORT" \
  --served-model-name Qwen3.5-9B \
  --max-model-len 131072 \
  --max-num-seqs 8 \
  --max-num-batched-tokens 16384 \
  --gpu-memory-utilization 0.65 \
  --enforce-eager \
  --language-model-only \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_xml \
  >> "$SERVER_LOG" 2>&1 &
SERVICE_PID=$!
event capacity_vllm_start "gpu=$GPU" "port=$PORT" "pid=$SERVICE_PID"

ready=0
for _ in $(seq 1 300); do
  # Record any process that arrives after the empty-GPU startup gate even
  # while vLLM is still loading.  This is evidence-only: late co-occupancy
  # never causes a voluntary yield and foreign processes are never signaled.
  verify_gpu_ownership
  if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
    EXIT_REASON=vllm_startup_failure
    exit 6
  fi
  if "$PYTHON" - "$PORT" >/dev/null 2>&1 <<'PY'
import json
import sys
import urllib.request

with urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/v1/models", timeout=2) as response:
    payload = json.load(response)
assert payload.get("data"), payload
PY
  then
    ready=1
    break
  fi
  sleep 2
done
[ "$ready" -eq 1 ] || { EXIT_REASON=vllm_startup_timeout; exit 7; }
verify_gpu_ownership
printf '%s\n' "$(date -Is)" > "$READY"
event capacity_vllm_ready "gpu=$GPU" "port=$PORT" "pid=$SERVICE_PID"
log "READY pid=$SERVICE_PID"

while true; do
  if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
    EXIT_REASON=vllm_died
    exit 8
  fi
  if ! kill -0 "$MANAGER_PID" 2>/dev/null; then
    EXIT_REASON=manager_exit
    exit 0
  fi
  verify_gpu_ownership
  sleep 30
done
