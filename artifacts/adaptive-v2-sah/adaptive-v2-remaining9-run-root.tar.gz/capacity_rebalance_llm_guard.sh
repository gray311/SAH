#!/usr/bin/env bash
set -euo pipefail

RUN=/home/nli61/workspace/harness_train/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
LOCK=$RUN/task_locks/adrs__llm_sql.lock
RELEASE=$RUN/capacity_rebalance_llm.release
LOG=$RUN/capacity_rebalance_llm_guard.log

mkdir -p "$RUN/task_locks"
exec 9>"$LOCK"
flock -x 9
printf '[%s] ACQUIRED lock=%s pid=%s reason=preserve_transaction_during_endpoint_rebalance\n' \
  "$(date -Is)" "$LOCK" "$$" >> "$LOG"
while [ ! -e "$RELEASE" ]; do
  sleep 1
done
printf '[%s] RELEASED lock=%s pid=%s reason=ahc058_and_transaction_balanced\n' \
  "$(date -Is)" "$LOCK" "$$" >> "$LOG"
