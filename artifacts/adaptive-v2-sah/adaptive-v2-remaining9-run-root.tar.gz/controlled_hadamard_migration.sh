#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
LOG=$RUN/controlled_hadamard_migration.log
LIFECYCLE=$RUN/controlled_hadamard_migration.jsonl
CAPACITY_LIFECYCLE=$RUN/capacity_lifecycle.jsonl
FIRST_MIGRATION=$RUN/controlled_lane_migration.jsonl
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
HAD_LANE_PID=413547
HAD_AUDIT=$RUN/tasks/eft__math__hadamard_maximal_det/campaign/round012/v2_audit_complete.json
AHC058_LOCK=$RUN/task_locks/eft__ahc_simpletes__ahc058.lock
TXN_LOCK=$RUN/task_locks/adrs__txn_scheduling.lock

log() {
  printf '[%s] [controlled-hadamard-migration] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

event() {
  "$PYTHON" - "$LIFECYCLE" "$@" <<'PY'
import datetime
import json
import sys
from pathlib import Path

path, name, *pairs = sys.argv[1:]
row = {"time": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "event": name}
for pair in pairs:
    key, raw = pair.split("=", 1)
    try:
        row[key] = json.loads(raw)
    except Exception:
        row[key] = raw
with Path(path).open("a") as handle:
    handle.write(json.dumps(row) + "\n")
PY
}

verify_lane() {
  local owner cmd pgid sid
  owner=$(ps -o user= -p "$HAD_LANE_PID" 2>/dev/null | tr -d ' ')
  cmd=$(ps -o cmd= -p "$HAD_LANE_PID" 2>/dev/null || true)
  pgid=$(ps -o pgid= -p "$HAD_LANE_PID" 2>/dev/null | tr -d ' ')
  sid=$(ps -o sid= -p "$HAD_LANE_PID" 2>/dev/null | tr -d ' ')
  [ "$owner" = "nli61" ] || return 1
  [ "$pgid" = "$HAD_LANE_PID" ] || return 1
  [ "$sid" = "$HAD_LANE_PID" ] || return 1
  [[ "$cmd" == *"run_lane.sh recovery_hadamard_transaction 8822 2"* ]]
}

log "START wait_for_first_takeover_and_hadamard_r12_audit target=third_capacity_endpoint domain_cap=4"
event migration_wait_start "hadamard_lane_pid=$HAD_LANE_PID" \
  "condition=first_capacity_takeover_confirmed_and_hadamard_round012_audited"

while true; do
  first_done=$(grep -c '"event": "capacity_takeover_confirmed"' "$FIRST_MIGRATION" 2>/dev/null || true)
  if [ "$first_done" -gt 0 ] && [ -e "$HAD_AUDIT" ]; then
    break
  fi
  if ! kill -0 "$HAD_LANE_PID" 2>/dev/null; then
    log "EXIT hadamard_lane_disappeared_before_migration artifacts_preserved=true"
    event migration_cancelled "reason=hadamard_lane_disappeared" "artifacts_preserved=true"
    exit 4
  fi
  sleep 5
done

verify_lane || {
  log "EXIT hadamard_lane_ownership_verification_failed pid=$HAD_LANE_PID"
  event migration_cancelled "reason=hadamard_lane_ownership_verification_failed"
  exit 5
}

mkdir -p "$RUN/task_locks"
exec 8>"$AHC058_LOCK"
exec 7>"$TXN_LOCK"
flock -n 8 || {
  log "EXIT ahc058_migration_guard_lock_unavailable"
  event migration_cancelled "reason=ahc058_guard_lock_unavailable"
  exit 6
}
flock -n 7 || {
  log "EXIT transaction_migration_guard_lock_unavailable"
  event migration_cancelled "reason=transaction_guard_lock_unavailable"
  exit 7
}

log "MIGRATE signal=TERM hadamard_lane=$HAD_LANE_PID completed_artifacts_preserved=true"
event migration_signal "signal=TERM" "hadamard_lane_pid=$HAD_LANE_PID" \
  "completed_artifacts_preserved=true" "resume=true"
kill -TERM -- "-$HAD_LANE_PID"

for _ in $(seq 1 30); do
  if ! kill -0 "$HAD_LANE_PID" 2>/dev/null; then
    event old_lane_stopped "hadamard_lane_pid=$HAD_LANE_PID"
    old_lane_gone=1
    break
  fi
  sleep 1
done
if [ "${old_lane_gone:-0}" -ne 1 ]; then
  log "EXIT old_lane_shutdown_timeout no_kill_escalation=true"
  event migration_incomplete "reason=old_lane_shutdown_timeout" "kill_escalation=false"
  exit 8
fi

for _ in $(seq 1 30); do
  had_started=$(grep -c '"event": "capacity_task_start".*"task_id": "eft__math__hadamard_maximal_det"' "$CAPACITY_LIFECYCLE" || true)
  if [ "$had_started" -gt 0 ]; then
    log "STOP capacity_takeover=true hadamard=true guard_locks_released=true"
    event capacity_takeover_confirmed "hadamard=true" "guard_locks_released=true"
    exit 0
  fi
  sleep 5
done

log "EXIT capacity_takeover_timeout guard_locks_released=true artifacts_preserved=true"
event migration_incomplete "reason=capacity_takeover_timeout" "guard_locks_released=true"
exit 9
