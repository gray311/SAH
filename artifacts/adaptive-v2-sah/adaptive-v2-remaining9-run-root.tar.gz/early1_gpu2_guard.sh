#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
CURRENT_RUN=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
PORT=8824
GPU=2
LOG=$RUN/early1_gpu2_guard.log
CURRENT_PID=$(tr -d '[:space:]' < "$CURRENT_RUN/supervisor.pid")
VLLM_GUARD_PID=$(tr -d '[:space:]' < "$RUN/gpu2_vllm_guard.pid")
LANE_PID=
RESTARTS=0

printf '%s\n' "$$" > "$RUN/early1_gpu2_guard.pid"

log() {
  printf '[%s] [early1-gpu2-guard] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

stop_lane() {
  [ -n "$LANE_PID" ] || return 0
  if kill -0 "$LANE_PID" 2>/dev/null; then
    log "STOP lane pid=$LANE_PID reason=cp26_transition"
    kill -TERM -- "-$LANE_PID" 2>/dev/null || kill -TERM "$LANE_PID" 2>/dev/null || true
    for _ in $(seq 1 30); do
      kill -0 "$LANE_PID" 2>/dev/null || break
      sleep 1
    done
    if kill -0 "$LANE_PID" 2>/dev/null; then
      log "ESCALATE lane pid=$LANE_PID"
      kill -KILL -- "-$LANE_PID" 2>/dev/null || kill -KILL "$LANE_PID" 2>/dev/null || true
    fi
  fi
  wait "$LANE_PID" 2>/dev/null || true
  LANE_PID=
}

cp26_complete() {
  "$PYTHON" - "$CURRENT_RUN" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1]) / "cp26/final_status.json"
if not path.exists():
    raise SystemExit(1)
status = json.loads(path.read_text())
if status.get("collected_rounds") != list(range(15)):
    raise SystemExit(1)
if status.get("pending_training") is not None or int(status.get("policy_updates", 0)) != 0:
    raise SystemExit(1)
PY
}

service_ready() {
  kill -0 "$VLLM_GUARD_PID" 2>/dev/null && "$PYTHON" - "$PORT" >/dev/null 2>&1 <<'PY'
import json
import sys
import urllib.request

with urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/v1/models", timeout=3) as response:
    payload = json.load(response)
assert payload.get("data"), payload
PY
}

launch_lane() {
  service_ready
  log "START AC2/EPLB lane gpu=$GPU port=$PORT restart=$RESTARTS"
  setsid bash "$RUN/run_lane.sh" early1_gpu2 "$PORT" "$GPU" \
    eft__math__second_autocorr_ineq \
    adrs__eplb \
    >> "$RUN/early1_gpu2.worker.log" 2>&1 &
  LANE_PID=$!
  log "LANE pid=$LANE_PID"
}

trap 'stop_lane' EXIT
trap 'stop_lane; exit 143' TERM
trap 'stop_lane; exit 130' INT
trap 'stop_lane; exit 129' HUP

launch_lane
while true; do
  if cp26_complete; then
    log "CP-26 final status detected; preserve GPU2 lane artifacts"
    stop_lane
    trap - EXIT INT TERM HUP
    exit 0
  fi
  if ! kill -0 "$CURRENT_PID" 2>/dev/null; then
    log "current supervisor exited; preserve GPU2 lane artifacts"
    stop_lane
    trap - EXIT INT TERM HUP
    exit 0
  fi
  if ! service_ready; then
    log "STOP GPU2 vLLM service unavailable"
    stop_lane
    trap - EXIT INT TERM HUP
    exit 8
  fi
  if ! kill -0 "$LANE_PID" 2>/dev/null; then
    set +e
    wait "$LANE_PID"
    status=$?
    set -e
    if [ "$status" -eq 0 ]; then
      log "COMPLETE AC2/EPLB GPU2 queue"
      LANE_PID=
      trap - EXIT INT TERM HUP
      exit 0
    fi
    RESTARTS=$((RESTARTS + 1))
    log "lane exited status=$status restart=$RESTARTS"
    if [ "$RESTARTS" -gt 3 ]; then
      log "STOP restart budget exhausted; formal remaining campaign will resume"
      LANE_PID=
      trap - EXIT INT TERM HUP
      exit "$status"
    fi
    launch_lane
  fi
  sleep 5
done
