#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
CURRENT_RUN=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
LOG=$RUN/follow_on.log
EARLY_PIDS=()

mkdir -p "$RUN"
printf '%s\n' "$$" > "$RUN/follow_on.pid"

log() {
  printf '[%s] [follow-on] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

stop_early_lanes() {
  local pid
  for pid in "${EARLY_PIDS[@]:-}"; do
    [ -n "$pid" ] || continue
    if kill -0 "$pid" 2>/dev/null; then
      log "STOP early lane pid=$pid reason=current_campaign_transition"
      kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
      for _ in $(seq 1 30); do
        kill -0 "$pid" 2>/dev/null || break
        sleep 1
      done
      if kill -0 "$pid" 2>/dev/null; then
        log "ESCALATE early lane pid=$pid"
        kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
      fi
    fi
    wait "$pid" 2>/dev/null || true
  done
  EARLY_PIDS=()
}

wait_guard_exit() {
  local pid_file=$1 label=$2 expected=$3 pid cmdline
  if [ ! -f "$pid_file" ]; then
    log "GUARD CLEAN label=$label state=pid_file_absent"
    return 0
  fi
  pid=$(tr -d '[:space:]' < "$pid_file")
  for _ in $(seq 1 90); do
    cmdline=$(ps -o cmd= -p "$pid" 2>/dev/null || true)
    if ! kill -0 "$pid" 2>/dev/null || [[ "$cmdline" != *"$expected"* ]]; then
      log "GUARD CLEAN label=$label pid=$pid"
      return 0
    fi
    sleep 1
  done
  log "FATAL guard did not exit label=$label pid=$pid expected=$expected"
  return 1
}

trap 'stop_early_lanes' EXIT
trap 'stop_early_lanes; exit 143' TERM
trap 'stop_early_lanes; exit 130' INT
trap 'stop_early_lanes; exit 129' HUP

CURRENT_PID=$(tr -d '[:space:]' < "$CURRENT_RUN/supervisor.pid")
log "WAIT current campaign pid=$CURRENT_PID"
EARLY_STARTED=0
while kill -0 "$CURRENT_PID" 2>/dev/null; do
  if [ "$EARLY_STARTED" -eq 0 ] && "$PYTHON" - <<'PY'
import json
import urllib.request

with urllib.request.urlopen("http://127.0.0.1:8823/v1/models", timeout=3) as response:
    payload = json.load(response)
assert payload.get("data"), payload
PY
  then
    EARLY_STARTED=1
    log "START early GPU1 lanes alongside PRISM; total active domains=4"
    setsid bash "$RUN/run_lane.sh" early0 8823 1 \
      eft__math__erdos_min_overlap \
      eft__ahc_simpletes__ahc039 \
      adrs__llm_sql \
      > "$RUN/early0.worker.log" 2>&1 &
    EARLY_PIDS+=("$!")
    setsid bash "$RUN/run_lane.sh" early1 8823 1 \
      eft__math__second_autocorr_ineq \
      adrs__eplb \
      > "$RUN/early1.worker.log" 2>&1 &
    EARLY_PIDS+=("$!")
    log "EARLY lanes pids=${EARLY_PIDS[*]} port=8823 gpu=1"
  fi
  if [ "$EARLY_STARTED" -eq 1 ] && "$PYTHON" - "$CURRENT_RUN" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1]) / "cp26/final_status.json"
if not path.exists():
    raise SystemExit(1)
status = json.loads(path.read_text())
if status.get("collected_rounds") != list(range(15)):
    raise SystemExit(1)
PY
  then
    log "CP-26 final status detected; preserve early-lane artifacts before model cleanup"
    stop_early_lanes
    EARLY_STARTED=2
  fi
  if [ "$EARLY_STARTED" -eq 1 ]; then
    sleep 5
  else
    sleep 30
  fi
done

stop_early_lanes
log "VALIDATE current campaign completed and cleaned GPUs"
"$PYTHON" - "$CURRENT_RUN" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
for shard in ("cp26", "prism"):
    status_path = root / shard / "final_status.json"
    assert status_path.exists(), status_path
    status = json.loads(status_path.read_text())
    assert status.get("collected_rounds") == list(range(15)), status
    assert status.get("pending_training") is None, status
    assert int(status.get("policy_updates", 0)) == 0, status
events = [json.loads(line) for line in (root / "lifecycle.jsonl").read_text().splitlines() if line.strip()]
exits = [row for row in events if row.get("event") == "campaign_exit"]
assert exits, "campaign_exit missing"
last = exits[-1]
assert last.get("reason") == "completed", last
assert last.get("gpu_cleanup") is True, last
PY

log "WAIT auxiliary early-lane/model guards before reusing GPU2"
wait_guard_exit "$RUN/early2_guard.pid" early2 early2_guard.sh
wait_guard_exit "$RUN/early1_gpu2_guard.pid" early1_gpu2 early1_gpu2_guard.sh
wait_guard_exit "$RUN/gpu2_vllm_guard.pid" gpu2_vllm gpu2_vllm_guard.sh

log "START remaining-nine campaign"
trap - EXIT INT TERM HUP
exec bash "$RUN/run.sh"
