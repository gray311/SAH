#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
CURRENT_RUN=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
VLLM=/home/nli61/.conda/envs/vllm-serve/bin/vllm
MODEL=/data/models/Qwen3.5-9B
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
PORT=${PORT_OVERRIDE:-8824}
GPU=${GPU_OVERRIDE:-2}
GUARD_TAG=${GUARD_TAG:-gpu2}
LOG=$RUN/${GUARD_TAG}_vllm_guard.log
SERVER_LOG=$RUN/logs/vllm-${GUARD_TAG}-extra.log
LIFECYCLE=$RUN/${GUARD_TAG}_lifecycle.jsonl
CURRENT_PID=$(tr -d '[:space:]' < "$CURRENT_RUN/supervisor.pid")
SERVICE_PID=
EXIT_REASON=running
CLEANUP_STARTED=0

mkdir -p "$RUN/logs"
printf '%s\n' "$$" > "$RUN/${GUARD_TAG}_vllm_guard.pid"

log() {
  printf '[%s] [%s-vllm-guard] %s\n' "$(date -Is)" "$GUARD_TAG" "$*" | tee -a "$LOG"
}

event() {
  "$PYTHON" - "$LIFECYCLE" "$@" <<'PY'
import datetime
import json
import sys
from pathlib import Path

path, name, *pairs = sys.argv[1:]
row = {"time": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "event": name}
for pair in pairs:
    key, raw = pair.split("=", 1)
    try:
        row[key] = json.loads(raw)
    except Exception:
        row[key] = raw
with Path(path).open("a") as handle:
    handle.write(json.dumps(row) + "\n")
PY
}

gpu_pids() {
  nvidia-smi -i "$GPU" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null \
    | sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p'
}

assert_gpu_free() {
  local occupants
  occupants=$(gpu_pids || true)
  if [ -n "$occupants" ]; then
    log "GPU occupied before startup pids=${occupants//$'\n'/,}"
    event startup_refused "reason=gpu_not_free" "pids=${occupants//$'\n'/,}"
    return 1
  fi
}

assert_port_free() {
  "$PYTHON" - "$PORT" <<'PY'
import socket
import sys

sock = socket.socket()
try:
    sock.bind(("127.0.0.1", int(sys.argv[1])))
finally:
    sock.close()
PY
}

stop_service() {
  [ -n "$SERVICE_PID" ] || return 0
  kill -0 "$SERVICE_PID" 2>/dev/null || return 0
  kill -TERM -- "-$SERVICE_PID" 2>/dev/null || kill -TERM "$SERVICE_PID" 2>/dev/null || true
  for _ in $(seq 1 30); do
    kill -0 "$SERVICE_PID" 2>/dev/null || return 0
    sleep 1
  done
  log "ESCALATE service pid=$SERVICE_PID"
  kill -KILL -- "-$SERVICE_PID" 2>/dev/null || kill -KILL "$SERVICE_PID" 2>/dev/null || true
}

cleanup() {
  local code=$? owned_remaining= pid owner
  [ "$CLEANUP_STARTED" -eq 0 ] || exit "$code"
  CLEANUP_STARTED=1
  trap - EXIT INT TERM HUP
  event vllm_stop_requested "pid=${SERVICE_PID:-}" "gpu=$GPU" "port=$PORT" "reason=$EXIT_REASON"
  stop_service
  sleep 3
  while read -r pid; do
    [ -n "$pid" ] || continue
    owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
    if [ "$owner" = "nli61" ]; then
      owned_remaining="${owned_remaining}${pid};"
    fi
  done < <(gpu_pids)
  if [ -n "$owned_remaining" ]; then
    event gpu_cleanup_incomplete "remaining=$owned_remaining" "reason=$EXIT_REASON"
    log "GPU cleanup incomplete remaining=$owned_remaining"
    exit 5
  fi
  event campaign_exit "exit_code=$code" "reason=$EXIT_REASON" "gpu_cleanup=true"
  log "EXIT code=$code reason=$EXIT_REASON gpu_cleanup=true"
  exit "$code"
}

trap cleanup EXIT
trap 'EXIT_REASON=terminated; exit 143' TERM
trap 'EXIT_REASON=interrupted; exit 130' INT
trap 'EXIT_REASON=hup; exit 129' HUP

assert_gpu_free || { EXIT_REASON=gpu_not_free; exit 4; }
assert_port_free || { EXIT_REASON=port_not_free; exit 4; }
event campaign_start "pid=$$" "gpu=$GPU" "port=$PORT" "model=Qwen3.5-9B" "reason=authorized_free_gpu_acceleration"
log "START vLLM gpu=$GPU port=$PORT model=Qwen3.5-9B"
setsid env \
  CUDA_VISIBLE_DEVICES="$GPU" \
  VLLM_USE_FLASHINFER_SAMPLER=0 \
  HF_HOME="$ROOT/.hf_cache" \
  "$VLLM" serve "$MODEL" \
  --host 127.0.0.1 \
  --port "$PORT" \
  --served-model-name Qwen3.5-9B \
  --max-model-len 131072 \
  --max-num-seqs 8 \
  --max-num-batched-tokens 16384 \
  --gpu-memory-utilization 0.65 \
  --enforce-eager \
  --language-model-only \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_xml \
  >> "$SERVER_LOG" 2>&1 &
SERVICE_PID=$!
printf '%s\n' "$SERVICE_PID" > "$RUN/${GUARD_TAG}_vllm_service.pid"
event vllm_start "pid=$SERVICE_PID" "gpu=$GPU" "port=$PORT"

ready=0
for _ in $(seq 1 300); do
  if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
    EXIT_REASON=vllm_startup_failure
    log "vLLM died during startup pid=$SERVICE_PID"
    tail -100 "$SERVER_LOG" || true
    exit 6
  fi
  if "$PYTHON" - "$PORT" >/dev/null 2>&1 <<'PY'
import json
import sys
import urllib.request

with urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/v1/models", timeout=2) as response:
    payload = json.load(response)
assert payload.get("data"), payload
PY
  then
    ready=1
    break
  fi
  sleep 2
done
[ "$ready" -eq 1 ] || { EXIT_REASON=vllm_startup_timeout; exit 7; }
event vllm_ready "pid=$SERVICE_PID" "gpu=$GPU" "port=$PORT"
printf '%s\n' "$(date -Is)" > "$RUN/${GUARD_TAG}_vllm.ready"
log "READY vLLM pid=$SERVICE_PID gpu=$GPU port=$PORT"

while kill -0 "$CURRENT_PID" 2>/dev/null; do
  if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
    EXIT_REASON=vllm_died
    exit 8
  fi
  if [ -e "$CURRENT_RUN/cp26/final_status.json" ] && "$PYTHON" - "$CURRENT_RUN/cp26/final_status.json" <<'PY'
import json
import sys

status = json.load(open(sys.argv[1]))
assert status.get("collected_rounds") == list(range(15))
assert status.get("pending_training") is None
assert int(status.get("policy_updates", 0)) == 0
PY
  then
    EXIT_REASON=cp26_transition
    exit 0
  fi
  sleep 15
done

EXIT_REASON=current_supervisor_exit
