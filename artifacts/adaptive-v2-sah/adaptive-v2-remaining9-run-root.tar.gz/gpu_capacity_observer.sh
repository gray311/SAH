#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
CURRENT=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
LOG=$RUN/gpu_capacity_observer.log
STATE=$RUN/gpu_capacity_state.json
LAST_SNAPSHOT=

printf '%s\n' "$$" > "$RUN/gpu_capacity_observer.pid"

log() {
  printf '[%s] [gpu-capacity-observer] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

gpu_pids() {
  local gpu=$1
  nvidia-smi -i "$gpu" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null \
    | sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p'
}

audit_count() {
  local current_count run_count
  current_count=$(find "$CURRENT" -name v2_audit_complete.json 2>/dev/null | wc -l)
  run_count=$(find "$RUN" -name v2_audit_complete.json 2>/dev/null | wc -l)
  echo $((current_count + run_count))
}

write_state() {
  local audits=$1 snapshot=$2 free_csv=$3
  "$PYTHON" - "$STATE" "$audits" "$snapshot" "$free_csv" <<'PY'
import datetime
import json
import os
import sys
from pathlib import Path

target, audits, snapshot, free_csv = sys.argv[1:]
payload = {
    "schema": "sah.gpu-capacity-observer/1",
    "time": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
    "audited_rounds": int(audits),
    "free_gpus": [int(item) for item in free_csv.split(",") if item],
    "snapshot": snapshot,
    "action": "observe_only_preserve_four_domain_cap",
}
path = Path(target)
temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
temporary.write_text(json.dumps(payload, indent=2))
temporary.replace(path)
PY
}

trap 'log "STOP signal=TERM read_only=true"; exit 143' TERM
trap 'log "STOP signal=INT read_only=true"; exit 130' INT
trap 'log "STOP signal=HUP read_only=true"; exit 129' HUP

log "START poll_seconds=30 read_only=true four_domain_cap=true"
while true; do
  audits=$(audit_count)
  snapshot= free_csv=
  for gpu in 0 1 2 3; do
    occupants=$(gpu_pids "$gpu" || true)
    if [ -z "$occupants" ]; then
      snapshot="${snapshot}gpu${gpu}=free;"
      free_csv="${free_csv}${free_csv:+,}${gpu}"
      continue
    fi
    owners=
    while read -r pid; do
      [ -n "$pid" ] || continue
      owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
      owners="${owners}${pid}:${owner};"
    done <<< "$occupants"
    snapshot="${snapshot}gpu${gpu}=${owners};"
  done
  if [ "$snapshot" != "$LAST_SNAPSHOT" ]; then
    log "OBSERVE audits=$audits $snapshot action=occupied_processes_untouched"
    LAST_SNAPSHOT=$snapshot
  fi
  write_state "$audits" "$snapshot" "$free_csv"
  if [ "$audits" -eq 165 ]; then
    log "COMPLETE audits=165 read_only=true"
    exit 0
  fi
  sleep 30
done
