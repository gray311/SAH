#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
LOG=$RUN/health_snapshotter.log

printf '%s\n' "$$" > "$RUN/health_snapshotter.pid"

log() {
  printf '[%s] [health-snapshotter] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

trap 'log "STOP signal=TERM read_only=true"; exit 143' TERM
trap 'log "STOP signal=INT read_only=true"; exit 130' INT
trap 'log "STOP signal=HUP read_only=true"; exit 129' HUP

log "START interval_seconds=1800 read_only=true"
while true; do
  if "$PYTHON" "$RUN/health_snapshot.py" >> "$LOG" 2>&1; then
    decision=$("$PYTHON" - "$RUN/health_latest.json" <<'PY'
import json
import sys
print(json.load(open(sys.argv[1])).get("decision", "unknown"))
PY
)
    log "SNAPSHOT decision=$decision"
  else
    log "SNAPSHOT ERROR artifacts_preserved=true"
  fi
  audits=$(find "$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059" \
    "$RUN" -name v2_audit_complete.json 2>/dev/null | wc -l)
  if [ "$audits" -eq 165 ]; then
    log "COMPLETE audits=165 read_only=true"
    exit 0
  fi
  sleep 1800
done
