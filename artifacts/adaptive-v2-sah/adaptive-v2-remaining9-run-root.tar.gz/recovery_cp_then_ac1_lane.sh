#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
CURRENT=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
PORT=${PORT_OVERRIDE:-8822}
GPU=${GPU_OVERRIDE:-0}

bash "$CURRENT/run_shard.sh" cp26 "$PORT" eft__math__circle_packing
bash "$RUN/run_lane.sh" recovery_ac1_ahc058 "$PORT" "$GPU" \
  eft__math__first_autocorr_ineq \
  eft__ahc_simpletes__ahc058
