#!/usr/bin/env bash
set -euo pipefail
umask 027
export PYTHONDONTWRITEBYTECODE=1

ROOT=/home/nli61/workspace/harness_train
CURRENT=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
VLLM=/home/nli61/.conda/envs/vllm-serve/bin/vllm
MODEL=/data/models/Qwen3.5-9B
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
GPU=${GPU_OVERRIDE:-0}
PORT=${PORT_OVERRIDE:-8822}
ALLOW_EXISTING_OCCUPANTS=${ALLOW_EXISTING_OCCUPANTS:-0}
GPU_MEMORY_UTILIZATION=${GPU_MEMORY_UTILIZATION:-0.65}
LOG=$RUN/recovery_supervisor.log
SERVER_LOG=$RUN/logs/vllm-gpu0-recovery.log
LIFECYCLE=$RUN/recovery_lifecycle.jsonl
SERVICE_PID=
LANE_PIDS=()
LANE_NAMES=(cp_then_ac1 ahc039_then_sql ac2_then_eplb hadamard_then_transaction)
EXIT_REASON=running
CLEANUP_STARTED=0
LAST_CO_OCCUPANTS=

export TMPDIR=$ROOT/.tmp_adaptive_v2
mkdir -p "$RUN/logs" "$RUN/snapshots" "$RUN/.matplotlib" "$TMPDIR"
printf '%s\n' "$$" > "$RUN/recovery_supervisor.pid"

log() {
  printf '[%s] [recovery-gpu0] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

event() {
  "$PYTHON" - "$LIFECYCLE" "$@" <<'PY'
import datetime
import json
import sys
from pathlib import Path

path, name, *pairs = sys.argv[1:]
row = {"time": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "event": name}
for pair in pairs:
    key, raw = pair.split("=", 1)
    try:
        row[key] = json.loads(raw)
    except Exception:
        row[key] = raw
with Path(path).open("a") as handle:
    handle.write(json.dumps(row) + "\n")
PY
}

snapshot() {
  local label=$1
  nvidia-smi --query-gpu=index,uuid,memory.used,memory.free,utilization.gpu \
    --format=csv,noheader > "$RUN/snapshots/recovery_gpu_${label}.txt" 2>&1 || true
  nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name,used_memory \
    --format=csv,noheader > "$RUN/snapshots/recovery_processes_${label}.txt" 2>&1 || true
}

gpu_pids() {
  nvidia-smi -i "$GPU" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null \
    | sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p'
}

assert_gpu_free() {
  local occupants
  occupants=$(gpu_pids || true)
  if [ -n "$occupants" ]; then
    if [ "$ALLOW_EXISTING_OCCUPANTS" = "1" ]; then
      log "GPU occupied at authorized model-replacement startup gpu=$GPU pids=${occupants//$'\n'/,} action=continue_without_signaling"
      event startup_cooccupancy_authorized "reason=model_replacement" "gpu=$GPU" \
        "pids=${occupants//$'\n'/,}" "action=continue_without_signaling"
      return 0
    fi
    log "GPU occupied before recovery startup gpu=$GPU pids=${occupants//$'\n'/,}"
    event startup_refused "reason=gpu_not_free" "gpu=$GPU" "pids=${occupants//$'\n'/,}"
    return 1
  fi
}

assert_port_free() {
  "$PYTHON" - "$PORT" <<'PY'
import socket
import sys

sock = socket.socket()
try:
    sock.bind(("127.0.0.1", int(sys.argv[1])))
finally:
    sock.close()
PY
}

pid_descends_from() {
  local candidate=$1 ancestor=$2 parent
  for _ in $(seq 1 64); do
    [ "$candidate" = "$ancestor" ] && return 0
    [[ "$candidate" =~ ^[1-9][0-9]*$ ]] || return 1
    [ "$candidate" -gt 1 ] || return 1
    parent=$(ps -o ppid= -p "$candidate" 2>/dev/null | tr -d ' ')
    [[ "$parent" =~ ^[1-9][0-9]*$ ]] || return 1
    [ "$parent" != "$candidate" ] || return 1
    candidate=$parent
  done
  return 1
}

verify_gpu_ownership() {
  local pid owner co_occupants=
  while read -r pid; do
    [ -n "$pid" ] || continue
    owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
    if [ "$owner" = "nli61" ] && pid_descends_from "$pid" "$SERVICE_PID"; then
      continue
    fi
    co_occupants="${co_occupants}${pid}:${owner};"
  done < <(gpu_pids)
  if [ "$co_occupants" != "$LAST_CO_OCCUPANTS" ]; then
    if [ -n "$co_occupants" ]; then
      log "GPU co-occupancy observed gpu=$GPU occupants=$co_occupants action=continue_own_run_untouched"
      event gpu_co_occupancy "gpu=$GPU" "occupants=$co_occupants" \
        "action=continue_own_run_untouched"
    elif [ -n "$LAST_CO_OCCUPANTS" ]; then
      log "GPU co-occupancy cleared gpu=$GPU"
      event gpu_co_occupancy_cleared "gpu=$GPU"
    fi
    LAST_CO_OCCUPANTS=$co_occupants
  fi
  return 0
}

stop_process_group() {
  local pid=$1
  kill -0 "$pid" 2>/dev/null || return 0
  kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
  for _ in $(seq 1 30); do
    kill -0 "$pid" 2>/dev/null || return 0
    sleep 1
  done
  log "escalating owned process shutdown pid=$pid"
  kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
}

cleanup() {
  local code=$? pid candidate owner owned_remaining= foreign_remaining=
  [ "$CLEANUP_STARTED" -eq 0 ] || exit "$code"
  CLEANUP_STARTED=1
  trap - EXIT INT TERM HUP
  event cleanup_start "exit_code=$code" "reason=$EXIT_REASON"
  for pid in "${LANE_PIDS[@]:-}"; do
    [ -n "$pid" ] && stop_process_group "$pid"
  done
  if [ -n "$SERVICE_PID" ]; then
    event vllm_stop_requested "pid=$SERVICE_PID" "gpu=$GPU" "port=$PORT" "reason=$EXIT_REASON"
    stop_process_group "$SERVICE_PID"
  fi
  sleep 3
  snapshot final
  while read -r candidate; do
    [ -n "$candidate" ] || continue
    owner=$(ps -o user= -p "$candidate" 2>/dev/null | tr -d ' ')
    if [ "$owner" = "nli61" ]; then
      owned_remaining="${owned_remaining}${candidate};"
    else
      foreign_remaining="${foreign_remaining}${candidate}:${owner};"
    fi
  done < <(gpu_pids)
  [ -z "$foreign_remaining" ] || event foreign_processes_after_cleanup \
    "remaining=$foreign_remaining" "untouched=true"
  if [ -n "$owned_remaining" ]; then
    event gpu_cleanup_incomplete "remaining=$owned_remaining" "reason=$EXIT_REASON"
    log "GPU cleanup incomplete owned_remaining=$owned_remaining"
    exit 5
  fi
  event campaign_exit "exit_code=$code" "reason=$EXIT_REASON" "gpu_cleanup=true"
  log "EXIT code=$code reason=$EXIT_REASON gpu_cleanup=true"
  exit "$code"
}

trap cleanup EXIT
trap 'EXIT_REASON=terminated; exit 143' TERM
trap 'EXIT_REASON=interrupted; exit 130' INT
trap 'EXIT_REASON=hup; exit 129' HUP

assert_gpu_free || { EXIT_REASON=gpu_not_free; exit 4; }
assert_port_free || { EXIT_REASON=port_not_free; exit 4; }
snapshot before_start
event campaign_start \
  "pid=$$" "reason=resume_after_interrupted_or_failed_lane" "gpu=$GPU" "port=$PORT" \
  "protocol=adaptive_v2" "policy_mode=fixed_no_rl" "k=8" "rounds=15" \
  "domains_parallel=4" "resume=true" \
  "late_gpu_cooccupancy_policy=continue_own_run_untouched"

log "START vLLM gpu=$GPU port=$PORT model=Qwen3.5-9B"
setsid env \
  CUDA_VISIBLE_DEVICES="$GPU" \
  VLLM_USE_FLASHINFER_SAMPLER=0 \
  HF_HOME="$ROOT/.hf_cache" \
  "$VLLM" serve "$MODEL" \
  --host 127.0.0.1 \
  --port "$PORT" \
  --served-model-name Qwen3.5-9B \
  --max-model-len 131072 \
  --max-num-seqs 8 \
  --max-num-batched-tokens 16384 \
  --gpu-memory-utilization "$GPU_MEMORY_UTILIZATION" \
  --enforce-eager \
  --language-model-only \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_xml \
  >> "$SERVER_LOG" 2>&1 &
SERVICE_PID=$!
printf '%s\n' "$SERVICE_PID" > "$RUN/recovery_vllm_service.pid"
event vllm_start "pid=$SERVICE_PID" "gpu=$GPU" "port=$PORT"

ready=0
for _ in $(seq 1 300); do
  if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
    EXIT_REASON=vllm_startup_failure
    log "vLLM died during startup pid=$SERVICE_PID"
    tail -100 "$SERVER_LOG" || true
    exit 6
  fi
  if "$PYTHON" - "$PORT" >/dev/null 2>&1 <<'PY'
import json
import sys
import urllib.request

with urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/v1/models", timeout=2) as response:
    payload = json.load(response)
assert payload.get("data"), payload
PY
  then
    ready=1
    break
  fi
  sleep 2
done
[ "$ready" -eq 1 ] || { EXIT_REASON=vllm_startup_timeout; exit 7; }
verify_gpu_ownership
snapshot models_ready
event vllm_ready "pid=$SERVICE_PID" "gpu=$GPU" "port=$PORT"
log "READY vLLM pid=$SERVICE_PID gpu=$GPU port=$PORT"

setsid env GPU_OVERRIDE="$GPU" PORT_OVERRIDE="$PORT" \
  bash "$RUN/recovery_cp_then_ac1_lane.sh" > "$RUN/recovery_cp_then_ac1.worker.log" 2>&1 &
LANE_PIDS+=("$!")
setsid bash "$RUN/run_lane.sh" recovery_ahc_sql "$PORT" "$GPU" \
  eft__math__erdos_min_overlap eft__ahc_simpletes__ahc039 adrs__llm_sql \
  > "$RUN/recovery_ahc_sql.worker.log" 2>&1 &
LANE_PIDS+=("$!")
setsid bash "$RUN/run_lane.sh" recovery_ac2_eplb "$PORT" "$GPU" \
  eft__math__second_autocorr_ineq adrs__eplb \
  > "$RUN/recovery_ac2_eplb.worker.log" 2>&1 &
LANE_PIDS+=("$!")
setsid bash "$RUN/run_lane.sh" recovery_hadamard_transaction "$PORT" "$GPU" \
  eft__math__hadamard_maximal_det adrs__txn_scheduling \
  > "$RUN/recovery_hadamard_transaction.worker.log" 2>&1 &
LANE_PIDS+=("$!")

for index in "${!LANE_PIDS[@]}"; do
  event lane_start "name=${LANE_NAMES[$index]}" "pid=${LANE_PIDS[$index]}" "gpu=$GPU" "port=$PORT"
done
log "START four recovery lanes pids=${LANE_PIDS[*]}"

monitor_index=0
while true; do
  any_alive=0
  for pid in "${LANE_PIDS[@]}"; do
    kill -0 "$pid" 2>/dev/null && any_alive=1
  done
  [ "$any_alive" -eq 1 ] || break
  if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
    EXIT_REASON=vllm_died
    exit 8
  fi
  verify_gpu_ownership
  manifest=$(find "$CURRENT/cp26/campaign" "$RUN/tasks" -name adaptive_train_manifest.json -print -quit)
  if [ -n "$manifest" ]; then
    EXIT_REASON=unexpected_training_manifest
    log "FATAL training manifest appeared: $manifest"
    exit 10
  fi
  if [ $((monitor_index % 10)) -eq 0 ]; then
    snapshot "monitor_$(printf '%05d' "$monitor_index")"
    event progress_heartbeat "index=$monitor_index" "lanes_alive=4_max" "policy_updates=0"
  fi
  monitor_index=$((monitor_index + 1))
  sleep 30
done

LANE_STATUSES=()
set +e
for index in "${!LANE_PIDS[@]}"; do
  wait "${LANE_PIDS[$index]}"
  status=$?
  LANE_STATUSES+=("$status")
  event lane_exit "name=${LANE_NAMES[$index]}" "exit_code=$status"
done
set -e
for status in "${LANE_STATUSES[@]}"; do
  if [ "$status" -ne 0 ]; then
    EXIT_REASON="lane_failure_${LANE_STATUSES[*]}"
    exit 11
  fi
done

MPLCONFIGDIR="$RUN/.matplotlib" "$PYTHON" "$RUN/report.py" \
  --current-run "$CURRENT" --remaining-run "$RUN" --output "$RUN/final_report"

"$PYTHON" - "$CURRENT" "$RUN" <<'PY'
import json
import sys
from pathlib import Path

current, run = map(Path, sys.argv[1:])
markers = list(current.rglob("v2_audit_complete.json")) + list(run.rglob("v2_audit_complete.json"))
assert len(markers) == 165, len(markers)
payload = json.loads((run / "final_report/final_results.json").read_text())
assert payload.get("complete") is True
assert len(payload.get("tasks") or {}) == 11
report_audit = json.loads((run / "final_report/report_audit.json").read_text())
assert report_audit.get("passed") is True, report_audit
assert int(report_audit.get("task_count", -1)) == 11, report_audit
assert int(report_audit.get("round_count", -1)) == 165, report_audit
PY

EXIT_REASON=completed
log "COMPLETE all 11 tasks x 15 audited rounds; final report generated"
