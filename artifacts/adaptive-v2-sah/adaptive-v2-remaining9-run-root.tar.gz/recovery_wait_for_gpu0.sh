#!/usr/bin/env bash
set -euo pipefail
umask 027

ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
PORT=8822
CANDIDATE_GPUS=(0 1 2 3)
LOG=$RUN/recovery_wait.log
LAST_OCCUPANTS=
RETRIES=0
REPLACEMENT_GPU=${REPLACEMENT_GPU:-}
REPLACEMENT_GPU_MEMORY_UTILIZATION=${REPLACEMENT_GPU_MEMORY_UTILIZATION:-0.62}
REPLACEMENT_ATTEMPTED=0

printf '%s\n' "$$" > "$RUN/recovery_wait.pid"

log() {
  printf '[%s] [recovery-wait] %s\n' "$(date -Is)" "$*" | tee -a "$LOG"
}

gpu_pids() {
  local gpu=$1
  nvidia-smi -i "$gpu" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null \
    | sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p'
}

port_free() {
  "$PYTHON" - "$PORT" >/dev/null 2>&1 <<'PY'
import socket
import sys

sock = socket.socket()
try:
    sock.bind(("127.0.0.1", int(sys.argv[1])))
finally:
    sock.close()
PY
}

trap 'log "STOP signal=TERM no_gpu_owned=true"; exit 143' TERM
trap 'log "STOP signal=INT no_gpu_owned=true"; exit 130' INT
trap 'log "STOP signal=HUP no_gpu_owned=true"; exit 129' HUP

log "START wait_for_free_gpu gpus=0,1,2,3 port=$PORT poll_seconds=30"
while true; do
  if [ -n "$REPLACEMENT_GPU" ] && [ "$REPLACEMENT_ATTEMPTED" -eq 0 ] && port_free; then
    REPLACEMENT_ATTEMPTED=1
    log "ATTEMPT authorized raw-model replacement gpu=$REPLACEMENT_GPU port=$PORT utilization=$REPLACEMENT_GPU_MEMORY_UTILIZATION retries=$RETRIES"
    set +e
    ALLOW_EXISTING_OCCUPANTS=1 \
      GPU_MEMORY_UTILIZATION="$REPLACEMENT_GPU_MEMORY_UTILIZATION" \
      GPU_OVERRIDE="$REPLACEMENT_GPU" PORT_OVERRIDE="$PORT" \
      bash "$RUN/recovery_gpu0.sh"
    status=$?
    set -e
    if [ "$status" -eq 0 ]; then
      log "COMPLETE recovery and all experiments status=0"
      exit 0
    fi
    RETRIES=$((RETRIES + 1))
    log "RAW MODEL REPLACEMENT EXIT status=$status retries=$RETRIES artifacts_preserved=true"
    LAST_OCCUPANTS=
  fi

  snapshot= free_gpu=
  for gpu in "${CANDIDATE_GPUS[@]}"; do
    occupants=$(gpu_pids "$gpu" || true)
    if [ -z "$occupants" ] && [ -z "$free_gpu" ]; then
      free_gpu=$gpu
      snapshot="${snapshot}gpu${gpu}=free;"
      continue
    fi
    owners=
    while read -r pid; do
      [ -n "$pid" ] || continue
      owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
      owners="${owners}${pid}:${owner};"
    done <<< "$occupants"
    snapshot="${snapshot}gpu${gpu}=${owners:-free};"
  done
  if [ "$snapshot" != "$LAST_OCCUPANTS" ]; then
    log "OBSERVE $snapshot action=occupied_processes_untouched"
    LAST_OCCUPANTS=$snapshot
  fi

  if [ -n "$free_gpu" ] && port_free; then
    log "ATTEMPT recovery gpu=$free_gpu port=$PORT retries=$RETRIES"
    set +e
    GPU_OVERRIDE="$free_gpu" PORT_OVERRIDE="$PORT" bash "$RUN/recovery_gpu0.sh"
    status=$?
    set -e
    if [ "$status" -eq 0 ]; then
      log "COMPLETE recovery and all experiments status=0"
      exit 0
    fi
    RETRIES=$((RETRIES + 1))
    log "RECOVERY EXIT status=$status retries=$RETRIES artifacts_preserved=true"
    if [ "$status" -ne 4 ] && [ "$status" -ne 9 ] && [ "$RETRIES" -ge 3 ]; then
      log "STOP retry_budget_exhausted status=$status retries=$RETRIES"
      exit "$status"
    fi
    LAST_OCCUPANTS=
  fi
  sleep 30
done
