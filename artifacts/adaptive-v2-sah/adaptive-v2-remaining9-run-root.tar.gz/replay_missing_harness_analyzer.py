#!/usr/bin/env python3
"""Replay one failed Adaptive V2 harness analyzer from its frozen prompt.

This is a provenance-preserving recovery helper.  It never edits the original
analysis files and explicitly records that the replay did not participate in
the original proposal.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

from nexau import Agent, AgentConfig

from protocols import adaptive_v2_analysis as ava
from protocols.adaptive_v1_tokens import count_chat_tokens


def canonical(value: object) -> str:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )


def digest_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analysis-dir", required=True)
    parser.add_argument("--harness-id", required=True)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer-path", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument(
        "--reason",
        default="original per-harness analyzer failed before producing a valid report",
    )
    args = parser.parse_args()

    analysis_dir = Path(args.analysis_dir).resolve()
    harness_id = args.harness_id
    prompts = json.loads((analysis_dir / "harness_prompts.json").read_text())
    reports = json.loads((analysis_dir / "harness_reports.json").read_text())
    trajectories = json.loads(
        (analysis_dir / "harness_trajectories.json").read_text()
    )
    original_meta = json.loads((analysis_dir / "meta.json").read_text())
    prompt_payload = prompts[harness_id]
    original_report = reports[harness_id]
    original_trajectory = trajectories[harness_id]
    if original_trajectory:
        raise SystemExit(f"{harness_id}: original trajectory is not empty")

    member = prompt_payload["member"]
    evidence_id = str(member["evidence_id"])
    rendered = canonical(prompt_payload)
    if len(rendered) > ava.PER_HARNESS_MAX_CHARS:
        raise SystemExit("frozen prompt exceeds current character contract")
    token_count, token_source = count_chat_tokens(
        system=(
            ava.ANALYSIS_PACKAGE / "harness_trace_analyzer" / "system.md"
        ).read_text(),
        user=rendered,
        tokenizer_path=args.tokenizer_path,
    )
    if token_count > ava.PER_HARNESS_MAX_TOKENS:
        raise SystemExit("frozen prompt exceeds current token contract")

    config = AgentConfig.from_yaml(
        ava.ANALYSIS_PACKAGE / "harness_trace_analyzer" / "agent.yaml"
    )
    ava._configure(
        config,
        base_url=args.base_url,
        model=args.model,
        api_key="EMPTY",
        timeout=args.timeout,
        seed=args.seed,
    )
    agent = Agent(config=config)
    raw = agent.run(message=rendered)
    response, warnings = ava._drop_untested_attributions(
        ava._json_object(ava._agent_text(raw, agent)),
        member.get("changed_fields") or [],
    )
    response, runtime_warnings = ava._drop_runtime_disprovable_budget_claims(
        response, member.get("trace") or {}
    )
    warnings.extend(runtime_warnings)
    response, list_warnings = ava._trim_overfull_report_lists(response)
    warnings.extend(list_warnings)
    response, string_warnings = ava._clip_overlong_report_strings(response)
    warnings.extend(string_warnings)
    report = ava.validate_harness_report(
        response,
        harness_id=harness_id,
        evidence_id=evidence_id,
        changed_fields=member.get("changed_fields") or [],
    )
    trajectory = ava._history(agent)
    if not trajectory:
        raise SystemExit("replay produced an empty analyzer trajectory")

    recovery_dir = analysis_dir / "recovery" / harness_id
    recovery_dir.mkdir(parents=True, exist_ok=True)
    values = {
        "frozen_prompt_payload.json": prompt_payload,
        "original_fallback_report.json": original_report,
        "original_empty_trajectory.json": original_trajectory,
        "replay_report.json": report,
        "replay_trajectory.json": trajectory,
        "replay_meta.json": {
            "schema": "sah.adaptive-v2-harness-analyzer-replay/1",
            "harness_id": harness_id,
            "evidence_id": evidence_id,
            "replay_time": datetime.now().astimezone().isoformat(
                timespec="seconds"
            ),
            "reason": args.reason,
            "original_analysis_version": original_meta.get("version"),
            "original_analysis_errors": original_meta.get("errors") or [],
            "replay_analysis_version": ava.ANALYSIS_VERSION,
            "replay_package_hash": ava.analysis_package_hash(),
            "frozen_prompt_payload_hash": digest_text(canonical(prompt_payload)),
            "rendered_prompt_hash": digest_text(rendered),
            "token_count": token_count,
            "token_source": token_source,
            "model": args.model,
            "request_seed": args.seed,
            "participated_in_original_proposal": False,
            "original_fallback_and_brief_preserved": True,
            "uses_only_frozen_pre_proposal_prompt": True,
            "future_round_data_used": False,
            "warnings": warnings,
            "valid": True,
        },
    }
    for name, value in values.items():
        (recovery_dir / name).write_text(
            json.dumps(value, indent=2, ensure_ascii=False)
        )
    print(
        f"REPLAY PASS harness={harness_id} trajectory={len(trajectory)} "
        f"tokens={token_count} -> {recovery_dir}"
    )


if __name__ == "__main__":
    main()
