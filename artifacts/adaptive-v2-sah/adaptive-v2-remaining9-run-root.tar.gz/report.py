#!/usr/bin/env python3
"""Build the audited Adaptive V2 all-domain tables and score trajectory plots."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".matplotlib"))
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


TASK_NAMES = {
    "eft__math__erdos_min_overlap": "Erdos",
    "eft__math__first_autocorr_ineq": "AC1",
    "eft__math__second_autocorr_ineq": "AC2",
    "eft__math__circle_packing": "CP-26",
    "eft__math__hadamard_maximal_det": "Hadamard",
    "eft__ahc_simpletes__ahc039": "ahc039",
    "eft__ahc_simpletes__ahc058": "ahc058",
    "adrs__eplb": "EPLB",
    "adrs__prism": "PRISM",
    "adrs__llm_sql": "LLM-SQL",
    "adrs__txn_scheduling": "Transaction",
}

FIELD_NAMES = {
    "system_prompt": "system prompt",
    "skill_description": "skill 描述",
    "skill_body": "skill 内容",
    "sampling.temperature": "temperature",
    "sampling.top_p": "top-p",
    "sampling.top_k": "top-k",
    "sampling.max_tokens": "token 上限",
    "agent.max_iterations": "迭代上限",
    "middleware.budget_reminder_from_left": "预算提醒",
    "middleware.long_tool_output_max_chars": "工具输出上限",
}


def load(path: Path):
    return json.loads(path.read_text())


def fmt(value) -> str:
    if value is None:
        return "—"
    value = float(value)
    if value == 0:
        return "0"
    if abs(value) >= 1000 or abs(value) < 1e-4:
        return f"{value:.6g}"
    return f"{value:.6f}".rstrip("0").rstrip(".")


def task_safe(task_id: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in task_id)


def md_text(value: str) -> str:
    """Keep generated one-line descriptions inside one Markdown table cell."""
    return str(value).replace("|", "／").replace("\n", " ")


def concise_clause(value: str, limit: int = 110) -> str:
    """Normalize evidence prose to one bounded clause, preserving decimal points."""
    normalized = re.sub(r"\s+", " ", md_text(value)).strip()
    # Split only at likely sentence boundaries; decimal points such as 0.93 are
    # intentionally not boundaries.
    parts = re.split(
        r"[。！？]+|(?<=[!?])\s+|\.(?=\s+[A-Z`\u4e00-\u9fff])",
        normalized,
        maxsplit=1,
    )
    selected = parts[0].strip(" .!?。！？;；")
    if len(selected) > limit:
        selected = selected[: limit - 1].rstrip(" .!?。！？;；") + "…"
    return selected


def is_single_sentence(value: str) -> bool:
    """Require exactly one terminal Chinese full stop and no embedded sentence."""
    text = str(value or "").strip()
    if not text.endswith("。") or text.count("。") != 1:
        return False
    body = text[:-1]
    return not re.search(
        r"[！？]+|(?<=[!?])\s+|\.(?=\s+[A-Z`\u4e00-\u9fff])",
        body,
    )


def campaign_map(current: Path, remaining: Path) -> dict[str, Path]:
    result = {
        "eft__math__circle_packing": current / "cp26/campaign",
        "adrs__prism": current / "prism/campaign",
    }
    for task_id in TASK_NAMES:
        if task_id not in result:
            result[task_id] = remaining / "tasks" / task_safe(task_id) / "campaign"
    return result


def model_provenance(task_id: str, round_index: int, transition: dict) -> dict[str, str]:
    """Classify a round using the immutable user-requested model transition record."""
    grandfathered = (
        transition.get("grandfathered_audited_results", {}).get("task_round_counts", {})
    )
    transition_rounds = transition.get("transition_rounds_may_retain_pre_switch_partial_artifacts", {})
    strict_from = transition.get("strict_original_model_only_from_round", {})
    original = str(transition.get("new_model", {}).get("path") or "unknown")
    previous = str(transition.get("old_model", {}).get("path") or "unknown")
    if round_index < int(grandfathered.get(task_id, 0)):
        return {
            "model_phase": "grandfathered_pre_switch",
            "model_checkpoint": previous,
            "model_note_cn": "用户要求保留、不重跑的切换前已审计结果",
        }
    if round_index == int(transition_rounds.get(task_id, -1)):
        return {
            "model_phase": "transition_partial_artifacts",
            "model_checkpoint": "mixed_provenance_see_transition_record",
            "model_note_cn": "模型切换时已在途，可能保留切换前部分产物",
        }
    if round_index >= int(strict_from.get(task_id, 10**9)):
        return {
            "model_phase": "strict_original_qwen",
            "model_checkpoint": original,
            "model_note_cn": "严格使用原始 Qwen3.5-9B",
        }
    raise AssertionError((task_id, round_index, "round is not covered by model transition record"))


def changed_summary(member: dict) -> str:
    fields = list(member.get("changed_fields") or [])
    partial = ((member.get("action") or {}).get("native_partial_spec") or {})
    labels = []
    for field in fields:
        if field.startswith("tool_descriptions."):
            label = f"`{field.rsplit('.', 1)[-1]}` 工具说明"
        elif field.startswith("new_tools."):
            label = f"新增 `{field.rsplit('.', 1)[-1]}` 工具"
        elif field.startswith("new_skills."):
            label = f"新增 `{field.rsplit('.', 1)[-1]}` skill"
        elif field.startswith("new_middlewares."):
            label = f"新增 `{field.rsplit('.', 1)[-1]}` middleware"
        elif field == "new_tools":
            label = "新增工具"
        elif field == "new_skills":
            label = "新增 skill"
        elif field == "new_middlewares":
            label = "新增 middleware"
        else:
            label = FIELD_NAMES.get(field, field)
            parts = field.split(".")
            if len(parts) == 2 and parts[0] in {"sampling", "agent", "middleware"}:
                group = partial.get(parts[0]) or {}
                value = group.get(parts[1]) if isinstance(group, dict) else None
                if value is not None:
                    label = f"{label}={value}"
        if label not in labels:
            labels.append(label)
    if not labels:
        return "未形成有效字段改动"
    shown = "、".join(labels[:3])
    if len(labels) > 3:
        shown += f"等 {len(labels)} 类字段"
    return shown


def strategy_summary(member: dict) -> str | None:
    """Extract one concise, deterministic method clause from the native proposal."""
    action = member.get("action") or {}
    partial = action.get("native_partial_spec") or {}

    changed = set(member.get("changed_fields") or [])
    changed_tool_names = {
        field.split(".", 1)[1]
        for field in changed
        if field.startswith("new_tools.") and "." in field
    }
    for item in partial.get("new_tools") or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "")
        description = re.sub(r"\s+", " ", str(item.get("description") or "")).strip()
        if description and (not changed_tool_names or name in changed_tool_names):
            selected = f"使用 {name} 工具：{description}" if name else description
            return concise_clause(selected)

    text = partial.get("system_prompt")
    if not text:
        text = partial.get("skill_description") or partial.get("skill_body")
    if not isinstance(text, str) or not text.strip():
        return None

    text = re.sub(r"(?m)^\s*#{1,6}\s+.*$", "", text)
    normalized = re.sub(r"\s+", " ", text).strip()
    normalized = re.sub(r"(?:^|\s)#{1,6}\s+", " ", normalized).strip()
    # Keep numbered method lists in one clause instead of splitting at ``1.``.
    normalized = re.sub(r"\b(\d+)\.\s+", r"\1) ", normalized)
    clauses = re.split(
        r"(?<=[.!?])\s+|\s+(?=Method\s*[—:-])|(?=\b\d+\)\s+)",
        normalized,
    )
    boilerplate = (
        "you are a ",
        "you are an ",
        "you are the ",
        "expert software developer",
        "fixed inner harness",
        "single editable region",
        "evolve-block-start",
        "make exactly one tool call",
        "unchanged evaluator",
        "the seed program achieved",
        "the current harness achieved",
        "your goal is to maximize",
        "targeted search/replace edits",
        "the frozen program contains",
        "you are optimizing",
        "parse the task objective",
        "replace the placeholder",
        "prefer targeted search/replace",
        "search/replace",
        "the seed uses",
        "seed constructs",
        "your harness will soon provide",
        "call `evaluate_solution`",
        "call evaluate_solution",
        "call `finish`",
    )
    actionable = (
        "execute",
        "begin by",
        "implement",
        "construct",
        "search",
        "refine",
        "gradient",
        "placement",
        "schedule",
        "optimiz",
        "swap",
        "phase",
        "block",
        "use ",
        "test ",
    )
    contextual = (
        "method",
        "strategy",
        "approach",
    )
    candidates = [
        clause.strip(" -—:\t")
        for clause in clauses
        if 24 <= len(clause.strip()) <= 800
        and not any(token in clause.lower() for token in boilerplate)
    ]
    def score(clause: str) -> tuple[int, int]:
        lowered = clause.lower()
        return (
            3 * sum(token in lowered for token in actionable)
            + sum(token in lowered for token in contextual),
            -len(clause),
        )

    selected = max(candidates, key=score) if candidates else None
    if not selected:
        return None
    return concise_clause(selected)


def audit_note_cn(audit: dict) -> str:
    """Return a concise provenance note without concealing accepted recovery paths."""
    source = str(audit.get("analysis_source") or "unknown")
    replayed = [str(item) for item in (audit.get("per_harness_replay_accepted") or [])]
    if replayed:
        harnesses = "、".join(f"`{item}`" for item in replayed)
        return (
            f"{harnesses} 的 analyzer 使用冻结的 pre-proposal prompt 做事后 replay；"
            "replay 未参与原 proposal，原始 fallback 与 coordinator 因果记录均保留。"
        )
    if audit.get("coordinator_fallback_accepted") is True:
        return "population coordinator 模型调用失败后使用了经严格校验的确定性 runtime fallback。"
    if source == "bootstrap_empty_population":
        return "初始轮没有历史 population，使用 bootstrap empty-population 上下文。"
    if source == "nexau_k_harness_analyzers_plus_population_coordinator":
        return "常规 per-harness analyzer 与 population coordinator 审计通过。"
    return f"审计来源：`{source}`。"


def read_round(task_id: str, campaign: Path, round_index: int, transition: dict) -> dict:
    root = campaign / f"round{round_index:03d}"
    audit = load(root / "v2_audit_complete.json")
    assert audit.get("passed") is True, (task_id, round_index, audit)
    assert audit.get("task_id") == task_id, (task_id, round_index, "audit task mismatch", audit)
    assert int(audit.get("round", -1)) == round_index, (task_id, round_index, "audit round mismatch", audit)
    assert int(audit.get("requested_k", -1)) == 8, (task_id, round_index, "requested_k", audit)
    assert int(audit.get("policy_updates", -1)) == 0, (task_id, round_index, "policy_updates", audit)
    summary = load(root / "round_summary.json")["groups"][task_id]
    population = load(root / "population" / task_id / "population.json")
    members = list(population.get("members") or [])
    assert members, (task_id, round_index, "empty population")
    direction = population.get("score_direction", "higher_is_better")
    reverse = direction != "lower_is_better"
    scored = []
    for member in members:
        score = (member.get("trace") or {}).get("best_score")
        if score is not None and math.isfinite(float(score)):
            scored.append((float(score), member))
    assert scored, (task_id, round_index, "no finite rollout")
    assert int(population.get("requested_k", -1)) == 8, (task_id, round_index, "population requested_k")
    assert int(population.get("evaluated_k", -1)) == int(audit.get("evaluated_k", -2)), (
        task_id,
        round_index,
        "evaluated_k mismatch",
    )
    candidate_score, winner = sorted(scored, key=lambda row: row[0], reverse=reverse)[0]
    base = float(summary.get("base_score"))
    gain = candidate_score - base if reverse else base - candidate_score
    candidate_is_round_best = (
        candidate_score >= base if reverse else candidate_score <= base
    )
    round_best = candidate_score if candidate_is_round_best else base
    changes = changed_summary(winner)
    strategy = strategy_summary(winner)
    harness_id = winner.get("harness_id") or f"cand{int(winner.get('k', 0)):02d}"
    intervention = f"调整了{changes}"
    if strategy:
        intervention += f"，核心策略是“{strategy}”"
    if gain > 0:
        sentence = f"{harness_id} {intervention}；本轮最高候选 rollout 较基线提高 {fmt(gain)}。"
    elif math.isclose(gain, 0.0, abs_tol=1e-12):
        sentence = f"{harness_id} {intervention}；本轮最高候选 rollout 与基线持平。"
    else:
        sentence = f"{harness_id} {intervention}；本轮最高候选 rollout 低于基线 {fmt(abs(gain))}。"
    provenance = model_provenance(task_id, round_index, transition)
    return {
        "round": round_index,
        "base_score": base,
        "candidate_best_rollout": candidate_score,
        "round_best_rollout": round_best,
        "round_best_source": harness_id if candidate_is_round_best else "base",
        "gain_vs_base": gain,
        "winner": harness_id,
        "evaluated_k": int(population.get("evaluated_k", len(members))),
        "requested_k": int(population.get("requested_k", 8)),
        "rollouts": int(audit.get("rollouts", -1)),
        "analyzer_prompts": int(audit.get("analyzer_prompts", -1)),
        "score_direction": direction,
        "description_cn": sentence,
        "analysis_source": str(audit.get("analysis_source") or "unknown"),
        "original_analysis_source": audit.get("original_analysis_source"),
        "coordinator_fallback_accepted": audit.get("coordinator_fallback_accepted") is True,
        "per_harness_replay_accepted": list(audit.get("per_harness_replay_accepted") or []),
        "policy_updates": int(audit.get("policy_updates", -1)),
        "audit_note_cn": audit_note_cn(audit),
        "population_artifact": str(root / "population" / task_id / "population.json"),
        "analysis_artifact": str(root / "analysis" / task_id),
        **provenance,
    }


def add_best_so_far(rows: list[dict]) -> None:
    higher = rows[0]["score_direction"] != "lower_is_better"
    best = rows[0]["base_score"]
    for row in rows:
        value = row["round_best_rollout"]
        best = max(best, value) if higher else min(best, value)
        row["best_so_far"] = best


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = [
        "round",
        "base_score",
        "candidate_best_rollout",
        "round_best_rollout",
        "round_best_source",
        "best_so_far",
        "gain_vs_base",
        "winner",
        "evaluated_k",
        "requested_k",
        "rollouts",
        "analyzer_prompts",
        "description_cn",
        "analysis_source",
        "original_analysis_source",
        "coordinator_fallback_accepted",
        "per_harness_replay_accepted",
        "policy_updates",
        "audit_note_cn",
        "population_artifact",
        "analysis_artifact",
        "model_phase",
        "model_checkpoint",
        "model_note_cn",
    ]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_table(path: Path, name: str, task_id: str, campaign: Path, rows: list[dict]) -> None:
    lines = [
        f"# {name} — Adaptive V2 逐轮结果",
        "",
        f"- Task ID：`{task_id}`",
        f"- Campaign：`{campaign}`",
        "- 曲线定义：`Round best rollout` 是当轮所有实际 rollout（matched base + K 个有效候选）中的最高分；`Best so far` 是截至当轮的历史最高观测分，因此单调不降。表格同时保留候选集合中的最高分，便于判断 harness 改动本身是否超过 matched base。",
        "",
        "| 轮次 | matched base | 最高候选 rollout | 当轮最高 rollout（含 base） | 历史 best-so-far | 候选相对基线增益 | 最高候选 | 当轮最高来源 | K | 本轮改动 | 模型来源 | 审计来源 |",
        "|---:|---:|---:|---:|---:|---:|---|---|---:|---|---|---|",
    ]
    for row in rows:
        lines.append(
            "| {round} | {base} | {candidate} | {rollout} | {best} | {gain} | `{winner}` | `{source}` | {evaluated}/{requested} | {description} | {model_note} | {audit_note} |".format(
                round=row["round"],
                base=fmt(row["base_score"]),
                candidate=fmt(row["candidate_best_rollout"]),
                rollout=fmt(row["round_best_rollout"]),
                best=fmt(row["best_so_far"]),
                gain=fmt(row["gain_vs_base"]),
                winner=row["winner"],
                source=row["round_best_source"],
                evaluated=row["evaluated_k"],
                requested=row["requested_k"],
                description=md_text(row["description_cn"]),
                model_note=md_text(row["model_note_cn"]),
                audit_note=md_text(row["audit_note_cn"]),
            )
        )
    path.write_text("\n".join(lines) + "\n")


def plot_task(path: Path, name: str, rows: list[dict]) -> None:
    rounds = [row["round"] for row in rows]
    rollout = [row["round_best_rollout"] for row in rows]
    best = [row["best_so_far"] for row in rows]
    fig, ax = plt.subplots(figsize=(9.6, 5.2), constrained_layout=True)
    ax.plot(rounds, rollout, marker="o", linewidth=1.8, color="#4472C4", label="Round best rollout")
    ax.plot(rounds, best, marker="s", linewidth=2.4, color="#ED7D31", label="Best observed so far")
    ax.set_title(f"{name} — Adaptive V2 score trajectory")
    ax.set_xlabel("Round")
    ax.set_ylabel("Evaluator score")
    ax.set_xticks(rounds)
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def validate_final_report(output: Path, results: dict, transition: dict) -> dict:
    """Fail closed on missing rows, non-monotonic curves, or absent deliverables."""
    issues = []
    checked_files = []
    for task_id, task in results.items():
        name = str(task["name"])
        rows = list(task.get("rounds") or [])
        if len(rows) != 15 or [row.get("round") for row in rows] != list(range(15)):
            issues.append(f"{task_id}: round coverage is not exactly 0..14")
            continue
        higher = rows[0]["score_direction"] != "lower_is_better"
        previous = None
        for row in rows:
            expected_round = (
                max(row["base_score"], row["candidate_best_rollout"])
                if higher
                else min(row["base_score"], row["candidate_best_rollout"])
            )
            if not math.isclose(
                float(row["round_best_rollout"]), float(expected_round), rel_tol=0, abs_tol=1e-12
            ):
                issues.append(f"{task_id} round {row['round']}: round-best mismatch")
            current = float(row["best_so_far"])
            if previous is not None:
                monotonic = current >= previous - 1e-12 if higher else current <= previous + 1e-12
                if not monotonic:
                    issues.append(f"{task_id} round {row['round']}: best-so-far is not monotonic")
            previous = current
            if int(row.get("policy_updates", -1)) != 0:
                issues.append(f"{task_id} round {row['round']}: policy update is not zero")
            if int(row.get("requested_k", -1)) != 8:
                issues.append(f"{task_id} round {row['round']}: requested K is not eight")
            if int(row.get("rollouts", -1)) != int(row.get("evaluated_k", -2)) + 1:
                issues.append(
                    f"{task_id} round {row['round']}: expected base plus exactly one rollout per valid harness"
                )
            if not is_single_sentence(str(row.get("description_cn") or "")):
                issues.append(f"{task_id} round {row['round']}: description is not exactly one sentence")

        stem = name.lower().replace("-", "_")
        expected_files = (
            output / "tables" / f"{stem}.csv",
            output / "tables" / f"{stem}.md",
            output / "plots" / f"{stem}.png",
        )
        for path in expected_files:
            checked_files.append(str(path))
            if not path.exists() or path.stat().st_size < 100:
                issues.append(f"{task_id}: missing or empty artifact {path}")

    phase_counts = {}
    for task in results.values():
        for row in task.get("rounds") or []:
            phase = str(row.get("model_phase") or "missing")
            phase_counts[phase] = phase_counts.get(phase, 0) + 1
    expected_phase_counts = {
        "grandfathered_pre_switch": int(
            transition.get("grandfathered_audited_results", {}).get("audit_marker_count", -1)
        ),
        "transition_partial_artifacts": len(
            transition.get("transition_rounds_may_retain_pre_switch_partial_artifacts", {})
        ),
    }
    expected_phase_counts["strict_original_qwen"] = 165 - sum(expected_phase_counts.values())
    if phase_counts != expected_phase_counts:
        issues.append(
            f"model provenance counts mismatch: actual={phase_counts}, expected={expected_phase_counts}"
        )

    audit = {
        "schema": "sah.adaptive-v2-final-report-audit/1",
        "passed": not issues,
        "task_count": len(results),
        "round_count": sum(len(task.get("rounds") or []) for task in results.values()),
        "model_phase_counts": phase_counts,
        "expected_model_phase_counts": expected_phase_counts,
        "checked_files": checked_files,
        "issues": issues,
    }
    (output / "report_audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False))
    if issues:
        raise RuntimeError("final report audit failed: " + "; ".join(issues[:8]))
    return audit


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--current-run", required=True, type=Path)
    parser.add_argument("--remaining-run", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    tables = args.output / "tables"
    plots = args.output / "plots"
    tables.mkdir(exist_ok=True)
    plots.mkdir(exist_ok=True)

    campaigns = campaign_map(args.current_run.resolve(), args.remaining_run.resolve())
    transition_path = args.remaining_run.resolve() / "model_transition.json"
    transition = load(transition_path)
    assert transition.get("schema") == "sah.adaptive-v2-model-transition/1", transition_path
    all_results = {}
    summary_rows = []
    provenance_rows = []
    for task_id, name in TASK_NAMES.items():
        campaign = campaigns[task_id]
        assert campaign.exists(), campaign
        rows = [read_round(task_id, campaign, round_index, transition) for round_index in range(15)]
        assert [row["round"] for row in rows] == list(range(15)), (task_id, "round coverage")
        assert all(row["policy_updates"] == 0 for row in rows), (task_id, "unexpected policy update")
        add_best_so_far(rows)
        stem = name.lower().replace("-", "_")
        write_csv(tables / f"{stem}.csv", rows)
        write_table(tables / f"{stem}.md", name, task_id, campaign, rows)
        plot_task(plots / f"{stem}.png", name, rows)
        initial = rows[0]["base_score"]
        final = rows[-1]["best_so_far"]
        higher = rows[0]["score_direction"] != "lower_is_better"
        gain = final - initial if higher else initial - final
        all_results[task_id] = {
            "name": name,
            "campaign": str(campaign),
            "initial_score": initial,
            "final_best_observed": final,
            "absolute_gain": gain,
            "rounds": rows,
        }
        summary_rows.append((name, task_id, initial, final, gain, stem))
        for row in rows:
            if row["coordinator_fallback_accepted"] or row["per_harness_replay_accepted"]:
                provenance_rows.append((name, row["round"], row["audit_note_cn"]))

    payload = {
        "schema": "sah.adaptive-v2-all11-final-results/3",
        "complete": True,
        "protocol": "adaptive_v2",
        "policy_mode": "fixed_no_rl",
        "k": 8,
        "rounds": 15,
        "model_transition": transition,
        "tasks": all_results,
    }
    (args.output / "final_results.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False))

    lines = [
        "# Adaptive V2 全 domain 最终结果",
        "",
        "本报告只在 11 个任务均完成 15 轮、每轮 `v2_audit_complete.json` 通过后生成。固定 Qwen 模型没有进行 RL 更新；每轮生成 K=8 个候选 harness，每个有效 harness 只 rollout 一次。",
        "",
        "两条曲线分别表示当轮所有实际 rollout（matched base + 有效候选）中的最高分（可能波动）和截至该轮的历史最佳观测分数（单调 best-so-far）。逐轮表格另列最高候选 rollout，避免把 base 重评波动误当成候选 harness 改进。",
        "",
        "## 模型切换与结果口径",
        "",
        "按用户要求，切换前已经审计完成的 93 轮原样保留、不重跑；4 个切换时已在途的轮次可能保留部分切换前产物；其余 68 轮严格使用原始 `/data/models/Qwen3.5-9B`。逐轮表格明确标注模型来源，完整边界和服务证据见 [model_transition.json](../model_transition.json)。",
        "",
        "| 任务 | 初始分数 | 最终 best-so-far | 绝对提升 | 逐轮表格 | 轨迹图 |",
        "|---|---:|---:|---:|---|---|",
    ]
    for name, _task_id, initial, final, gain, stem in summary_rows:
        lines.append(
            f"| {name} | {fmt(initial)} | {fmt(final)} | {fmt(gain)} | [表格](tables/{stem}.md) | [折线图](plots/{stem}.png) |"
        )
    lines.extend(["", "## 审计与恢复来源", ""])
    if provenance_rows:
        lines.append("以下轮次使用了审计允许但需要显式披露的恢复路径；其余轮次按常规 analyzer/coordinator 路径完成：")
        lines.append("")
        for name, round_index, note in provenance_rows:
            lines.append(f"- {name} 第 {round_index} 轮：{note}")
    else:
        lines.append("所有轮次均按常规 analyzer/coordinator 路径完成，无 fallback 或事后 replay。")
    lines.extend(
        [
            "",
            "完整机器可读结果见 [final_results.json](final_results.json)，每个任务另有 CSV、Markdown 表格和 PNG 图。原始 harness、analyzer prompt/report、coordinator trace 与 rollout trace 保留在表格所列 campaign 路径中。",
            "最终交付的覆盖率、单调曲线、fixed/no-RL 与文件完整性自检见 [report_audit.json](report_audit.json)。",
        ]
    )
    (args.output / "SUMMARY_CN.md").write_text("\n".join(lines) + "\n")
    validate_final_report(args.output, all_results, transition)
    print(args.output / "SUMMARY_CN.md")


if __name__ == "__main__":
    main()
