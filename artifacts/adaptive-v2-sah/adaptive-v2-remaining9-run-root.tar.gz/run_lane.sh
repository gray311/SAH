#!/usr/bin/env bash
set -euo pipefail
umask 027

if [ "$#" -lt 4 ]; then
  echo "usage: $0 LANE PORT GPU TASK_ID..." >&2
  exit 2
fi

LANE=$1
PORT=$2
GPU=$3
shift 3
TASKS=("$@")
ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
LOG=$RUN/$LANE.log

log() {
  printf '[%s] [%s] %s\n' "$(date -Is)" "$LANE" "$*" | tee -a "$LOG"
}

log "START gpu=$GPU port=$PORT tasks=${#TASKS[@]}"
for TASK_ID in "${TASKS[@]}"; do
  log "TASK START id=$TASK_ID"
  bash "$RUN/run_task.sh" "$TASK_ID" "$PORT"
  log "TASK COMPLETE id=$TASK_ID"
done
log "COMPLETE gpu=$GPU tasks=${#TASKS[@]}"
