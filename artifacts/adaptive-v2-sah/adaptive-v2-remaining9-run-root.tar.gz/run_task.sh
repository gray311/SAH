#!/usr/bin/env bash
set -euo pipefail
umask 027
export PYTHONDONTWRITEBYTECODE=1

if [ "$#" -ne 2 ]; then
  echo "usage: $0 TASK_ID PORT" >&2
  exit 2
fi

TASK_ID=$1
PORT=$2
ROOT=/home/nli61/workspace/harness_train
RUN=$ROOT/.tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500
export TMPDIR=$ROOT/.tmp_adaptive_v2
mkdir -p "$TMPDIR"
CURRENT_RUN=$ROOT/.tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059
V1_RUN=$ROOT/.tools/adaptive-v1-population-once-k8-all11-15r-seed23-20260731T112313
REPO=$ROOT/.tools/sah-adaptive-unified
DATASET=$ROOT/.tools/adaptive-v1-fixed-all11-15r-seed23-20260731T042108/dataset
INITIAL_BASES=$V1_RUN/initial_bases.json
ROLLOUT_RUNNER=$V1_RUN/run_rollouts.py
AUDITOR=$CURRENT_RUN/audit_v2_round.py
PYTHON=$ROOT/.tools/sah-smoke-env/bin/python
MODEL=/data/models/Qwen3.5-9B
TASK_SAFE=${TASK_ID//[^[:alnum:]]/_}
TASK_ROOT=$RUN/tasks/$TASK_SAFE
CAMPAIGN=$TASK_ROOT/campaign
STATE=$CAMPAIGN/adaptive_v2_state.json
TASK_LOG=$TASK_ROOT/campaign.log
TOTAL_ROUNDS=15
K=8
PLATEAU_ROUNDS=1000000000
MAX_EVALS=20

mkdir -p "$CAMPAIGN"

log() {
  printf '[%s] [%s] %s\n' "$(date -Is)" "$TASK_SAFE" "$*" | tee -a "$TASK_LOG"
}

# Keep at most four domains, but route the two not-yet-started follow-on tasks
# to any healthy capacity service. Existing tasks are never restarted or
# migrated. A capacity-model cleanup removes its ready marker, and the endpoint
# check requires the exact original base model before routing away from the
# requested primary port.
REQUESTED_PORT=$PORT
PORT_SOURCE=primary_requested
capacity_endpoint_ready() {
  local gpu=$1 candidate_port=$2
  [ -e "$RUN/capacity_gpu${gpu}.ready" ] || return 1
  "$PYTHON" - "$candidate_port" >/dev/null 2>&1 <<'PY'
import json
import sys
import urllib.request

with urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/v1/models", timeout=2) as response:
    payload = json.load(response)
models = payload.get("data") or []
assert len(models) == 1, payload
assert models[0].get("id") == "Qwen3.5-9B", payload
assert models[0].get("root") == "/data/models/Qwen3.5-9B", payload
PY
}

case "$TASK_ID" in
  eft__ahc_simpletes__ahc058)
    candidate_gpus=(0 1 2 3)
    ;;
  adrs__txn_scheduling)
    candidate_gpus=(1 0 2 3)
    ;;
  *)
    candidate_gpus=()
    ;;
esac
requested_gpu=$((REQUESTED_PORT - 8830))
if [ "$requested_gpu" -ge 0 ] && [ "$requested_gpu" -le 3 ] \
    && capacity_endpoint_ready "$requested_gpu" "$REQUESTED_PORT"; then
  # The capacity manager owns the GPU-to-port assignment.  Respect that
  # verified endpoint first so a task launched for GPU3 cannot silently send
  # all inference to GPU1 and leave its assigned model idle.
  PORT=$REQUESTED_PORT
  PORT_SOURCE="requested_capacity_gpu${requested_gpu}_original_base_ready"
else
  for candidate_gpu in "${candidate_gpus[@]}"; do
    candidate_port=$((8830 + candidate_gpu))
    [ "$candidate_port" != "$REQUESTED_PORT" ] || continue
    if capacity_endpoint_ready "$candidate_gpu" "$candidate_port"; then
      PORT=$candidate_port
      PORT_SOURCE="capacity_gpu${candidate_gpu}_original_base_ready"
      break
    fi
  done
fi
log "ROUTE requested_port=$REQUESTED_PORT selected_port=$PORT source=$PORT_SOURCE domain_cap=4"

# Every future primary/expansion runner uses the same per-task lock.  This lets
# a newly available GPU pull a queued domain forward without ever allowing two
# processes to mutate the same protocol state or round directory concurrently.
TASK_LOCK_DIR=$RUN/task_locks
TASK_LOCK=$TASK_LOCK_DIR/$TASK_SAFE.lock
mkdir -p "$TASK_LOCK_DIR"
exec 9>"$TASK_LOCK"
log "WAIT task_lock=$TASK_LOCK"
flock 9
log "ACQUIRED task_lock=$TASK_LOCK pid=$$"

write_status() {
  "$PYTHON" - "$STATE" "$TASK_ROOT/campaign_status.json" "$TOTAL_ROUNDS" "$TASK_ID" <<'PY'
import json
import sys
from pathlib import Path

state_path, target, total, task_id = sys.argv[1:]
state = json.loads(Path(state_path).read_text()) if Path(state_path).exists() else {}
task = (state.get("tasks") or {}).get(task_id) or {}
controller = task.get("controller") or {}
working = task.get("working") or {}
champion = task.get("champion") or {}
payload = {
    "schema": "sah.adaptive-v2-fixed-task-status/1",
    "task_id": task_id,
    "total_rounds": int(total),
    "pending_training": state.get("pending_training"),
    "collected_rounds": list(task.get("collected_rounds") or []),
    "next_protocol_round": task.get("next_protocol_round"),
    "working_score": working.get("score"),
    "champion_score": champion.get("promotion_score", champion.get("score")),
    "confirmed_record": controller.get("confirmed_record"),
    "plateau_streak": controller.get("rounds_since_confirmed_record"),
    "policy_updates": controller.get("policy_updates", 0),
    "last_training_decision": controller.get("last_training_decision"),
    "last_population_artifact": task.get("last_population_artifact"),
}
Path(target).write_text(json.dumps(payload, indent=2))
PY
}

assert_fixed_policy() {
  "$PYTHON" - "$TASK_ROOT/campaign_status.json" "$PLATEAU_ROUNDS" <<'PY'
import json
import sys

status = json.load(open(sys.argv[1]))
assert status.get("pending_training") is None, status
assert int(status.get("policy_updates", 0)) == 0, status
assert int(status.get("plateau_streak") or 0) < int(sys.argv[2]), status
PY
}

BASES=$INITIAL_BASES
for ROUND in $(seq 0 $((TOTAL_ROUNDS - 1))); do
  ROUND_DIR=$CAMPAIGN/round$(printf '%03d' "$ROUND")
  if [ -e "$ROUND_DIR/v2_audit_complete.json" ]; then
    log "SKIP already audited round=$ROUND"
    BASES=$ROUND_DIR/next_bases.json
    continue
  fi

  mkdir -p "$ROUND_DIR"
  log "START round=$ROUND task=$TASK_ID protocol=adaptive_v2 k=$K no_rl=true"

  if [ ! -e "$ROUND_DIR/round.json" ]; then
    PROPOSE_ARGS=(
      -m outer.outer_round propose
      --round-dir "$ROUND_DIR"
      --round "$ROUND"
      --k "$K"
      --base-url "http://127.0.0.1:$PORT/v1"
      --model Qwen3.5-9B
      --seed 23
      --parallel 4
      --max-evals "$MAX_EVALS"
      --tasks "$TASK_ID"
      --force-tool-frac 0.25
      --protocol adaptive_v2
      --protocol-state "$STATE"
      --protocol-round "$ROUND"
      --total-rounds "$TOTAL_ROUNDS"
      --bases-file "$BASES"
    )
    if [ -f "$CAMPAIGN/best_programs.json" ]; then
      PROPOSE_ARGS+=(--seed-programs-file "$CAMPAIGN/best_programs.json")
    fi
    (
      cd "$REPO/src"
      ADAPTIVE_V1_DATASET_ROOT="$DATASET" \
      ADAPTIVE_TOKENIZER_PATH="$MODEL" \
      PYTHONPATH="$REPO/src" \
      OPENAI_API_KEY=EMPTY \
        "$PYTHON" "${PROPOSE_ARGS[@]}"
    ) 2>&1 | tee "$ROUND_DIR/propose.log"
  else
    log "RESUME retained proposal round=$ROUND"
  fi

  if [ ! -e "$ROUND_DIR/round_summary.json" ]; then
    ROLLOUT_ARGS=(
      "$ROLLOUT_RUNNER"
      "$ROUND_DIR"
      --python "$PYTHON"
      --repo "$REPO"
      --dataset "$DATASET"
      --base-urls "http://127.0.0.1:$PORT/v1"
      --model Qwen3.5-9B
      --seed-base 104729
      --parallel 4
      --max-iters 20
      --max-attempts 2
      --eval-timeout 360
      --eval-timeout-override eft__math__first_autocorr_ineq=1200
      --resume
    )
    if [ -f "$CAMPAIGN/best_programs.json" ]; then
      ROLLOUT_ARGS+=(--seed-programs-file "$CAMPAIGN/best_programs.json")
    fi
    AHC_PIN_CORES=0 AHC_CASE_WORKERS=4 \
      "$PYTHON" "${ROLLOUT_ARGS[@]}" 2>&1 | tee "$ROUND_DIR/rollouts.log"

    (
      cd "$REPO/src"
      ADAPTIVE_V1_DATASET_ROOT="$DATASET" \
      PYTHONPATH="$REPO/src" \
        "$PYTHON" -m outer.outer_round collect \
        --round-dir "$ROUND_DIR" \
        --protocol adaptive_v2 \
        --protocol-state "$STATE" \
        --confidence-z 0 \
        --plateau-rounds "$PLATEAU_ROUNDS"
    ) 2>&1 | tee "$ROUND_DIR/collect.log"
  else
    log "RESUME retained collection round=$ROUND"
  fi

  if [ -e "$ROUND_DIR/adaptive_train_manifest.json" ]; then
    log "FATAL unexpected training manifest despite plateau=$PLATEAU_ROUNDS"
    exit 4
  fi

  (
    cd "$REPO"
    PYTHONPATH="$REPO/src" \
      "$PYTHON" "$AUDITOR" "$ROUND_DIR" --state "$STATE"
  ) 2>&1 | tee "$ROUND_DIR/final_audit.log"

  BASES=$ROUND_DIR/next_bases.json
  write_status
  assert_fixed_policy
  log "STOP round=$ROUND exit=success population_once=true no_rl=true"
done

write_status
assert_fixed_policy
cp "$TASK_ROOT/campaign_status.json" "$TASK_ROOT/final_status.json"
log "COMPLETE rounds=$TOTAL_ROUNDS task=$TASK_ID policy_updates=0"
