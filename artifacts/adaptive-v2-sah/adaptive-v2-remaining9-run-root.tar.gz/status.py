#!/usr/bin/env python3
from __future__ import annotations

import json
import math
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path("/home/nli61/workspace/harness_train")
CURRENT = ROOT / ".tools/adaptive-v2-k8-cp26-prism-15r-seed23-20260731T123059"
RUN = ROOT / ".tools/adaptive-v2-k8-remaining9-15r-seed23-20260801T025500"
REMAINING_TASKS = (
    "eft__math__erdos_min_overlap",
    "eft__math__first_autocorr_ineq",
    "eft__math__second_autocorr_ineq",
    "eft__math__hadamard_maximal_det",
    "eft__ahc_simpletes__ahc039",
    "eft__ahc_simpletes__ahc058",
    "adrs__eplb",
    "adrs__llm_sql",
    "adrs__txn_scheduling",
)


def load(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def lifecycle_state(root: Path) -> str:
    path = root / "lifecycle.jsonl"
    if not path.exists():
        return "not_started"
    events = []
    for line in path.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except Exception:
            continue
    if not events:
        return "not_started"
    last_exit = next((row for row in reversed(events) if row.get("event") == "campaign_exit"), None)
    last_start = next((row for row in reversed(events) if row.get("event") == "campaign_start"), None)
    if last_exit and last_start and last_exit.get("time", "") > last_start.get("time", ""):
        return f"stopped:{last_exit.get('reason', 'unknown')}"
    recent = next(
        (
            row
            for row in reversed(events)
            if row.get("event") in {"progress_heartbeat", "campaign_start", "vllm_ready"}
        ),
        None,
    )
    if recent:
        stamp = datetime.fromisoformat(recent["time"])
        if datetime.now().astimezone() - stamp < timedelta(minutes=15):
            return "running"
    return "unknown"


def recovery_state() -> str:
    path = RUN / "recovery_lifecycle.jsonl"
    if not path.exists():
        return "not_started"
    events = []
    for line in path.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except Exception:
            continue
    if not events:
        return "not_started"
    last_start = next((row for row in reversed(events) if row.get("event") == "campaign_start"), None)
    last_exit = next((row for row in reversed(events) if row.get("event") == "campaign_exit"), None)
    if last_exit and last_start and last_exit.get("time", "") > last_start.get("time", ""):
        return f"stopped:{last_exit.get('reason', 'unknown')}"
    recent = next(
        (row for row in reversed(events) if row.get("event") in {"progress_heartbeat", "vllm_ready", "campaign_start"}),
        None,
    )
    if recent:
        stamp = datetime.fromisoformat(recent["time"])
        if datetime.now().astimezone() - stamp < timedelta(minutes=15):
            return "running"
    return "unknown"


def phase(campaign: Path, round_index: int) -> str:
    root = campaign / f"round{round_index:03d}"
    if (root / "v2_audit_complete.json").exists():
        return "audited"
    if (root / "round_summary.json").exists():
        return "audit"
    progress = root / "rollout_progress.jsonl"
    if progress.exists():
        completed_labels = set()
        for line in progress.read_text().splitlines():
            try:
                row = json.loads(line)
            except Exception:
                continue
            if row.get("event") == "finish" and row.get("exit_code") == 0:
                label = row.get("label")
                if label:
                    completed_labels.add(str(label))
        plan = load(root / "adaptive_rollout_plan.json") or {}
        total = len(plan.get("runs") or [])
        return f"rollout {len(completed_labels)}/{total}"
    if (root / "round.json").exists():
        return "rollout 0/?"
    if root.exists():
        return "analysis/propose"
    return "waiting"


def rollout_details(campaign: Path, round_index: int):
    root = campaign / f"round{round_index:03d}"
    plan = load(root / "adaptive_rollout_plan.json") or {}
    runs = list(plan.get("runs") or [])
    if not runs:
        return []

    latest_event = {}
    progress = root / "rollout_progress.jsonl"
    if progress.exists():
        for line in progress.read_text().splitlines():
            try:
                row = json.loads(line)
            except Exception:
                continue
            label = row.get("label")
            if label:
                latest_event[label] = row

    details = []
    max_evaluations = int(plan.get("max_agent_iterations") or 20)
    for run in runs:
        label = run.get("label")
        event = latest_event.get(label) or {}
        if event.get("event") == "finish" and event.get("exit_code") == 0:
            state = "complete"
        elif event.get("event") == "finish":
            state = "failed_or_retrying"
        elif event.get("event") == "start":
            state = "active"
        else:
            state = "pending"

        checkpoint = None
        output_dir = Path(run.get("output_dir") or "")
        if output_dir.is_absolute():
            checkpoints = sorted(output_dir.glob("*/checkpoints/*.json"))
            if checkpoints:
                checkpoint = checkpoints[-1]
        checkpoint_data = load(checkpoint) if checkpoint else None
        details.append(
            {
                "label": label,
                "state": state,
                "evaluations": int((checkpoint_data or {}).get("evaluations") or 0),
                "max_evaluations": max_evaluations,
                "best_score": (
                    event.get("best_score")
                    if state == "complete"
                    else (checkpoint_data or {}).get("best_score")
                ),
                "checkpoint_updated": (
                    datetime.fromtimestamp(checkpoint.stat().st_mtime)
                    .astimezone()
                    .isoformat(timespec="seconds")
                    if checkpoint
                    else None
                ),
            }
        )
    return details


def best_observed_score(task_id: str, campaign: Path, collected: list[int]):
    """Return the cumulative best absolute score across audited rollouts.

    The population-once controller's ``champion_score`` is a current-frontier
    estimate under the latest shared request seed. It may move down when the
    seed changes even though the matched candidate improved over that round's
    base. Keep that quantity distinct from the best-ever curve requested for
    final reporting.
    """
    values = []
    direction = "higher_is_better"
    for round_index in collected:
        root = campaign / f"round{int(round_index):03d}"
        summary = (load(root / "round_summary.json") or {}).get("groups", {}).get(task_id, {})
        for field in ("base_score_prior", "base_score"):
            value = summary.get(field)
            if value is not None:
                try:
                    value = float(value)
                except (TypeError, ValueError):
                    continue
                if math.isfinite(value):
                    values.append(value)

        population = load(root / "population" / task_id / "population.json") or {}
        direction = population.get("score_direction") or direction
        for member in population.get("members") or []:
            value = (member.get("trace") or {}).get("best_score")
            if value is None:
                continue
            try:
                value = float(value)
            except (TypeError, ValueError):
                continue
            if math.isfinite(value):
                values.append(value)
    if not values:
        return None, direction
    best = min(values) if direction == "lower_is_better" else max(values)
    return best, direction


def task_row(task_id: str, campaign: Path, status_path: Path):
    status = load(status_path) or {}
    status_collected = [int(item) for item in status.get("collected_rounds") or []]
    audited = sorted(
        int(path.parent.name.removeprefix("round"))
        for path in campaign.glob("round[0-9][0-9][0-9]/v2_audit_complete.json")
    )
    # The task runner writes campaign_status only after its inline audit
    # returns. A monitor can repair/replay an audit before the runner resumes,
    # so the immutable audit markers are the authoritative live progress.
    collected = audited if audited else status_collected
    latest = (max(collected) + 1) if collected else 0
    if latest >= int(status.get("total_rounds") or 15):
        latest = 14
        current_phase = "complete"
    else:
        current_phase = phase(campaign, latest)
    observed_best, score_direction = best_observed_score(task_id, campaign, collected)
    latest_summary = {}
    if collected:
        latest_summary = (
            (load(campaign / f"round{max(collected):03d}" / "round_summary.json") or {})
            .get("groups", {})
            .get(task_id, {})
        )
    working_score = latest_summary.get("working_score")
    champion_score = latest_summary.get("champion_score")
    row = {
        "task_id": task_id,
        "collected": len(collected),
        "total": int(status.get("total_rounds") or 15),
        "latest_round": latest,
        "phase": current_phase,
        "working_score": (
            working_score if working_score is not None else status.get("working_score")
        ),
        "champion_score": (
            champion_score if champion_score is not None else status.get("champion_score")
        ),
        "best_observed_score": observed_best,
        "score_direction": score_direction,
        "policy_updates": int(status.get("policy_updates") or 0),
        "pending_training": status.get("pending_training"),
    }
    if current_phase.startswith("rollout"):
        row["rollout_details"] = rollout_details(campaign, latest)
    return row


tasks = {
    "eft__math__circle_packing": task_row(
        "eft__math__circle_packing", CURRENT / "cp26/campaign", CURRENT / "cp26/campaign_status.json"
    ),
    "adrs__prism": task_row(
        "adrs__prism", CURRENT / "prism/campaign", CURRENT / "prism/campaign_status.json"
    ),
}
for task_id in REMAINING_TASKS:
    safe = "".join(ch if ch.isalnum() else "_" for ch in task_id)
    task_root = RUN / "tasks" / safe
    if task_root.exists():
        tasks[task_id] = task_row(
            task_id, task_root / "campaign", task_root / "campaign_status.json"
        )

print(
    json.dumps(
        {
            "schema": "sah.adaptive-v2-all11-live-status/4",
            "current_campaign_state": lifecycle_state(CURRENT),
            "follow_on_armed": (RUN / "follow_on.pid").exists(),
            "remaining_campaign_state": lifecycle_state(RUN),
            "recovery_campaign_state": recovery_state(),
            "tasks": tasks,
            "complete_tasks": sum(row["collected"] == row["total"] for row in tasks.values()),
            "target_tasks": 11,
            "report": str(RUN / "final_report/SUMMARY_CN.md"),
        },
        indent=2,
        ensure_ascii=False,
    )
)
