#!/usr/bin/env bash
set -euo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ADAPTIVE_DIR="$ROOT/scripts/adaptive"

usage() {
  cat <<'EOF'
Adaptive EvoGate v1/v2

Usage:
  ./adaptive.sh setup [core|extended]
  ./adaptive.sh check [core|extended]
  ./adaptive.sh doctor
  ./adaptive.sh validate PROTOCOL [--rounds N] [TASK ...]
  ./adaptive.sh test
  ./adaptive.sh run PROTOCOL TASK SERVING_GPU TRAINING_GPU [SEED [ROUNDS [PORT]]]
  ./adaptive.sh remaining PROTOCOL SERVING_GPU TRAINING_GPU [SEED [ROUNDS [PORT]]]
  ./adaptive.sh cumsum PROTOCOL SERVING_GPU TRAINING_GPU COMPILER_GPU PERF_GPU [SEED [ROUNDS]]
  ./adaptive.sh aime-v2 SERVING_GPU [SEED [ROUNDS [PORT]]]
  ./adaptive.sh aime-v2-scaleup SERVING_GPU [SEED [ROUNDS [PORT]]]
  ./adaptive.sh scores [RUN_ROOT ...] [--json] [--output FILE]

PROTOCOL must be v1 or v2. Run `./adaptive.sh help` for this message.
EOF
}

COMMAND=${1:-help}
case "$COMMAND" in
  help|-h|--help)
    usage
    ;;
  setup)
    if [[ "$#" -gt 2 ]]; then
      usage >&2
      exit 2
    fi
    exec bash "$ADAPTIVE_DIR/setup.sh" "${2:-core}"
    ;;
  check)
    if [[ "$#" -gt 2 ]] ||
       [[ "${2:-core}" != "core" && "${2:-core}" != "extended" ]]; then
      usage >&2
      exit 2
    fi
    if [[ "${2:-core}" == "extended" ]]; then
      exec bash "$ADAPTIVE_DIR/setup.sh" check-extended
    fi
    exec bash "$ADAPTIVE_DIR/setup.sh" check
    ;;
  doctor)
    if [[ "$#" -ne 1 ]]; then
      usage >&2
      exit 2
    fi
    bash "$ADAPTIVE_DIR/setup.sh" check
    bash "$ADAPTIVE_DIR/validate.sh" v1
    bash "$ADAPTIVE_DIR/validate.sh" v2
    exec bash "$ADAPTIVE_DIR/test.sh"
    ;;
  validate)
    shift
    exec bash "$ADAPTIVE_DIR/validate.sh" "$@"
    ;;
  test)
    if [[ "$#" -ne 1 ]]; then
      usage >&2
      exit 2
    fi
    exec bash "$ADAPTIVE_DIR/test.sh"
    ;;
  run)
    shift
    exec bash "$ADAPTIVE_DIR/run_task.sh" "$@"
    ;;
  remaining)
    shift
    exec bash "$ADAPTIVE_DIR/run_remaining.sh" "$@"
    ;;
  cumsum)
    shift
    exec bash "$ADAPTIVE_DIR/run_cumsum.sh" "$@"
    ;;
  aime-v2)
    shift
    exec bash "$ADAPTIVE_DIR/run_aime_v2.sh" "$@"
    ;;
  aime-v2-scaleup)
    shift
    exec bash "$ADAPTIVE_DIR/run_aime_v2_scaleup.sh" "$@"
    ;;
  scores)
    shift
    SCORE_PYTHON=${CAMPAIGN_PYTHON:-"$ROOT/.venv-nexau/bin/python"}
    if [[ ! -x "$SCORE_PYTHON" ]]; then
      echo "missing campaign environment; run: ./adaptive.sh setup core" >&2
      exit 4
    fi
    exec "$SCORE_PYTHON" \
      "$ROOT/evolve_harness/scripts/summarize_adaptive_scores.py" "$@"
    ;;
  *)
    echo "unknown command: $COMMAND" >&2
    usage >&2
    exit 2
    ;;
esac
