# HarnessOpt: discrete whole-harness optimization

HarnessOpt is EvoGate's lightweight, non-parametric baseline for optimizing a
complete agent harness. It generalizes skill-only search without treating a
skill as a special kernel concept: prompts, inference settings, context
compaction, and registered skill or memory profiles are all typed fields on the
same mutable harness component.

HarnessOpt does not train model parameters. A `HarnessActionPolicy` proposes
semantic edits; `HarnessActionCompiler` converts each action into exactly one
bounded `MutationProposal`; `HarnessOptOptimizer.learn()` records verified
transition rewards in a versioned archive. A future RL proposer can implement
the same policy port while storing weights and optimizer state in
`OptimizerState`.

## Action contract

One proposal is one falsifiable intervention and one reward:

```json
{
  "proposal_id": "hopt-r003-s01",
  "axis": "context",
  "hypothesis": "Earlier compaction will prevent repeated stale edits.",
  "expected_effect": "Fewer repeated tool calls at equal or better score.",
  "evidence_ids": ["sha256:..."],
  "edit_atoms": [
    {
      "kind": "set",
      "field": "compaction.threshold",
      "value": 0.72
    }
  ],
  "preserve": ["best-valid restoration"]
}
```

Built-in edit atoms are:

- `set` for declared typed scalar fields;
- `prompt_upsert_section` and `prompt_delete_section` for stable managed prompt
  blocks;
- `profile_add`, `profile_remove`, and `profile_swap` for protected registry
  entries.

The compiler sees only fields exposed through `outer_visibility`. The ordinary
EvoGate capability policy then limits JSON Pointer paths, operations, types,
bounds, and mutation count. Framework-specific invariants remain in a
`candidate_validator`. A `set` atom may use either the declared logical alias
or the exact exposed JSON Pointer (for example, `temperature`,
`llm.temperature`, or `/llm/temperature`).

## Policy choices

`StaticHarnessActionPolicy` is deterministic and useful for tests.
`ModelHarnessActionPolicy` uses any `ModelAdapter` and asks for JSON-only typed
actions. Samples are generated sequentially: each later request sees a compact
summary of earlier valid actions in the same batch and must change the target
or causal mechanism. The optimizer canonicalizes the compiled patch and drops
duplicate executable mutations before evaluation, even when they use different
IDs, aliases, axes, or rationale.

For text edits, `semantic_duplicate_threshold` additionally enables a
lightweight near-duplicate gate. It compares substantive text within the same
executable target and uses overlap coefficient rather than the surrounding
full prompt. Managed prompt section IDs are organizational labels and normalize
to `/system_prompt`, so changing a label cannot disguise a repeated
intervention. Rejected paraphrases are kept in the transcript and participate
in transitive clustering, so a chain of minor rewrites cannot evade the batch
gate. Scalar edits and short strings remain exact-match only. Set the threshold
to `null` to disable this optional policy; the open-ended application uses
`0.50`.

`semantic_archive_window` applies the same gate to recent archived attempts,
preventing a zero-credit or failed intervention from returning a few rounds
later under new prose. The application checks the latest 24 attempts; `0`
disables cross-round filtering. `semantic_archive_threshold` may be set
separately when cross-round paraphrases drift more than same-batch rewrites;
the application uses `0.58`.

Archive operator statistics expose both observed and confidence-adjusted
effects. `raw_mean_reward` preserves score direction;
`mean_learning_reward` subtracts the configured confidence margin and is the
credit used for declaring statistically positive actions. Legacy
`mean_reward` remains an alias for confidence-adjusted credit. When an older
archive is restored, these fields are rebuilt from its retained attempt
records before proposal generation. A positive raw mean with zero learning
credit is exploratory evidence, not a demonstrated improvement.

The proposal transcript records retained proposals, exact duplicates, semantic
duplicates, similarities, compiled target/mutation signatures, and the
normalized semantic target signature. Fewer than the requested number of
candidates is therefore an audited policy-diversity failure rather than
duplicated evidence or learning. Evidence IDs are restricted to
`evidence[*].evidence_id`; unknown IDs are dropped and recorded in the proposal
transcript rather than entering the compiled mutation. Unknown top-level or
edit-atom annotation fields are likewise dropped and audited; the typed
executable fields and the public
`HarnessAction.from_dict` API remain strict. Invalid model outputs are recorded
without crashing the whole round.

`proposal_attempt_multiplier` can cheaply over-sample the outer policy while
keeping the executable candidate quota unchanged. HarnessOpt evaluates only
the first `proposal_count` distinct compiled actions; filtered attempts and
additional distinct `surplus` actions remain audited. The open-ended
application samples up to twice the candidate quota because an extra proposer
call is far cheaper than an inner open-ended rollout. Launcher budget
derivation includes this multiplier.

```python
model = OpenAICompatibleModel(
    base_url="http://127.0.0.1:8000/v1",
    api_key_env=None,
    require_api_key=False,
)
policy = ModelHarnessActionPolicy(
    model=model,
    model_component={"served_model": "Qwen3.5-9B"},
    temperature=0.8,
    max_tokens=2048,
)
optimizer = HarnessOptOptimizer(
    policy=policy,
    proposal_count=3,
    proposal_attempt_multiplier=2,
    semantic_duplicate_threshold=0.50,
    semantic_archive_window=24,
    semantic_archive_threshold=0.58,
)
```

The archive tracks attempts, successful interventions, invalid signatures, and
reward statistics per axis and edit operator. It is deliberately small and
auditable; it is not a learned policy. Attempts keep both the raw paired score
delta and `learning_reward`. With positive `confidence_z`, the latter shrinks
the raw delta by its paired confidence margin; missing uncertainty learns zero.
Only a positive confidence-adjusted reward enters `successful_actions` and
operator reward statistics.

## Stochastic evaluators

Pairing the episode seed controls model sampling but does not make an agent
trajectory deterministic. Tool feedback, generated tool-call IDs, search
programs, and runtimes may all introduce entropy. For such tasks,
`evaluation.repeats` must cover multiple complete inner-agent trajectories.
Evaluators should additionally report `score_sem` for repeated verification of
each final behavior, and configs should set `evaluation.confidence_z`.

Champion promotion then requires:

```text
gain >= max(min_improvement,
            confidence_z * paired_delta_sem)
```

`paired_delta_sem` combines the sample SEM of per-repeat
candidate-minus-baseline trajectory deltas with verifier measurement SEM.
Fingerprint-reused measurements carry shared correlation and cancel when both
sides finalize the same behavior. If pairing is unavailable, EvoGate falls back
to `hypot(baseline_score_sem, candidate_score_sem)`.

The default `confidence_z` is `0`, preserving deterministic and legacy
behavior. When it is positive, missing uncertainty fails closed for champion
promotion; the candidate may still advance the working exploration state.
Selection metadata records the dynamic threshold and paired SEM for every
proposal.

### Cost-aware working exploration

Champion promotion remains score-and-confidence gated. The separate working
frontier can optionally add a resource gate:

```python
AdmissibleFrontierStrategy(
    max_working_cost_ratio=1.2,
    cost_metrics=("tokens", "tool_calls", "wall_seconds"),
    min_costly_working_improvement=0.0,
)
```

EvoGate compares candidate outcome usage against the paired working-baseline
outcome usage. If any configured metric exceeds the ratio and the candidate
does not improve outcome by more than the configured minimum, it is labeled
`resource_regressive` and cannot become the next working state. It may still be
considered independently by the champion rule. With no ratio configured,
`admissible_frontier` preserves its original exploration semantics.

This gate prevents a statistically indistinguishable but score-regressive
candidate from silently increasing iteration/token budgets for every later
round. Ratios, gains, and eligibility are stored in `selection_decided`
metadata.

Repeated evaluation is still insufficient when two harnesses produce exactly
the same final behavior: an independently randomized verifier can give that
same behavior different scores and create a false intervention reward. For
tasks with a sound exact identity, the evaluator should implement
`behavior_fingerprint(task, episode)`. EvoGate then:

- reuses the first verifier result for that split/task/fingerprint tuple;
- records the source episode in the immutable episode record;
- labels outcome and promotion equivalence separately;
- assigns zero dense reward for an outcome-equivalent action;
- advances neither working nor champion on an equivalent comparison.

This is opt-in and fail-open to ordinary evaluation: absent fingerprints never
imply equivalence. The fingerprint must cover everything the verifier observes,
not merely the harness configuration.

## NexAU surface

The first-party NexAU adapter supports this normalized mutable surface:

- system prompt, tool-call mode, iteration and context limits;
- LLM sampling and output-token settings;
- context-compaction strategy, threshold, and retention settings;
- a bounded list of digest-pinned skills or memory profiles.

Registry entries are verified when plugins load and again inside the isolated
NexAU worker. The worker rejects symlinks, manifest changes, hash mismatches,
unknown fields, duplicate skills, and inconsistent agent/compaction context
limits. It materializes registered profiles with `Skill.from_folder` and
replaces the configured `ContextCompactionMiddleware` deterministically.

## Fair comparison with a learned proposer

Use the same inner model, task splits, action schema, visibility, rollout
budget, evaluator, and promotion rule. For same-origin experiments,
`shared_origin_component: model` makes EvoGate verify that the inner model and
the outer proposer's initial model descriptor have identical artifact digests.

The comparison then changes only the outer update rule:

| Method | Proposal policy | `learn()` |
|---|---|---|
| Frozen V7 | frozen model capability | no parameter update |
| HarnessOpt | frozen model plus discrete reward archive | archive/statistics |
| Harness² RL | trainable proposer model | checkpoint/optimizer update |

Keep optimize evidence visible, promotion feedback hidden, and final evaluation
sealed. Fixed-instance tasks without distinct splits can be useful application
studies, but should not be reported as held-out generalization.
