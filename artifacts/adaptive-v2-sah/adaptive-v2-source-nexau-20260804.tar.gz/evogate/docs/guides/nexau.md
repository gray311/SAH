# NexAU adapter

The NexAU adapter targets the public 0.4.x API: `AgentConfig.from_yaml(...)`,
`Agent(config=...)`, and `Agent.run(message=...)`. NexAU is imported only inside
the configured worker environment.

## Execution path

```text
EvoGate → Sandbox.run(JSON request) → nexau_worker.py
        → AgentConfig.from_yaml(protected path)
        → apply bounded model/harness overlay
        → Agent.run(...)
        → normalized result + events + usage
```

## Plugin configuration

| Parameter | Type | Default | Meaning |
|---|---:|---:|---|
| `agent_config` | path | required | Protected NexAU YAML file |
| `python_executable` | path | current Python | Python 3.12 environment containing NexAU |
| `splits` | mapping | required | Split name to JSONL manifest |
| `runs_dir` | path | `nexau-runs` | Fresh per-episode worker directories |
| `api_key_env` | string | `LLM_API_KEY` | Secret environment variable name |
| `passthrough_env` | list | `[]` | Additional explicitly forwarded variables |
| `timeout_seconds` | float | `1800` | Per-worker ceiling, also bounded by inner budget |
| `execution_capabilities` | object | process defaults | Operator assertion about delegated isolation |
| `output_pointer` | JSON Pointer | `/result` | Private evaluator's result location |
| `error_reward` | float | `0` | Reward on worker/output failure |

## Mutable harness fields

The worker rejects unknown top-level fields.

| Field | Mapped NexAU setting |
|---|---|
| `system_prompt` | `AgentConfig.system_prompt` and type `string` |
| `system_prompt_suffix` | `AgentConfig.system_prompt_suffix` |
| `tool_call_mode` | `AgentConfig.tool_call_mode` |
| `max_context_tokens` | `AgentConfig.max_context_tokens` |
| `max_iterations` | `AgentConfig.max_iterations` |
| `timeout` | `AgentConfig.timeout` |
| `llm.temperature` | `LLMConfig.temperature` |
| `llm.max_tokens` | `LLMConfig.max_tokens` |
| `llm.top_p` | `LLMConfig.top_p` |
| `llm.frequency_penalty` | `LLMConfig.frequency_penalty` |
| `llm.presence_penalty` | `LLMConfig.presence_penalty` |
| `llm.stream` | `LLMConfig.stream` |
| `run.context` | `Agent.run(context=...)` overlay |
| `run.state` | `Agent.run(state=...)` |
| `run.config` | `Agent.run(config=...)` |

The protected `model` component overrides `LLMConfig.model`, `base_url`, and
`api_type`. API keys are never accepted from mutable state.

## Example

```bash
export LLM_MODEL=your-model
export LLM_BASE_URL=https://your-provider.example/v1
export LLM_API_KEY=secret

evogate validate examples/nexau_basic/config.json
evogate run examples/nexau_basic/config.json --run-dir runs/nexau
```

The worker charges each completed model call exactly once from
`AfterModelHookInput.model_response.usage` and each completed tool call once
from `after_tool`. `AgentEventsMiddleware` is retained only for the auditable
trace; event duplication cannot change budget accounting.
