from __future__ import annotations

import json
import os
import shutil
import stat
import tempfile
from pathlib import Path
from typing import Any, Iterable

from .canonical import canonical_bytes, digest_bytes, sha256_file
from .types import AgentState, ArtifactRef, Checkpoint, OptimizerState


class ArtifactError(RuntimeError):
    pass


class ArtifactStore:
    """Content-addressed immutable objects plus named state manifests.

    Objects are addressed by SHA-256 and written atomically. Tree artifacts are
    manifests whose files are themselves CAS objects; materialization rejects
    path traversal and verifies every digest.
    """

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root).resolve()
        self.objects = self.root / "objects"
        self.states = self.root / "states"
        self.optimizer_states = self.root / "optimizer-states"
        self.checkpoints = self.root / "checkpoints"
        self.refs = self.root / "refs"
        self.optimizer_refs = self.root / "optimizer-refs"
        self.checkpoint_refs = self.root / "checkpoint-refs"
        for path in (
            self.objects,
            self.states,
            self.optimizer_states,
            self.checkpoints,
            self.refs,
            self.optimizer_refs,
            self.checkpoint_refs,
        ):
            path.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _hex(digest: str) -> str:
        algorithm, separator, value = digest.partition(":")
        if algorithm != "sha256" or not separator or len(value) != 64:
            raise ArtifactError(f"invalid digest: {digest}")
        try:
            int(value, 16)
        except ValueError as exc:
            raise ArtifactError(f"invalid digest: {digest}") from exc
        return value

    def object_path(self, digest: str) -> Path:
        value = self._hex(digest)
        return self.objects / value[:2] / value[2:]

    def put_bytes(
        self, payload: bytes, *, kind: str, media_type: str = "application/octet-stream"
    ) -> ArtifactRef:
        digest = digest_bytes(payload)
        target = self.object_path(digest)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if sha256_file(target) != digest:
                raise ArtifactError(f"CAS collision/corruption at {target}")
        else:
            descriptor, temporary = tempfile.mkstemp(prefix=".cas-", dir=target.parent)
            try:
                with os.fdopen(descriptor, "wb") as handle:
                    handle.write(payload)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.chmod(temporary, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
                os.replace(temporary, target)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        return ArtifactRef(digest=digest, kind=kind, media_type=media_type, size=len(payload))

    def put_json(self, value: Any, *, kind: str) -> ArtifactRef:
        return self.put_bytes(canonical_bytes(value), kind=kind, media_type="application/json")

    def get_bytes(self, ref: ArtifactRef | str) -> bytes:
        digest = ref.digest if isinstance(ref, ArtifactRef) else ref
        path = self.object_path(digest)
        if not path.is_file():
            raise ArtifactError(f"missing object: {digest}")
        payload = path.read_bytes()
        if digest_bytes(payload) != digest:
            raise ArtifactError(f"corrupt object: {digest}")
        return payload

    def get_json(self, ref: ArtifactRef | str) -> Any:
        try:
            return json.loads(self.get_bytes(ref))
        except json.JSONDecodeError as exc:
            raise ArtifactError("artifact is not valid JSON") from exc

    def put_tree(
        self,
        source: Path | str,
        *,
        kind: str,
        exclude: Iterable[str] = (".git", "__pycache__"),
    ) -> ArtifactRef:
        source_path = Path(source).resolve()
        if not source_path.is_dir():
            raise ArtifactError(f"tree source is not a directory: {source_path}")
        blocked = set(exclude)
        entries: list[dict[str, Any]] = []
        for path in sorted(source_path.rglob("*")):
            relative = path.relative_to(source_path)
            if any(part in blocked for part in relative.parts):
                continue
            if path.is_symlink():
                raise ArtifactError(f"symlinks are not accepted in tree artifacts: {relative}")
            if path.is_dir():
                continue
            payload = path.read_bytes()
            file_ref = self.put_bytes(payload, kind="tree.file")
            entries.append(
                {
                    "path": relative.as_posix(),
                    "digest": file_ref.digest,
                    "size": len(payload),
                    "executable": bool(path.stat().st_mode & stat.S_IXUSR),
                }
            )
        return self.put_json(
            {"schema": "evogate.tree/v1", "kind": kind, "entries": entries},
            kind=kind,
        )

    def materialize_tree(self, ref: ArtifactRef, destination: Path | str) -> Path:
        manifest = self.get_json(ref)
        if manifest.get("schema") != "evogate.tree/v1":
            raise ArtifactError("artifact is not an evogate tree")
        destination_path = Path(destination).resolve()
        destination_path.mkdir(parents=True, exist_ok=True)
        for entry in manifest.get("entries", []):
            relative = Path(str(entry["path"]))
            if relative.is_absolute() or ".." in relative.parts:
                raise ArtifactError(f"unsafe tree path: {relative}")
            target = (destination_path / relative).resolve()
            if not target.is_relative_to(destination_path):
                raise ArtifactError(f"tree path escapes destination: {relative}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(self.get_bytes(str(entry["digest"])))
            target.chmod(0o555 if entry.get("executable") else 0o444)
        return destination_path

    def put_state(self, state: AgentState) -> Path:
        target = self.states / f"{self._hex(state.state_id)}.json"
        payload = canonical_bytes(state.to_dict())
        if target.exists():
            if target.read_bytes() != payload:
                raise ArtifactError(f"state id collision: {state.state_id}")
            return target
        descriptor, temporary = tempfile.mkstemp(prefix=".state-", dir=self.states)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return target

    def get_state(self, state_id: str) -> AgentState:
        target = self.states / f"{self._hex(state_id)}.json"
        if not target.is_file():
            raise ArtifactError(f"missing state: {state_id}")
        state = AgentState.from_dict(json.loads(target.read_text(encoding="utf-8")))
        if state.state_id != state_id:
            raise ArtifactError(f"state manifest identity mismatch: {state_id}")
        return state

    def put_optimizer_state(self, state: OptimizerState) -> Path:
        for ref in state.components.values():
            self.get_bytes(ref)
        if state.parent_id is not None:
            self.get_optimizer_state(state.parent_id)
        target = self.optimizer_states / f"{self._hex(state.state_id)}.json"
        payload = canonical_bytes(state.to_dict())
        if target.exists():
            if target.read_bytes() != payload:
                raise ArtifactError(f"optimizer state id collision: {state.state_id}")
            return target
        descriptor, temporary = tempfile.mkstemp(
            prefix=".optimizer-state-", dir=self.optimizer_states
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return target

    def get_optimizer_state(self, state_id: str) -> OptimizerState:
        target = self.optimizer_states / f"{self._hex(state_id)}.json"
        if not target.is_file():
            raise ArtifactError(f"missing optimizer state: {state_id}")
        state = OptimizerState.from_dict(json.loads(target.read_text(encoding="utf-8")))
        if state.state_id != state_id:
            raise ArtifactError(f"optimizer state manifest identity mismatch: {state_id}")
        return state

    def put_checkpoint(self, checkpoint: Checkpoint) -> Path:
        self.get_state(checkpoint.state_id)
        if checkpoint.optimizer_state_id is not None:
            self.get_optimizer_state(checkpoint.optimizer_state_id)
        if checkpoint.parent_checkpoint_id is not None:
            self.get_checkpoint(checkpoint.parent_checkpoint_id)
        for split, ref in checkpoint.evaluations.items():
            summary = self.get_json(ref)
            if summary.get("schema") != "evogate.evaluation-summary/v1":
                raise ArtifactError(
                    f"checkpoint evaluation {split!r} has an unsupported schema"
                )
            if summary.get("state_id") != checkpoint.state_id:
                raise ArtifactError(
                    f"checkpoint evaluation {split!r} belongs to another state"
                )
            if summary.get("split") != split:
                raise ArtifactError(
                    f"checkpoint evaluation {split!r} has a different split label"
                )
            for record in summary.get("record_artifacts", []):
                self.get_json(str(record["digest"]))
        if checkpoint.decision is not None:
            decision = self.get_json(checkpoint.decision)
            if decision.get("schema") != "evogate.candidate-decision/v1":
                raise ArtifactError("checkpoint decision has an unsupported schema")
        target = self.checkpoints / f"{self._hex(checkpoint.checkpoint_id)}.json"
        payload = canonical_bytes(checkpoint.to_dict())
        if target.exists():
            if target.read_bytes() != payload:
                raise ArtifactError(
                    f"checkpoint id collision: {checkpoint.checkpoint_id}"
                )
            return target
        descriptor, temporary = tempfile.mkstemp(prefix=".checkpoint-", dir=self.checkpoints)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return target

    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint:
        target = self.checkpoints / f"{self._hex(checkpoint_id)}.json"
        if not target.is_file():
            raise ArtifactError(f"missing checkpoint: {checkpoint_id}")
        checkpoint = Checkpoint.from_dict(
            json.loads(target.read_text(encoding="utf-8"))
        )
        if checkpoint.checkpoint_id != checkpoint_id:
            raise ArtifactError(
                f"checkpoint manifest identity mismatch: {checkpoint_id}"
            )
        return checkpoint

    @staticmethod
    def _safe_ref(name: str) -> None:
        allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_./"
        if not name or any(character not in allowed for character in name):
            raise ArtifactError(f"unsafe ref name: {name!r}")
        if name.startswith("/") or ".." in Path(name).parts:
            raise ArtifactError(f"unsafe ref name: {name!r}")

    @staticmethod
    def _write_ref(root: Path, name: str, identifier: str) -> None:
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(prefix=".ref-", dir=target.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write(identifier + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def update_ref(self, name: str, state_id: str) -> None:
        self._safe_ref(name)
        self.get_state(state_id)
        self._write_ref(self.refs, name, state_id)

    def read_ref(self, name: str) -> AgentState:
        target = (self.refs / name).resolve()
        if not target.is_relative_to(self.refs.resolve()) or not target.is_file():
            raise ArtifactError(f"missing ref: {name}")
        return self.get_state(target.read_text(encoding="utf-8").strip())

    def update_optimizer_ref(self, name: str, state_id: str) -> None:
        self._safe_ref(name)
        self.get_optimizer_state(state_id)
        self._write_ref(self.optimizer_refs, name, state_id)

    def read_optimizer_ref(self, name: str) -> OptimizerState:
        target = (self.optimizer_refs / name).resolve()
        if not target.is_relative_to(self.optimizer_refs.resolve()) or not target.is_file():
            raise ArtifactError(f"missing optimizer ref: {name}")
        return self.get_optimizer_state(target.read_text(encoding="utf-8").strip())

    def update_checkpoint_ref(self, name: str, checkpoint_id: str) -> None:
        self._safe_ref(name)
        self.get_checkpoint(checkpoint_id)
        self._write_ref(self.checkpoint_refs, name, checkpoint_id)

    def read_checkpoint_ref(self, name: str) -> Checkpoint:
        target = (self.checkpoint_refs / name).resolve()
        if not target.is_relative_to(self.checkpoint_refs.resolve()) or not target.is_file():
            raise ArtifactError(f"missing checkpoint ref: {name}")
        return self.get_checkpoint(target.read_text(encoding="utf-8").strip())

    def resolve_checkpoint(self, value: str) -> Checkpoint:
        if value.startswith("sha256:"):
            return self.get_checkpoint(value)
        return self.read_checkpoint_ref(value)

    def list_checkpoint_refs(self) -> dict[str, str]:
        result: dict[str, str] = {}
        for path in sorted(self.checkpoint_refs.rglob("*")):
            if path.is_file():
                name = path.relative_to(self.checkpoint_refs).as_posix()
                result[name] = path.read_text(encoding="utf-8").strip()
        return result

    def export(self, destination: Path | str) -> Path:
        destination_path = Path(destination).resolve()
        if destination_path.exists():
            raise ArtifactError(f"export destination exists: {destination_path}")
        shutil.copytree(self.root, destination_path)
        return destination_path
