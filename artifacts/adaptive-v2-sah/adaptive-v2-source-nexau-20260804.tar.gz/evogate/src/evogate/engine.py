from __future__ import annotations

import dataclasses
import hashlib
import json
import math
import re
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .artifacts import ArtifactStore
from .budget import BudgetExceeded, BudgetMeter
from .canonical import jsonable
from .ledger import EventLedger
from .optimizers import as_optimizer
from .policy import CapabilityPolicy, PolicyViolation, apply_patch, read_pointer
from .provenance import capture_implementations
from .protocols import PluginSet, TrainingRequest
from .sandbox import check_isolation, effective_inner_capabilities
from .strategies import ScoreDeltaReward, strategy_from_name
from .types import (
    AgentState,
    ArtifactRef,
    BudgetUsage,
    CandidateAssessment,
    CandidateDecision,
    Checkpoint,
    EpisodeResult,
    EvaluationResult,
    ExperimentSpec,
    MutationProposal,
    OptimizerState,
    OptimizerTransition,
    OuterContext,
    ProposalBatch,
    SelectionContext,
    TaskCase,
)


class EvolutionError(RuntimeError):
    pass


@dataclass(frozen=True)
class EvaluationBatch:
    split: str
    state_id: str
    score: float
    records: tuple[Mapping[str, Any], ...]
    artifact_refs: tuple[ArtifactRef, ...]
    usage: BudgetUsage
    integrity_flags: tuple[str, ...] = ()
    summary_ref: ArtifactRef | None = None

    def objective_score(self, statistic: str, *, maximize: bool) -> float:
        """Return the preregistered scalar objective for this batch.

        ``best`` is appropriate for open-ended discovery budgets where the
        product of a harness is its strongest valid solution.  The stored
        mean remains available as ``score`` for reliability diagnostics.
        """

        if statistic == "mean":
            return self.score
        if statistic != "best":
            raise ValueError(f"unknown evaluation statistic: {statistic!r}")
        rewards = [float(record["reward"]) for record in self.records]
        if not rewards:
            raise ValueError("cannot compute best score for an empty batch")
        return max(rewards) if maximize else min(rewards)

    def objective_sem(self, statistic: str) -> float | None:
        # A max/min order statistic is deliberately not assigned the SEM of
        # the mean. Promotion remains mean-based when confidence gates matter.
        return self.score_sem if statistic == "mean" else None

    @staticmethod
    def _record_score_sem(record: Mapping[str, Any]) -> float | None:
        metrics = record.get("metrics", {})
        if not isinstance(metrics, Mapping):
            return None
        value = metrics.get("score_sem")
        if (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(float(value))
            or float(value) < 0
        ):
            return None
        return float(value)

    @property
    def rollout_repeats(self) -> int:
        repeats = {
            int(record["repeat"])
            for record in self.records
            if isinstance(record.get("repeat"), int)
            and not isinstance(record.get("repeat"), bool)
        }
        return len(repeats)

    @property
    def rollout_score_sample_std(self) -> float | None:
        grouped: dict[int, list[float]] = {}
        for record in self.records:
            repeat = record.get("repeat")
            if not isinstance(repeat, int) or isinstance(repeat, bool):
                return None
            grouped.setdefault(repeat, []).append(float(record["reward"]))
        if len(grouped) < 2:
            return None
        repeat_means = [
            statistics.fmean(grouped[repeat]) for repeat in sorted(grouped)
        ]
        return statistics.stdev(repeat_means)

    @property
    def rollout_score_sem(self) -> float | None:
        sample_std = self.rollout_score_sample_std
        if sample_std is None:
            return None
        return sample_std / math.sqrt(self.rollout_repeats)

    @property
    def measurement_score_sem(self) -> float | None:
        """Verifier uncertainty, preserving cache-induced correlations.

        Repeated agent rollouts that finalize the same behavior reuse one
        verifier result. Their measurement errors are therefore correlated and
        must be weighted as one shared observation rather than as independent
        samples.
        """

        if not self.records:
            return None
        count = len(self.records)
        weights: dict[tuple[Any, ...], float] = {}
        standard_errors: dict[tuple[Any, ...], float | None] = {}
        for index, record in enumerate(self.records):
            fingerprint = record.get("behavior_fingerprint")
            key: tuple[Any, ...]
            if isinstance(fingerprint, str) and fingerprint:
                key = ("behavior", record.get("task_id"), fingerprint)
            else:
                key = ("record", index)
            weights[key] = weights.get(key, 0.0) + 1.0 / count
            value = self._record_score_sem(record)
            previous = standard_errors.get(key)
            standard_errors[key] = (
                value
                if previous is None
                else previous
                if value is None
                else max(previous, value)
            )
        variance = 0.0
        for key, weight in weights.items():
            value = standard_errors.get(key)
            if value is None:
                return None
            variance += (weight * value) ** 2
        return math.sqrt(variance)

    @property
    def score_sem(self) -> float | None:
        rollout = self.rollout_score_sem
        measurement = self.measurement_score_sem
        if rollout is None:
            return measurement
        if measurement is None:
            return rollout
        return math.hypot(rollout, measurement)

    @property
    def behavior_fingerprints(self) -> tuple[str, ...] | None:
        if not self.records:
            return None
        fingerprints: list[str] = []
        for record in self.records:
            value = record.get("behavior_fingerprint")
            if not isinstance(value, str) or not value:
                return None
            fingerprints.append(value)
        return tuple(fingerprints)

    def summary(
        self,
        *,
        include_records: bool = False,
        include_artifact_refs: bool = False,
    ) -> dict[str, Any]:
        rewards = [float(record["reward"]) for record in self.records]
        result = {
            "schema": "evogate.evaluation-summary/v1",
            "split": self.split,
            "state_id": self.state_id,
            "score": self.score,
            "count": len(rewards),
            "median_reward": statistics.median(rewards) if rewards else 0.0,
            "min_reward": min(rewards) if rewards else 0.0,
            "max_reward": max(rewards) if rewards else 0.0,
            "usage": jsonable(self.usage),
            "integrity_flags": list(self.integrity_flags),
        }
        if self.score_sem is not None:
            result["score_sem"] = self.score_sem
        result["rollout_repeats"] = self.rollout_repeats
        if self.rollout_score_sample_std is not None:
            result["rollout_score_sample_std"] = (
                self.rollout_score_sample_std
            )
        if self.rollout_score_sem is not None:
            result["rollout_score_sem"] = self.rollout_score_sem
        if self.measurement_score_sem is not None:
            result["measurement_score_sem"] = self.measurement_score_sem
        if self.behavior_fingerprints is not None:
            result["behavior_fingerprints"] = list(
                self.behavior_fingerprints
            )
        if include_records:
            result["records"] = list(self.records)
        if include_artifact_refs:
            result["record_artifacts"] = [
                jsonable(ref) for ref in self.artifact_refs
            ]
        return result


@dataclass(frozen=True)
class PairedDeltaUncertainty:
    total_sem: float | None
    rollout_sem: float | None
    measurement_sem: float | None
    paired_records: int
    paired_repeats: int


def paired_delta_uncertainty(
    candidate: EvaluationBatch,
    baseline: EvaluationBatch,
) -> PairedDeltaUncertainty:
    """Uncertainty of the paired candidate-minus-baseline mean.

    Agent rollouts are paired by ``episode_key``. Verifier measurement error
    cancels exactly when both sides finalize the same fingerprint and otherwise
    retains the correct cache-induced correlation weight.
    """

    candidate_by_key = {
        str(record.get("episode_key")): record
        for record in candidate.records
        if record.get("episode_key") is not None
    }
    baseline_by_key = {
        str(record.get("episode_key")): record
        for record in baseline.records
        if record.get("episode_key") is not None
    }
    if (
        not candidate_by_key
        or set(candidate_by_key) != set(baseline_by_key)
        or len(candidate_by_key) != len(candidate.records)
        or len(baseline_by_key) != len(baseline.records)
    ):
        return PairedDeltaUncertainty(None, None, None, 0, 0)

    grouped_deltas: dict[int, list[float]] = {}
    for key in sorted(candidate_by_key):
        candidate_record = candidate_by_key[key]
        baseline_record = baseline_by_key[key]
        candidate_repeat = candidate_record.get("repeat")
        baseline_repeat = baseline_record.get("repeat")
        if (
            not isinstance(candidate_repeat, int)
            or isinstance(candidate_repeat, bool)
            or candidate_repeat != baseline_repeat
        ):
            return PairedDeltaUncertainty(
                None, None, None, len(candidate_by_key), 0
            )
        grouped_deltas.setdefault(candidate_repeat, []).append(
            float(candidate_record["reward"])
            - float(baseline_record["reward"])
        )
    repeat_deltas = [
        statistics.fmean(grouped_deltas[repeat])
        for repeat in sorted(grouped_deltas)
    ]
    rollout_sem = (
        statistics.stdev(repeat_deltas) / math.sqrt(len(repeat_deltas))
        if len(repeat_deltas) >= 2
        else None
    )

    record_count = len(candidate_by_key)
    weights: dict[tuple[Any, ...], float] = {}
    standard_errors: dict[tuple[Any, ...], float | None] = {}
    for side, sign, records in (
        ("candidate", 1.0, candidate_by_key),
        ("baseline", -1.0, baseline_by_key),
    ):
        for episode_key, record in records.items():
            fingerprint = record.get("behavior_fingerprint")
            if isinstance(fingerprint, str) and fingerprint:
                measurement_key: tuple[Any, ...] = (
                    "behavior",
                    record.get("task_id"),
                    fingerprint,
                )
            else:
                measurement_key = (side, episode_key)
            weights[measurement_key] = (
                weights.get(measurement_key, 0.0) + sign / record_count
            )
            value = EvaluationBatch._record_score_sem(record)
            previous = standard_errors.get(measurement_key)
            standard_errors[measurement_key] = (
                value
                if previous is None
                else previous
                if value is None
                else max(previous, value)
            )
    measurement_variance = 0.0
    measurement_available = True
    for key, weight in weights.items():
        if abs(weight) <= 1e-15:
            continue
        value = standard_errors.get(key)
        if value is None:
            measurement_available = False
            break
        measurement_variance += (weight * value) ** 2
    measurement_sem = (
        math.sqrt(measurement_variance)
        if measurement_available
        else None
    )
    if rollout_sem is None:
        total_sem = measurement_sem
    elif measurement_sem is None:
        total_sem = rollout_sem
    else:
        total_sem = math.hypot(rollout_sem, measurement_sem)
    return PairedDeltaUncertainty(
        total_sem=total_sem,
        rollout_sem=rollout_sem,
        measurement_sem=measurement_sem,
        paired_records=record_count,
        paired_repeats=len(repeat_deltas),
    )


@dataclass(frozen=True)
class RunResult:
    experiment_id: str
    initial_state_id: str
    initial_checkpoint_id: str
    final_state_id: str
    final_checkpoint_id: str
    decisions: tuple[CandidateDecision, ...]
    final_evaluations: Mapping[str, Mapping[str, Any]]
    run_dir: Path
    ledger_head: str
    initial_optimizer_state_id: str = ""
    final_working_state_id: str = ""
    final_optimizer_state_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        return jsonable(self)


@dataclass
class _Candidate:
    proposal: MutationProposal
    state: AgentState | None = None
    outcome_batch: EvaluationBatch | None = None
    promotion_batch: EvaluationBatch | None = None
    assessment: CandidateAssessment | None = None
    rejection: CandidateDecision | None = None
    checkpoint: Checkpoint | None = None


class EvolutionEngine:
    """Frozen-baseline, transactional bilevel evolution orchestrator."""

    def __init__(
        self,
        *,
        spec: ExperimentSpec,
        plugins: PluginSet,
        run_dir: Path | str,
        initial_components: Mapping[str, Any],
        initial_provenance: Mapping[str, Any] | None = None,
        initial_optimizer_state: OptimizerState | None = None,
        initial_optimizer_objects: Mapping[str, bytes] | None = None,
    ) -> None:
        self.spec = spec
        self.plugins = plugins
        self.run_dir = Path(run_dir).resolve()
        if self.run_dir.exists() and any(self.run_dir.iterdir()):
            raise EvolutionError(f"run directory is not empty: {self.run_dir}")
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.store = ArtifactStore(self.run_dir / "artifacts")
        self.ledger = EventLedger(self.run_dir / "events.jsonl")
        self.policy = CapabilityPolicy.from_dict(spec.capabilities)
        self.optimizer = as_optimizer(plugins.outer, plugins.optimizer)
        self.strategy = plugins.strategy or strategy_from_name(
            spec.evolution_strategy
        )
        self.reward = plugins.reward or ScoreDeltaReward()
        self._behavior_evaluation_cache: dict[
            tuple[str, str, str], tuple[EvaluationResult, ArtifactRef]
        ] = {}
        self.meters = {
            name: BudgetMeter(name, limit) for name, limit in spec.budgets.items()
        }
        for required in ("inner", "outer", "training"):
            if required not in self.meters:
                raise EvolutionError(f"missing required budget namespace: {required}")
        launcher_capabilities = dict(plugins.sandbox.capabilities())
        inner_capabilities = effective_inner_capabilities(plugins.inner, plugins.sandbox)
        failures = check_isolation(inner_capabilities, spec.isolation)
        outer_capabilities_method = getattr(self.optimizer, "capabilities", None)
        outer_capabilities = (
            dict(outer_capabilities_method()) if callable(outer_capabilities_method) else {}
        )
        if spec.isolation.outer_isolation_required and not outer_capabilities.get("isolated"):
            failures.append("outer system is in-process or its isolation is undeclared")
        if failures:
            raise EvolutionError("isolation preflight failed: " + "; ".join(failures))
        component_refs = {
            name: self.store.put_json(value, kind=name) for name, value in initial_components.items()
        }
        self.initial_state = AgentState(
            components=component_refs,
            metadata={
                "experiment_id": spec.experiment_id,
                "generation": 0,
                **(
                    {"restored_from": dict(initial_provenance)}
                    if initial_provenance
                    else {}
                ),
            },
        )
        self.store.put_state(self.initial_state)
        self.store.update_ref("initial", self.initial_state.state_id)
        self.store.update_ref("latest", self.initial_state.state_id)
        self.store.update_ref("working", self.initial_state.state_id)
        self.store.update_ref("champion", self.initial_state.state_id)
        if initial_optimizer_state is None:
            self.optimizer_state = self.optimizer.initialize(
                store=self.store, budget=self.meters["outer"]
            )
        else:
            objects = dict(initial_optimizer_objects or {})
            restored_components: dict[str, ArtifactRef] = {}
            for name, ref in initial_optimizer_state.components.items():
                payload = objects.get(ref.digest)
                if payload is None:
                    raise EvolutionError(
                        f"missing restored optimizer object {ref.digest}"
                    )
                restored = self.store.put_bytes(
                    payload,
                    kind=ref.kind,
                    media_type=ref.media_type,
                )
                if restored.digest != ref.digest:
                    raise EvolutionError(
                        f"restored optimizer object digest mismatch for {name!r}"
                    )
                restored_components[name] = restored
            self.optimizer_state = OptimizerState(
                components=restored_components,
                step=initial_optimizer_state.step,
                metadata={
                    **dict(initial_optimizer_state.metadata),
                    "restored_from_optimizer_state_id": (
                        initial_optimizer_state.state_id
                    ),
                },
            )
        self.store.put_optimizer_state(self.optimizer_state)
        if spec.shared_origin_component is not None:
            component = spec.shared_origin_component
            inner_ref = self.initial_state.components.get(component)
            outer_ref = self.optimizer_state.components.get(component)
            if inner_ref is None or outer_ref is None:
                raise EvolutionError(
                    f"shared origin component {component!r} must exist in both "
                    "inner and optimizer states"
                )
            if inner_ref.digest != outer_ref.digest:
                raise EvolutionError(
                    f"shared origin component {component!r} has different digests"
                )
        self.store.update_optimizer_ref("initial", self.optimizer_state.state_id)
        self.store.update_optimizer_ref("latest", self.optimizer_state.state_id)
        self.initial_checkpoint = Checkpoint(
            state_id=self.initial_state.state_id,
            kind="initial",
            label="initial",
            optimizer_state_id=self.optimizer_state.state_id,
            metadata=dict(initial_provenance or {}),
        )
        self.store.put_checkpoint(self.initial_checkpoint)
        self.store.update_checkpoint_ref(
            "initial", self.initial_checkpoint.checkpoint_id
        )
        self.store.update_checkpoint_ref(
            "latest", self.initial_checkpoint.checkpoint_id
        )
        self.current_checkpoint_id = self.initial_checkpoint.checkpoint_id
        self._final_evaluated: set[str] = set()
        self._history: list[dict[str, Any]] = []
        self._decisions: list[CandidateDecision] = []
        implementation_provenance = capture_implementations(
            self.store,
            {
                "tasks": plugins.tasks,
                "inner": plugins.inner,
                "evaluator": plugins.evaluator,
                "outer": plugins.outer,
                "optimizer": self.optimizer,
                "strategy": self.strategy,
                "reward": self.reward,
                "sandbox": plugins.sandbox,
                "trainer": plugins.trainer,
                "candidate_validator": plugins.candidate_validator,
            },
        )
        manifest = {
            "schema": "evogate.run-manifest/v1",
            "experiment": jsonable(spec),
            "initial_state_id": self.initial_state.state_id,
            "initial_checkpoint_id": self.initial_checkpoint.checkpoint_id,
            "initial_optimizer_state_id": self.optimizer_state.state_id,
            "initial_provenance": dict(initial_provenance or {}),
            "plugins": jsonable(plugins.metadata),
            "implementations": implementation_provenance,
            "launcher": launcher_capabilities,
            "inner_execution": inner_capabilities,
            "outer_execution": outer_capabilities
            or {"isolated": False, "mode": "in-process-or-undeclared"},
        }
        manifest_ref = self.store.put_json(manifest, kind="run.manifest")
        (self.run_dir / "manifest.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        self.ledger.append(
            "run_started",
            {
                "experiment_id": spec.experiment_id,
                "initial_state_id": self.initial_state.state_id,
                "initial_checkpoint_id": self.initial_checkpoint.checkpoint_id,
                "initial_optimizer_state_id": self.optimizer_state.state_id,
                "manifest": manifest_ref,
                "contract": self.policy.public_contract(),
                "launcher": launcher_capabilities,
                "inner_execution": inner_capabilities,
                "outer_execution": outer_capabilities or {"isolated": False, "mode": "in-process"},
                "metadata": spec.metadata,
            },
        )
        self.ledger.append(
            "checkpoint_created",
            {
                "checkpoint_id": self.initial_checkpoint.checkpoint_id,
                "state_id": self.initial_state.state_id,
                "kind": "initial",
                "label": "initial",
                "evaluations": {},
                "decision": None,
                "optimizer_state_id": self.optimizer_state.state_id,
                "refs": ["initial", "latest"],
            },
        )

    def _components(self, state: AgentState) -> dict[str, Any]:
        return {name: self.store.get_json(ref) for name, ref in state.components.items()}

    @staticmethod
    def _ref_segment(value: str) -> str:
        normalized = re.sub(r"[^A-Za-z0-9_-]+", "-", value).strip("-")
        return (normalized or "candidate")[:48]

    def _checkpoint(
        self,
        *,
        state: AgentState,
        kind: str,
        label: str,
        evaluations: Mapping[str, EvaluationBatch] | None = None,
        parent_checkpoint_id: str | None = None,
        decision: ArtifactRef | None = None,
        metadata: Mapping[str, Any] | None = None,
        optimizer_state: OptimizerState | None = None,
        refs: Sequence[str] = (),
    ) -> Checkpoint:
        batches = dict(evaluations or {})
        if any(batch.summary_ref is None for batch in batches.values()):
            raise EvolutionError("checkpoint evaluation is missing its summary artifact")
        checkpoint = Checkpoint(
            state_id=state.state_id,
            kind=kind,
            label=label,
            evaluations={
                split: batch.summary_ref
                for split, batch in batches.items()
                if batch.summary_ref is not None
            },
            parent_checkpoint_id=parent_checkpoint_id,
            decision=decision,
            optimizer_state_id=(
                optimizer_state.state_id if optimizer_state is not None else None
            ),
            metadata=dict(metadata or {}),
        )
        self.store.put_checkpoint(checkpoint)
        for name in refs:
            self.store.update_checkpoint_ref(name, checkpoint.checkpoint_id)
        self.ledger.append(
            "checkpoint_created",
            {
                "checkpoint_id": checkpoint.checkpoint_id,
                "state_id": checkpoint.state_id,
                "kind": kind,
                "label": label,
                "parent_checkpoint_id": parent_checkpoint_id,
                "evaluations": checkpoint.evaluations,
                "decision": decision,
                "optimizer_state_id": checkpoint.optimizer_state_id,
                "refs": list(refs),
            },
        )
        return checkpoint

    @staticmethod
    def _delta_usage(after: BudgetUsage, before: BudgetUsage) -> BudgetUsage:
        values = {
            item.name: max(0, getattr(after, item.name) - getattr(before, item.name))
            for item in dataclasses.fields(BudgetUsage)
        }
        return BudgetUsage(**values)

    @staticmethod
    def _missing_usage(reported: BudgetUsage, observed: BudgetUsage) -> BudgetUsage:
        values = {
            item.name: max(0, getattr(reported, item.name) - getattr(observed, item.name))
            for item in dataclasses.fields(BudgetUsage)
        }
        return BudgetUsage(**values)

    @staticmethod
    def _integrity_flags(result: EvaluationResult, episode: EpisodeResult) -> list[str]:
        flags: list[str] = []
        if episode.error:
            flags.append(f"episode_error:{episode.error}")
        integrity = result.integrity
        for key in (
            "reward_hacking",
            "verifier_tampering",
            "protected_state_changed",
            "data_leakage",
            "sandbox_escape",
        ):
            if integrity.get(key):
                flags.append(key)
        if integrity.get("status") in {"fail", "failed", "violation"}:
            flags.append(f"integrity_status:{integrity['status']}")
        return flags

    def evaluate_state(self, state: AgentState, split: str, *, final: bool = False) -> EvaluationBatch:
        protocol = self.spec.evaluation
        if split in protocol.final_splits:
            if not final:
                raise EvolutionError(f"final split {split!r} cannot be used for selection")
            if protocol.evaluate_final_once and split in self._final_evaluated:
                raise EvolutionError(f"final split {split!r} has already been evaluated")
            self._final_evaluated.add(split)
        tasks = tuple(self.plugins.tasks.cases(split))
        if not tasks:
            raise EvolutionError(f"task source returned no cases for split {split!r}")
        meter = self.meters["inner"]
        components = self._components(state)
        start_usage = meter.usage
        records: list[dict[str, Any]] = []
        refs: list[ArtifactRef] = []
        flags: set[str] = set()
        paired_jobs: list[tuple[int, TaskCase]] = []
        for repeat in range(protocol.repeats):
            for task in tasks:
                episode_key = f"{split}:{task.task_id}:{repeat}"
                seed_material = f"{protocol.seed}:{episode_key}".encode("utf-8")
                episode_seed = int.from_bytes(
                    hashlib.sha256(seed_material).digest()[:8], "big"
                )
                paired_jobs.append(
                    (
                        repeat,
                        dataclasses.replace(
                            task,
                            seed=episode_seed,
                            episode_key=episode_key,
                            metadata={
                                **dict(task.metadata),
                                "evogate_episode": {
                                    "key": episode_key,
                                    "seed": episode_seed,
                                    "repeat": repeat,
                                },
                            },
                        ),
                    )
                )
        parallelism = max(
            1, int(getattr(self.plugins.inner, "max_parallel_episodes", 1))
        )
        parallel_episodes: dict[str, EpisodeResult] = {}
        if parallelism > 1 and len(paired_jobs) > 1:
            for _repeat, _task in paired_jobs:
                meter.ensure_episode_available()

            def run_parallel(paired_task: TaskCase) -> EpisodeResult:
                return self.plugins.inner.run(
                    state=state,
                    components=components,
                    task=paired_task,
                    sandbox=self.plugins.sandbox,
                    budget=meter,
                )

            futures = {}
            with ThreadPoolExecutor(
                max_workers=min(parallelism, len(paired_jobs))
            ) as pool:
                for _repeat, paired_task in paired_jobs:
                    future = pool.submit(run_parallel, paired_task)
                    futures[future] = str(paired_task.episode_key)
                for future in as_completed(futures):
                    parallel_episodes[futures[future]] = future.result()
        for repeat in range(protocol.repeats):
            for task in tasks:
                episode_key = f"{split}:{task.task_id}:{repeat}"
                seed_material = f"{protocol.seed}:{episode_key}".encode("utf-8")
                episode_seed = int.from_bytes(
                    hashlib.sha256(seed_material).digest()[:8], "big"
                )
                paired_task = next(
                    paired
                    for job_repeat, paired in paired_jobs
                    if job_repeat == repeat
                    and paired.episode_key == episode_key
                )
                if parallel_episodes:
                    episode = parallel_episodes[episode_key]
                else:
                    meter.ensure_episode_available()
                    before = meter.usage
                    started = time.monotonic()
                    try:
                        episode = self.plugins.inner.run(
                            state=state,
                            components=components,
                            task=paired_task,
                            sandbox=self.plugins.sandbox,
                            budget=meter,
                        )
                    finally:
                        elapsed = time.monotonic() - started
                        observed = self._delta_usage(meter.usage, before)
                        if observed.wall_seconds < elapsed:
                            meter.consume(
                                BudgetUsage(
                                    wall_seconds=elapsed - observed.wall_seconds
                                )
                            )
                    observed = self._delta_usage(meter.usage, before)
                    meter.consume(
                        self._missing_usage(episode.usage, observed)
                    )
                behavior_fingerprint: str | None = None
                fingerprinter = getattr(
                    self.plugins.evaluator, "behavior_fingerprint", None
                )
                if callable(fingerprinter):
                    behavior_fingerprint = fingerprinter(
                        task=paired_task,
                        episode=episode,
                    )
                    if behavior_fingerprint is not None and (
                        not isinstance(behavior_fingerprint, str)
                        or not behavior_fingerprint
                    ):
                        raise EvolutionError(
                            "evaluator behavior_fingerprint must return "
                            "a non-empty string or None"
                        )
                evaluation_cache_key = (
                    (split, task.task_id, behavior_fingerprint)
                    if behavior_fingerprint is not None
                    else None
                )
                reused_evaluation = (
                    self._behavior_evaluation_cache.get(evaluation_cache_key)
                    if evaluation_cache_key is not None
                    else None
                )
                evaluation_started = time.monotonic()
                if reused_evaluation is None:
                    evaluation = self.plugins.evaluator.evaluate(
                        task=paired_task,
                        episode=episode,
                        sandbox=self.plugins.sandbox,
                    )
                    evaluation_source_ref = None
                else:
                    evaluation, evaluation_source_ref = reused_evaluation
                evaluation_elapsed = time.monotonic() - evaluation_started
                if evaluation_elapsed > 0:
                    meter.consume(
                        BudgetUsage(wall_seconds=evaluation_elapsed)
                    )
                record_flags = self._integrity_flags(evaluation, episode)
                flags.update(record_flags)
                record = {
                    "schema": "evogate.episode-record/v1",
                    "task_id": task.task_id,
                    "task_input": paired_task.input,
                    "split": split,
                    "repeat": repeat,
                    "episode_key": episode_key,
                    "seed": episode_seed,
                    "state_id": state.state_id,
                    "output": episode.output,
                    "trace": list(episode.trace),
                    "usage": episode.usage,
                    "error": episode.error,
                    "reward": evaluation.reward,
                    "metrics": evaluation.metrics,
                    "integrity": evaluation.integrity,
                    "feedback": evaluation.feedback,
                    "integrity_flags": record_flags,
                    "behavior_fingerprint": behavior_fingerprint,
                    "evaluation_reuse": {
                        "reused": evaluation_source_ref is not None,
                        "source_record": evaluation_source_ref,
                    },
                }
                ref = self.store.put_json(record, kind="episode.record")
                if (
                    evaluation_cache_key is not None
                    and reused_evaluation is None
                ):
                    self._behavior_evaluation_cache[
                        evaluation_cache_key
                    ] = (evaluation, ref)
                refs.append(ref)
                records.append(jsonable(record))
                self.ledger.append(
                    "episode_finished",
                    {
                        "task_id": task.task_id,
                        "split": split,
                        "repeat": repeat,
                        "episode_key": episode_key,
                        "seed": episode_seed,
                        "state_id": state.state_id,
                        "record": ref,
                        "behavior_fingerprint": behavior_fingerprint,
                        "evaluation_reused": (
                            evaluation_source_ref is not None
                        ),
                        "sealed": split in protocol.final_splits,
                    },
                )
        score = statistics.fmean(float(record["reward"]) for record in records)
        usage = self._delta_usage(meter.usage, start_usage)
        batch = EvaluationBatch(
            split=split,
            state_id=state.state_id,
            score=score,
            records=tuple(records),
            artifact_refs=tuple(refs),
            usage=usage,
            integrity_flags=tuple(sorted(flags)),
        )
        summary_ref = self.store.put_json(
            batch.summary(include_artifact_refs=True), kind="evaluation.summary"
        )
        batch = dataclasses.replace(batch, summary_ref=summary_ref)
        self.ledger.append(
            "evaluation_finished",
            {
                "split": split,
                "state_id": state.state_id,
                "score": score,
                "summary": summary_ref,
                "sealed": split in protocol.final_splits,
            },
        )
        return batch

    def _outer_context(
        self, round_index: int, state: AgentState, train: EvaluationBatch
    ) -> OuterContext:
        components = self._components(state)
        visible_components: dict[str, Any] = {}
        for name, paths in self.spec.outer_visibility.items():
            value = components[name]
            visible_components[name] = {
                pointer: read_pointer(value, pointer) for pointer in paths
            }
        evidence: list[Mapping[str, Any]] = []
        if self.spec.evaluation.reveal_train_traces:
            for record, ref in zip(train.records, train.artifact_refs, strict=True):
                evidence.append(
                    {
                        "evidence_id": ref.digest,
                        "task_id": record["task_id"],
                        "task_input": record.get("task_input"),
                        "reward": record["reward"],
                        "metrics": record["metrics"],
                        "feedback": record["feedback"],
                        "output": record["output"],
                        "trace": record["trace"],
                    }
                )
        return OuterContext(
            experiment_id=self.spec.experiment_id,
            round_index=round_index,
            state=state,
            component_views=visible_components,
            train_summary=train.summary(include_records=False),
            history=(
                tuple(self._history)
                if self.spec.evaluation.reveal_selection_feedback
                else ()
            ),
            capability_contract=self.policy.public_contract(),
            evidence=tuple(evidence),
        )

    def _apply_proposal(
        self,
        *,
        baseline: AgentState,
        proposal: MutationProposal,
        proposal_ref: ArtifactRef,
        trajectory_refs: Sequence[ArtifactRef],
        round_index: int,
    ) -> AgentState:
        self.policy.validate(proposal)
        component_values = self._components(baseline)
        component_refs = dict(baseline.components)
        train_operations = []
        for mutation in proposal.mutations:
            if mutation.surface == "model.train":
                train_operations.extend(mutation.operations)
                continue
            if mutation.surface == "model":
                raise PolicyViolation(("direct model mutation is forbidden; use model.train",))
            if mutation.surface not in component_values:
                raise EvolutionError(f"state has no component {mutation.surface!r}")
            updated = apply_patch(component_values[mutation.surface], mutation.operations)
            component_values[mutation.surface] = updated
            component_refs[mutation.surface] = self.store.put_json(
                updated, kind=mutation.surface
            )
        if train_operations:
            if self.plugins.trainer is None:
                raise EvolutionError("proposal requests model.train but no trainer is configured")
            recipe = component_values.get("training_recipe", {})
            updated_recipe = apply_patch(recipe, train_operations)
            component_values["training_recipe"] = updated_recipe
            component_refs["training_recipe"] = self.store.put_json(
                updated_recipe, kind="training_recipe"
            )
            training_root = self.run_dir / "training"
            training_root.mkdir(exist_ok=True)
            output_dir = training_root / f"round-{round_index:03d}-{proposal.proposal_id}"
            request = TrainingRequest(
                base_model=baseline.components["model"],
                base_model_value=component_values["model"],
                recipe=updated_recipe,
                trajectory_refs=tuple(trajectory_refs),
                output_dir=output_dir,
                metadata={"proposal_id": proposal.proposal_id, "round": round_index},
            )
            training_meter = self.meters["training"]
            training_before = training_meter.usage
            training_started = time.monotonic()
            try:
                result = self.plugins.trainer.train(
                    request=request,
                    store=self.store,
                    sandbox=self.plugins.sandbox,
                    budget=training_meter,
                )
            finally:
                elapsed = time.monotonic() - training_started
                observed = self._delta_usage(training_meter.usage, training_before)
                floor = BudgetUsage(wall_seconds=elapsed, training_seconds=elapsed)
                training_meter.consume(self._missing_usage(floor, observed))
            if isinstance(result.usage, BudgetUsage):
                observed = self._delta_usage(training_meter.usage, training_before)
                training_meter.consume(self._missing_usage(result.usage, observed))
            if result.model is None:
                if result.model_value is None:
                    raise EvolutionError("trainer returned neither model nor model_value")
                component_refs["model"] = self.store.put_json(result.model_value, kind="model")
            else:
                component_refs["model"] = result.model
            self.ledger.append(
                "training_finished",
                {
                    "round": round_index,
                    "proposal_id": proposal.proposal_id,
                    "base_model": baseline.components["model"],
                    "new_model": component_refs["model"],
                    "metrics": result.metrics,
                    "logs": result.logs,
                    "gpu_cleanup_status": "recorded_in_lifecycle_logs" if result.logs else "plugin_report_unavailable",
                },
            )
        state = AgentState(
            components=component_refs,
            parent_id=baseline.state_id,
            metadata={
                "experiment_id": self.spec.experiment_id,
                "generation": round_index + 1,
                "proposal_id": proposal.proposal_id,
                "actor": proposal.actor,
            },
        )
        if self.plugins.candidate_validator is not None:
            self.plugins.candidate_validator.validate(
                baseline=baseline,
                candidate=state,
                proposal=proposal,
                components=self._components(state),
            )
        self.store.put_state(state)
        self.ledger.append(
            "candidate_built",
            {
                "round": round_index,
                "proposal_id": proposal.proposal_id,
                "proposal": proposal_ref,
                "baseline_state_id": baseline.state_id,
                "candidate_state_id": state.state_id,
                "components": state.components,
            },
        )
        return state

    def _improvement(self, baseline: float, candidate: float) -> float:
        return candidate - baseline if self.spec.evaluation.maximize else baseline - candidate

    def _stop_reached(self, score: float) -> bool:
        target = self.spec.evaluation.stop_score
        if target is None:
            return False
        return score >= target if self.spec.evaluation.maximize else score <= target

    def run(self) -> RunResult:
        working = self.initial_state
        champion = self.initial_state
        try:
            for round_index in range(self.spec.rounds):
                self.ledger.append(
                    "round_started",
                    {
                        "round": round_index,
                        "working_state_id": working.state_id,
                        "champion_state_id": champion.state_id,
                        "optimizer_state_id": self.optimizer_state.state_id,
                    },
                )
                evaluation_cache: dict[tuple[str, str], EvaluationBatch] = {}

                def evaluate_cached(state: AgentState, split: str) -> EvaluationBatch:
                    key = (state.state_id, split)
                    if key not in evaluation_cache:
                        evaluation_cache[key] = self.evaluate_state(state, split)
                    return evaluation_cache[key]

                protocol = self.spec.evaluation

                def outcome_score(batch: EvaluationBatch) -> float:
                    return batch.objective_score(
                        protocol.outcome_statistic,
                        maximize=protocol.maximize,
                    )

                def promotion_score(batch: EvaluationBatch) -> float:
                    return batch.objective_score(
                        protocol.promotion_statistic,
                        maximize=protocol.maximize,
                    )

                evidence = evaluate_cached(working, protocol.update_split)
                outcome_baseline = evaluate_cached(
                    working, protocol.effective_outcome_split
                )
                working_promotion = evaluate_cached(
                    working, protocol.effective_promotion_split
                )
                champion_promotion = evaluate_cached(
                    champion, protocol.effective_promotion_split
                )
                round_root = f"rounds/{round_index:03d}"
                working_batches = {
                    batch.split: batch
                    for batch in (evidence, outcome_baseline, working_promotion)
                }
                baseline_checkpoint = self._checkpoint(
                    state=working,
                    kind="baseline",
                    label=f"round-{round_index:03d}-baseline",
                    evaluations=working_batches,
                    parent_checkpoint_id=self.current_checkpoint_id,
                    optimizer_state=self.optimizer_state,
                    metadata={
                        "round": round_index,
                        "working_state_id": working.state_id,
                        "champion_state_id": champion.state_id,
                        "champion_score": promotion_score(
                            champion_promotion
                        ),
                        "outcome_statistic": protocol.outcome_statistic,
                        "promotion_statistic": (
                            protocol.promotion_statistic
                        ),
                    },
                    refs=(f"{round_root}/baseline",),
                )
                if self._stop_reached(
                    promotion_score(champion_promotion)
                ):
                    retained = self._checkpoint(
                        state=champion,
                        kind="retained",
                        label=f"round-{round_index:03d}-early-stop",
                        evaluations={champion_promotion.split: champion_promotion},
                        parent_checkpoint_id=baseline_checkpoint.checkpoint_id,
                        optimizer_state=self.optimizer_state,
                        metadata={"round": round_index, "early_stop": True},
                        refs=(f"{round_root}/promoted", "latest"),
                    )
                    self.current_checkpoint_id = retained.checkpoint_id
                    self.ledger.append(
                        "early_stop", {
                            "round": round_index,
                            "score": promotion_score(
                                champion_promotion
                            ),
                            "reason": "target",
                        },
                    )
                    break
                context = self._outer_context(round_index, working, evidence)
                context_ref = self.store.put_json(
                    {
                        "schema": "evogate.outer-context/v1",
                        **jsonable(context),
                    },
                    kind="outer.context",
                )
                before_outer = self.meters["outer"].usage
                outer_started = time.monotonic()
                try:
                    proposal_batch = self.optimizer.propose(
                        context=context,
                        state=self.optimizer_state,
                        store=self.store,
                        budget=self.meters["outer"],
                    )
                finally:
                    outer_elapsed = time.monotonic() - outer_started
                    outer_observed = self._delta_usage(
                        self.meters["outer"].usage, before_outer
                    )
                    if outer_observed.wall_seconds < outer_elapsed:
                        self.meters["outer"].consume(
                            BudgetUsage(
                                wall_seconds=outer_elapsed - outer_observed.wall_seconds
                            )
                        )
                if not isinstance(proposal_batch, ProposalBatch):
                    raise EvolutionError("optimizer.propose must return ProposalBatch")
                proposals = tuple(proposal_batch.proposals)
                if len({proposal.proposal_id for proposal in proposals}) != len(proposals):
                    raise EvolutionError("outer system returned duplicate proposal IDs")
                if len(proposals) > self.spec.max_proposals_per_round:
                    raise EvolutionError(
                        f"outer system returned {len(proposals)} proposals; maximum is "
                        f"{self.spec.max_proposals_per_round}"
                    )
                unknown_actions = set(proposal_batch.actions) - {
                    proposal.proposal_id for proposal in proposals
                }
                if unknown_actions:
                    raise EvolutionError(
                        "proposal batch has actions for unknown proposals: "
                        f"{sorted(unknown_actions)}"
                    )
                for ref in proposal_batch.artifacts:
                    self.store.get_bytes(ref)
                proposal_refs = {
                    proposal.proposal_id: self.store.put_json(
                        {
                            "schema": "evogate.mutation-proposal/v1",
                            **jsonable(proposal),
                        },
                        kind="mutation.proposal",
                    )
                    for proposal in proposals
                }
                self.ledger.append(
                    "proposals_received",
                    {
                        "round": round_index,
                        "count": len(proposals),
                        "proposal_ids": [item.proposal_id for item in proposals],
                        "proposals": [
                            proposal_refs[item.proposal_id] for item in proposals
                        ],
                        "context": context_ref,
                        "optimizer_state_id": self.optimizer_state.state_id,
                        "batch_metadata": proposal_batch.metadata,
                        "batch_artifacts": proposal_batch.artifacts,
                        "outer_usage": self._delta_usage(
                            self.meters["outer"].usage, before_outer
                        ),
                    },
                )
                candidates: list[_Candidate] = []
                for proposal in proposals:
                    candidate = _Candidate(proposal=proposal)
                    try:
                        state = self._apply_proposal(
                            baseline=working,
                            proposal=proposal,
                            proposal_ref=proposal_refs[proposal.proposal_id],
                            trajectory_refs=evidence.artifact_refs,
                            round_index=round_index,
                        )
                        outcome_batch = evaluate_cached(
                            state, protocol.effective_outcome_split
                        )
                        candidate.state = state
                        candidate.outcome_batch = outcome_batch
                    except PolicyViolation as exc:
                        candidate.rejection = CandidateDecision(
                            proposal_id=proposal.proposal_id,
                            accepted=False,
                            reason="policy_violation",
                            baseline_score=promotion_score(
                                champion_promotion
                            ),
                            policy_violations=exc.violations,
                        )
                    except (BudgetExceeded, EvolutionError, RuntimeError, ValueError) as exc:
                        candidate.rejection = CandidateDecision(
                            proposal_id=proposal.proposal_id,
                            accepted=False,
                            reason=f"candidate_failed:{type(exc).__name__}:{exc}",
                            baseline_score=promotion_score(
                                champion_promotion
                            ),
                        )
                    candidates.append(candidate)
                promotion_candidates = [
                    candidate
                    for candidate in candidates
                    if (
                        candidate.rejection is None
                        and candidate.state is not None
                        and candidate.outcome_batch is not None
                        and not candidate.outcome_batch.integrity_flags
                    )
                ]
                promotion_candidates.sort(
                    key=lambda candidate: (
                        outcome_score(candidate.outcome_batch),
                        candidate.proposal.proposal_id,
                    ),
                    reverse=protocol.maximize,
                )
                if protocol.promotion_top_k is not None:
                    promotion_candidates = promotion_candidates[
                        : protocol.promotion_top_k
                    ]
                promotion_ids = {
                    candidate.proposal.proposal_id
                    for candidate in promotion_candidates
                }
                self.ledger.append(
                    "promotion_shortlist_decided",
                    {
                        "round": round_index,
                        "promotion_top_k": protocol.promotion_top_k,
                        "outcome_statistic": protocol.outcome_statistic,
                        "proposal_ids": [
                            candidate.proposal.proposal_id
                            for candidate in promotion_candidates
                        ],
                        "outcome_scores": {
                            candidate.proposal.proposal_id: outcome_score(
                                candidate.outcome_batch
                            )
                            for candidate in promotion_candidates
                        },
                    },
                )
                for candidate in promotion_candidates:
                    try:
                        candidate.promotion_batch = evaluate_cached(
                            candidate.state,
                            protocol.effective_promotion_split,
                        )
                    except (
                        BudgetExceeded,
                        EvolutionError,
                        RuntimeError,
                        ValueError,
                    ) as exc:
                        self.ledger.append(
                            "promotion_evaluation_failed",
                            {
                                "round": round_index,
                                "proposal_id": (
                                    candidate.proposal.proposal_id
                                ),
                                "error": (
                                    f"{type(exc).__name__}:{exc}"
                                ),
                            },
                        )
                for candidate in candidates:
                    integrity_flags = tuple(
                        sorted(
                            set(
                                (
                                    candidate.outcome_batch.integrity_flags
                                    if candidate.outcome_batch
                                    else ()
                                )
                                + (
                                    candidate.promotion_batch.integrity_flags
                                    if candidate.promotion_batch
                                    else ()
                                )
                            )
                        )
                    )
                    outcome_fingerprints = (
                        candidate.outcome_batch.behavior_fingerprints
                        if candidate.outcome_batch
                        else None
                    )
                    promotion_fingerprints = (
                        candidate.promotion_batch.behavior_fingerprints
                        if candidate.promotion_batch
                        else None
                    )
                    outcome_baseline_fingerprints = (
                        outcome_baseline.behavior_fingerprints
                    )
                    champion_fingerprints = (
                        champion_promotion.behavior_fingerprints
                    )
                    outcome_delta_uncertainty = (
                        paired_delta_uncertainty(
                            candidate.outcome_batch,
                            outcome_baseline,
                        )
                        if candidate.outcome_batch
                        else PairedDeltaUncertainty(
                            None, None, None, 0, 0
                        )
                    )
                    promotion_delta_uncertainty = (
                        paired_delta_uncertainty(
                            candidate.promotion_batch,
                            champion_promotion,
                        )
                        if candidate.promotion_batch
                        else PairedDeltaUncertainty(
                            None, None, None, 0, 0
                        )
                    )
                    candidate.assessment = CandidateAssessment(
                        proposal_id=candidate.proposal.proposal_id,
                        candidate_state_id=(
                            candidate.state.state_id if candidate.state else None
                        ),
                        outcome_score=(
                            outcome_score(candidate.outcome_batch)
                            if candidate.outcome_batch
                            else None
                        ),
                        promotion_score=(
                            promotion_score(candidate.promotion_batch)
                            if candidate.promotion_batch
                            else None
                        ),
                        outcome_score_sem=(
                            candidate.outcome_batch.objective_sem(
                                protocol.outcome_statistic
                            )
                            if candidate.outcome_batch
                            else None
                        ),
                        promotion_score_sem=(
                            candidate.promotion_batch.objective_sem(
                                protocol.promotion_statistic
                            )
                            if candidate.promotion_batch
                            else None
                        ),
                        outcome_delta_sem=(
                            outcome_delta_uncertainty.total_sem
                            if protocol.outcome_statistic == "mean"
                            else None
                        ),
                        promotion_delta_sem=(
                            promotion_delta_uncertainty.total_sem
                        ),
                        outcome_behavior_fingerprints=(
                            outcome_fingerprints or ()
                        ),
                        promotion_behavior_fingerprints=(
                            promotion_fingerprints or ()
                        ),
                        outcome_behavior_equivalent=(
                            outcome_fingerprints is not None
                            and outcome_baseline_fingerprints is not None
                            and outcome_fingerprints
                            == outcome_baseline_fingerprints
                        ),
                        promotion_behavior_equivalent=(
                            promotion_fingerprints is not None
                            and champion_fingerprints is not None
                            and promotion_fingerprints
                            == champion_fingerprints
                        ),
                        outcome_usage=(
                            jsonable(candidate.outcome_batch.usage)
                            if candidate.outcome_batch
                            else {}
                        ),
                        promotion_usage=(
                            jsonable(candidate.promotion_batch.usage)
                            if candidate.promotion_batch
                            else {}
                        ),
                        integrity_flags=integrity_flags,
                        failure_reason=(
                            candidate.rejection.reason
                            if candidate.rejection
                            else None
                        ),
                    )
                selection = self.strategy.select(
                    context=SelectionContext(
                        round_index=round_index,
                        working_state_id=working.state_id,
                        champion_state_id=champion.state_id,
                        working_score=outcome_score(outcome_baseline),
                        champion_score=promotion_score(
                            champion_promotion
                        ),
                        candidates=tuple(
                            candidate.assessment
                            for candidate in candidates
                            if candidate.assessment is not None
                        ),
                        min_improvement=protocol.min_improvement,
                        maximize=protocol.maximize,
                        working_score_sem=outcome_baseline.objective_sem(
                            protocol.outcome_statistic
                        ),
                        champion_score_sem=(
                            champion_promotion.objective_sem(
                                protocol.promotion_statistic
                            )
                        ),
                        confidence_z=protocol.confidence_z,
                        working_usage=jsonable(outcome_baseline.usage),
                        history=tuple(self._history),
                        has_future_round=(
                            round_index + 1 < self.spec.rounds
                            or protocol.advance_working_on_final_round
                        ),
                    )
                )
                by_proposal = {
                    candidate.proposal.proposal_id: candidate
                    for candidate in candidates
                }
                selected_working = by_proposal.get(
                    selection.working_proposal_id
                )
                if (
                    selection.working_proposal_id is not None
                    and (
                        selected_working is None
                        or selected_working.assessment is None
                        or not selected_working.assessment.outcome_admissible
                    )
                ):
                    raise EvolutionError(
                        "strategy selected outcome-inadmissible working "
                        f"proposal {selection.working_proposal_id!r}"
                    )
                selected_champion = by_proposal.get(
                    selection.champion_proposal_id
                )
                if (
                    selection.champion_proposal_id is not None
                    and (
                        selected_champion is None
                        or selected_champion.assessment is None
                        or not selected_champion.assessment.promotion_admissible
                    )
                ):
                    raise EvolutionError(
                        "strategy selected promotion-inadmissible champion "
                        f"proposal {selection.champion_proposal_id!r}"
                    )
                self.ledger.append(
                    "selection_decided",
                    {
                        "round": round_index,
                        "working_proposal_id": selection.working_proposal_id,
                        "champion_proposal_id": selection.champion_proposal_id,
                        "metadata": selection.metadata,
                    },
                )
                round_decisions: list[CandidateDecision] = []
                transitions: list[OptimizerTransition] = []
                for candidate_index, candidate in enumerate(candidates):
                    if candidate.rejection:
                        decision = candidate.rejection
                    elif (
                        candidate.assessment is None
                        or candidate.outcome_batch is None
                        or candidate.state is None
                    ):
                        decision = CandidateDecision(
                            proposal_id=candidate.proposal.proposal_id,
                            accepted=False,
                            reason="candidate_missing",
                            baseline_score=promotion_score(
                                champion_promotion
                            ),
                        )
                    elif candidate.assessment.integrity_flags:
                        decision = CandidateDecision(
                            proposal_id=candidate.proposal.proposal_id,
                            accepted=False,
                            reason="integrity_gate",
                            baseline_score=promotion_score(
                                champion_promotion
                            ),
                            candidate_score=(
                                promotion_score(
                                    candidate.promotion_batch
                                )
                                if candidate.promotion_batch
                                else outcome_score(
                                    candidate.outcome_batch
                                )
                            ),
                            candidate_state_id=candidate.state.state_id,
                            integrity_flags=candidate.assessment.integrity_flags,
                        )
                    else:
                        decision = CandidateDecision(
                            proposal_id=candidate.proposal.proposal_id,
                            accepted=(
                                candidate.proposal.proposal_id
                                == selection.champion_proposal_id
                            ),
                            reason=selection.reasons.get(
                                candidate.proposal.proposal_id,
                                "strategy_not_selected",
                            ),
                            baseline_score=promotion_score(
                                champion_promotion
                            ),
                            candidate_score=(
                                promotion_score(
                                    candidate.promotion_batch
                                )
                                if candidate.promotion_batch
                                else outcome_score(
                                    candidate.outcome_batch
                                )
                            ),
                            candidate_state_id=candidate.state.state_id,
                        )
                    round_decisions.append(decision)
                    self._decisions.append(decision)
                    decision_ref = self.store.put_json(
                        {
                            "schema": "evogate.candidate-decision/v1",
                            **jsonable(decision),
                        },
                        kind="candidate.decision",
                    )
                    if (
                        candidate.state is not None
                        and candidate.outcome_batch is not None
                    ):
                        segment = self._ref_segment(candidate.proposal.proposal_id)
                        checkpoint_batches = [
                            candidate.outcome_batch
                        ]
                        if candidate.promotion_batch is not None:
                            checkpoint_batches.append(
                                candidate.promotion_batch
                            )
                        candidate_batches = {
                            batch.split: batch
                            for batch in checkpoint_batches
                        }
                        candidate_refs = [
                            f"{round_root}/candidates/{candidate_index:03d}-{segment}"
                        ]
                        if (
                            candidate.proposal.proposal_id
                            == selection.working_proposal_id
                        ):
                            candidate_refs.append(f"{round_root}/working")
                        if (
                            candidate.proposal.proposal_id
                            == selection.champion_proposal_id
                        ):
                            candidate_refs.append(f"{round_root}/champion")
                        candidate.checkpoint = self._checkpoint(
                            state=candidate.state,
                            kind="candidate",
                            label=candidate.proposal.proposal_id,
                            evaluations=candidate_batches,
                            parent_checkpoint_id=baseline_checkpoint.checkpoint_id,
                            decision=decision_ref,
                            optimizer_state=self.optimizer_state,
                            metadata={
                                "round": round_index,
                                "proposal_id": candidate.proposal.proposal_id,
                                "accepted": decision.accepted,
                                "working": (
                                    candidate.proposal.proposal_id
                                    == selection.working_proposal_id
                                ),
                                "promotion_shortlisted": (
                                    candidate.proposal.proposal_id
                                    in promotion_ids
                                ),
                            },
                            refs=tuple(candidate_refs),
                        )
                    self.ledger.append("candidate_decided", jsonable(decision))
                    assessment = candidate.assessment
                    if assessment is None:
                        raise EvolutionError("candidate assessment was not created")
                    promotion_visible = (
                        protocol.reveal_selection_feedback
                    )
                    learning_assessment = (
                        assessment
                        if promotion_visible
                        else dataclasses.replace(
                            assessment,
                            promotion_score=None,
                            promotion_score_sem=None,
                            promotion_delta_sem=None,
                            promotion_behavior_fingerprints=(),
                            promotion_behavior_equivalent=False,
                        )
                    )
                    learning_decision = (
                        decision
                        if promotion_visible
                        else CandidateDecision(
                            proposal_id=decision.proposal_id,
                            accepted=False,
                            reason="promotion_hidden",
                            candidate_state_id=decision.candidate_state_id,
                            policy_violations=decision.policy_violations,
                            integrity_flags=decision.integrity_flags,
                        )
                    )
                    reward = self.reward.score(
                        assessment=learning_assessment,
                        decision=learning_decision,
                        outcome_baseline=outcome_score(
                            outcome_baseline
                        ),
                        promotion_baseline=(
                            promotion_score(champion_promotion)
                            if promotion_visible
                            else 0.0
                        ),
                        maximize=protocol.maximize,
                    )
                    transition = OptimizerTransition(
                        round_index=round_index,
                        context=context,
                        proposal=candidate.proposal,
                        action=dict(
                            proposal_batch.actions.get(
                                candidate.proposal.proposal_id, {}
                            )
                        ),
                        assessment=learning_assessment,
                        decision=learning_decision,
                        reward=reward,
                        proposal_ref=proposal_refs[
                            candidate.proposal.proposal_id
                        ],
                        outcome_ref=(
                            candidate.outcome_batch.summary_ref
                            if candidate.outcome_batch
                            else None
                        ),
                        promotion_ref=(
                            candidate.promotion_batch.summary_ref
                            if candidate.promotion_batch
                            and promotion_visible
                            else None
                        ),
                        metadata={
                            "promotion_visible": promotion_visible,
                            "confidence_z": protocol.confidence_z,
                            "outcome_statistic": (
                                protocol.outcome_statistic
                            ),
                            "promotion_statistic": (
                                protocol.promotion_statistic
                            ),
                            "outcome_behavior_equivalent": (
                                assessment.outcome_behavior_equivalent
                            ),
                            "promotion_behavior_equivalent": (
                                assessment.promotion_behavior_equivalent
                                if promotion_visible
                                else None
                            ),
                        },
                    )
                    transition_ref = self.store.put_json(
                        {
                            "schema": "evogate.optimizer-transition/v1",
                            **jsonable(transition),
                        },
                        kind="optimizer.transition",
                    )
                    transitions.append(transition)
                    self.ledger.append(
                        "optimizer_transition",
                        {
                            "round": round_index,
                            "proposal_id": candidate.proposal.proposal_id,
                            "reward": reward.total,
                            "transition": transition_ref,
                        },
                    )
                previous_optimizer_state = self.optimizer_state
                learn_before = self.meters["outer"].usage
                learn_started = time.monotonic()
                try:
                    learn_with_training = getattr(
                        self.optimizer, "learn_with_training", None
                    )
                    if callable(learn_with_training):
                        learned_state = learn_with_training(
                            state=previous_optimizer_state,
                            transitions=tuple(transitions),
                            store=self.store,
                            outer_budget=self.meters["outer"],
                            training_budget=self.meters["training"],
                            run_dir=self.run_dir,
                        )
                    else:
                        learned_state = self.optimizer.learn(
                            state=previous_optimizer_state,
                            transitions=tuple(transitions),
                            store=self.store,
                            budget=self.meters["outer"],
                        )
                finally:
                    learn_elapsed = time.monotonic() - learn_started
                    learn_observed = self._delta_usage(
                        self.meters["outer"].usage, learn_before
                    )
                    if learn_observed.wall_seconds < learn_elapsed:
                        self.meters["outer"].consume(
                            BudgetUsage(
                                wall_seconds=learn_elapsed
                                - learn_observed.wall_seconds
                            )
                        )
                if not isinstance(learned_state, OptimizerState):
                    raise EvolutionError(
                        "optimizer.learn must return OptimizerState"
                    )
                if learned_state.state_id != previous_optimizer_state.state_id:
                    if learned_state.parent_id != previous_optimizer_state.state_id:
                        raise EvolutionError(
                            "updated optimizer state must name its previous state as parent"
                        )
                    if learned_state.step <= previous_optimizer_state.step:
                        raise EvolutionError(
                            "updated optimizer state must advance its step"
                        )
                self.store.put_optimizer_state(learned_state)
                self.optimizer_state = learned_state
                self.store.update_optimizer_ref(
                    "latest", self.optimizer_state.state_id
                )
                self.ledger.append(
                    "optimizer_updated",
                    {
                        "round": round_index,
                        "previous_optimizer_state_id": (
                            previous_optimizer_state.state_id
                        ),
                        "optimizer_state_id": self.optimizer_state.state_id,
                        "transition_count": len(transitions),
                    },
                )
                working_candidate = (
                    by_proposal.get(selection.working_proposal_id)
                    if selection.working_proposal_id
                    else None
                )
                champion_candidate = (
                    by_proposal.get(selection.champion_proposal_id)
                    if selection.champion_proposal_id
                    else None
                )
                if working_candidate is not None and working_candidate.state is not None:
                    working = working_candidate.state
                if champion_candidate is not None and champion_candidate.state is not None:
                    champion = champion_candidate.state
                self.store.update_ref("working", working.state_id)
                self.store.update_ref("champion", champion.state_id)
                self.store.update_ref("latest", champion.state_id)
                if working_candidate is None:
                    self.store.update_checkpoint_ref(
                        f"{round_root}/working", baseline_checkpoint.checkpoint_id
                    )
                if champion_candidate is None:
                    self.store.update_checkpoint_ref(
                        f"{round_root}/champion", self.current_checkpoint_id
                    )
                promoted_parent = (
                    champion_candidate.checkpoint.checkpoint_id
                    if (
                        champion_candidate is not None
                        and champion_candidate.checkpoint is not None
                    )
                    else baseline_checkpoint.checkpoint_id
                )
                promoted_batch = (
                    champion_candidate.promotion_batch
                    if champion_candidate is not None
                    else champion_promotion
                )
                if promoted_batch is None:
                    raise EvolutionError("champion is missing promotion evaluation")
                promoted_checkpoint = self._checkpoint(
                    state=champion,
                    kind=(
                        "promoted"
                        if champion_candidate is not None
                        else "retained"
                    ),
                    label=f"round-{round_index:03d}-promoted",
                    evaluations={promoted_batch.split: promoted_batch},
                    parent_checkpoint_id=promoted_parent,
                    optimizer_state=self.optimizer_state,
                    metadata={
                        "round": round_index,
                        "champion_proposal_id": selection.champion_proposal_id,
                        "working_proposal_id": selection.working_proposal_id,
                        "working_state_id": working.state_id,
                        "strategy": selection.metadata,
                    },
                    refs=(f"{round_root}/promoted", "latest"),
                )
                self.current_checkpoint_id = promoted_checkpoint.checkpoint_id
                self._history.append(
                    {
                        "round": round_index,
                        "baseline_state_id": champion_promotion.state_id,
                        "baseline_score": promotion_score(
                            champion_promotion
                        ),
                        "baseline_score_sem": (
                            champion_promotion.objective_sem(
                                protocol.promotion_statistic
                            )
                        ),
                        "outcome_statistic": (
                            protocol.outcome_statistic
                        ),
                        "promotion_statistic": (
                            protocol.promotion_statistic
                        ),
                        "working_state_id": working.state_id,
                        "champion_state_id": champion.state_id,
                        "optimizer_state_id": self.optimizer_state.state_id,
                        "decisions": [jsonable(item) for item in round_decisions],
                    }
                )
                self.ledger.append(
                    "round_finished",
                    {
                        "round": round_index,
                        "working_state_id": working.state_id,
                        "champion_state_id": champion.state_id,
                        "champion_promoted": champion_candidate is not None,
                    },
                )
            final_evaluations: dict[str, Mapping[str, Any]] = {}
            final_batches: dict[str, EvaluationBatch] = {}
            for split in self.spec.evaluation.final_splits:
                batch = self.evaluate_state(champion, split, final=True)
                final_batches[split] = batch
                final_summary = batch.summary(
                    include_records=self.spec.evaluation.reveal_selection_details
                )
                final_summary["objective_statistic"] = (
                    self.spec.evaluation.final_statistic
                )
                final_summary["objective_score"] = batch.objective_score(
                    self.spec.evaluation.final_statistic,
                    maximize=self.spec.evaluation.maximize,
                )
                final_evaluations[split] = final_summary
            self.store.update_ref("final", champion.state_id)
            self.store.update_optimizer_ref("final", self.optimizer_state.state_id)
            final_checkpoint = self._checkpoint(
                state=champion,
                kind="final",
                label="final",
                evaluations=final_batches,
                parent_checkpoint_id=self.current_checkpoint_id,
                optimizer_state=self.optimizer_state,
                metadata={"sealed": True},
                refs=("final", "latest"),
            )
            completion = self.ledger.append(
                "run_finished",
                {
                    "experiment_id": self.spec.experiment_id,
                    "final_state_id": champion.state_id,
                    "final_working_state_id": working.state_id,
                    "final_optimizer_state_id": self.optimizer_state.state_id,
                    "final_checkpoint_id": final_checkpoint.checkpoint_id,
                    "final_evaluations": final_evaluations,
                    "budgets": {
                        name: jsonable(meter.snapshot()) for name, meter in self.meters.items()
                    },
                },
            )
            result = RunResult(
                experiment_id=self.spec.experiment_id,
                initial_state_id=self.initial_state.state_id,
                initial_checkpoint_id=self.initial_checkpoint.checkpoint_id,
                initial_optimizer_state_id=(
                    self.initial_checkpoint.optimizer_state_id or ""
                ),
                final_state_id=champion.state_id,
                final_working_state_id=working.state_id,
                final_checkpoint_id=final_checkpoint.checkpoint_id,
                final_optimizer_state_id=self.optimizer_state.state_id,
                decisions=tuple(self._decisions),
                final_evaluations=final_evaluations,
                run_dir=self.run_dir,
                ledger_head=completion["event_hash"],
            )
            (self.run_dir / "summary.json").write_text(
                json.dumps(result.to_dict(), indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            return result
        except BaseException as exc:
            self.ledger.append(
                "run_failed", {"type": type(exc).__name__, "reason": str(exc)[:4000]}
            )
            raise
