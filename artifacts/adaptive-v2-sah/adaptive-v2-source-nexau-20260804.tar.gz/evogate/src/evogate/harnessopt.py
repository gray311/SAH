from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field, replace
from typing import Any, Callable, Mapping, Protocol, Sequence

from .artifacts import ArtifactStore
from .budget import BudgetMeter
from .canonical import digest_json, jsonable
from .protocols import ModelAdapter
from .types import (
    ArtifactRef,
    ModelRequest,
    Mutation,
    MutationOp,
    MutationProposal,
    OptimizerState,
    OptimizerTransition,
    OuterContext,
    ProposalBatch,
)


_PROMPT_SECTION_ID = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_EDIT_KINDS = {
    "set",
    "prompt_upsert_section",
    "prompt_delete_section",
    "profile_add",
    "profile_remove",
    "profile_swap",
}
_ACTION_AXES = {"prompt", "search", "inference", "context", "profiles"}
_ACTION_FIELDS = {
    "proposal_id",
    "axis",
    "hypothesis",
    "edit_atoms",
    "expected_effect",
    "evidence_ids",
    "preserve",
    "metadata",
}
_EDIT_ATOM_FIELDS = {"kind", "field", "value"}
_MANAGED_PROMPT_SECTION = re.compile(
    r"<!-- HARNESSOPT:([a-z][a-z0-9_-]{0,63}) -->\s*"
    r"(.*?)\s*<!-- /HARNESSOPT:\1 -->",
    re.DOTALL,
)
_SEMANTIC_TOKEN = re.compile(r"[a-z0-9]+|[\u4e00-\u9fff]")


@dataclass(frozen=True)
class HarnessEditAtom:
    """One typed semantic edit before it is compiled to JSON Patch."""

    kind: str
    field: str = ""
    value: Any = None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "HarnessEditAtom":
        unknown = set(value) - {"kind", "field", "value"}
        if unknown:
            raise ValueError(f"unknown HarnessEditAtom fields: {sorted(unknown)}")
        kind = str(value.get("kind") or "")
        if kind not in _EDIT_KINDS:
            raise ValueError(f"unsupported HarnessEditAtom kind: {kind!r}")
        field_name = str(value.get("field") or "")
        if kind in {"set", "prompt_upsert_section", "prompt_delete_section"}:
            if not field_name:
                raise ValueError(f"HarnessEditAtom {kind!r} requires field")
        if kind in {"profile_add", "profile_remove"} and not isinstance(
            value.get("value"), str
        ):
            raise ValueError(f"HarnessEditAtom {kind!r} requires a string value")
        if kind == "profile_swap" and (
            not field_name or not isinstance(value.get("value"), str)
        ):
            raise ValueError(
                "HarnessEditAtom 'profile_swap' requires old profile in field "
                "and new profile in value"
            )
        return cls(kind=kind, field=field_name, value=value.get("value"))

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "field": self.field, "value": jsonable(self.value)}


@dataclass(frozen=True)
class HarnessAction:
    """An evidence-grounded outer action that maps to exactly one candidate."""

    proposal_id: str
    axis: str
    hypothesis: str
    edit_atoms: tuple[HarnessEditAtom, ...]
    expected_effect: str = ""
    evidence_ids: tuple[str, ...] = ()
    preserve: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "HarnessAction":
        unknown = set(value) - {
            "proposal_id",
            "axis",
            "hypothesis",
            "edit_atoms",
            "expected_effect",
            "evidence_ids",
            "preserve",
            "metadata",
        }
        if unknown:
            raise ValueError(f"unknown HarnessAction fields: {sorted(unknown)}")
        proposal_id = str(value.get("proposal_id") or "")
        axis = str(value.get("axis") or "")
        hypothesis = str(value.get("hypothesis") or "")
        if not proposal_id or not axis or not hypothesis:
            raise ValueError("HarnessAction requires proposal_id, axis, and hypothesis")
        if axis not in _ACTION_AXES:
            raise ValueError(
                f"HarnessAction axis must be one of {sorted(_ACTION_AXES)}"
            )
        raw_atoms = value.get("edit_atoms")
        if not isinstance(raw_atoms, list) or not raw_atoms:
            raise ValueError("HarnessAction requires a non-empty edit_atoms list")
        atoms = tuple(
            HarnessEditAtom.from_dict(item)
            for item in raw_atoms
            if isinstance(item, Mapping)
        )
        if len(atoms) != len(raw_atoms):
            raise ValueError("HarnessAction edit_atoms must all be mappings")
        if len(atoms) > 4:
            raise ValueError("HarnessAction may contain at most four edit atoms")
        evidence_ids = value.get("evidence_ids", [])
        preserve = value.get("preserve", [])
        if not isinstance(evidence_ids, list) or not all(
            isinstance(item, str) for item in evidence_ids
        ):
            raise ValueError("HarnessAction evidence_ids must be a string list")
        if not isinstance(preserve, list) or not all(
            isinstance(item, str) for item in preserve
        ):
            raise ValueError("HarnessAction preserve must be a string list")
        return cls(
            proposal_id=proposal_id,
            axis=axis,
            hypothesis=hypothesis,
            edit_atoms=atoms,
            expected_effect=str(value.get("expected_effect") or ""),
            evidence_ids=tuple(evidence_ids),
            preserve=tuple(preserve),
            metadata=dict(value.get("metadata", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "axis": self.axis,
            "hypothesis": self.hypothesis,
            "expected_effect": self.expected_effect,
            "evidence_ids": list(self.evidence_ids),
            "edit_atoms": [item.to_dict() for item in self.edit_atoms],
            "preserve": list(self.preserve),
            "metadata": jsonable(self.metadata),
        }

    def signature(self) -> str:
        return digest_json(
            {
                "axis": self.axis,
                "edit_atoms": [item.to_dict() for item in self.edit_atoms],
            }
        )


def compiled_mutation_signature(proposal: MutationProposal) -> str:
    """Identify the executable state change, excluding prose and proposal IDs."""

    operations = sorted(
        (
            {
                "surface": mutation.surface,
                "op": operation.op,
                "path": operation.path,
                "value": jsonable(operation.value),
            }
            for mutation in proposal.mutations
            for operation in mutation.operations
        ),
        key=lambda item: (
            item["surface"],
            item["path"],
            item["op"],
            digest_json(item["value"]),
        ),
    )
    return digest_json(operations)


def compiled_mutation_target_signature(proposal: MutationProposal) -> str:
    """Identify the executable targets while ignoring proposed values.

    Managed prompt section IDs are included so edits to independent sections
    remain distinct even though both compile to ``/system_prompt``.
    """

    targets = []
    for mutation in proposal.mutations:
        for operation in mutation.operations:
            section_ids: list[str] = []
            if (
                operation.path == "/system_prompt"
                and isinstance(operation.value, str)
            ):
                section_ids = sorted(
                    match.group(1)
                    for match in _MANAGED_PROMPT_SECTION.finditer(
                        operation.value
                    )
                )
            targets.append(
                {
                    "surface": mutation.surface,
                    "op": operation.op,
                    "path": operation.path,
                    "managed_prompt_sections": section_ids,
                }
            )
    return digest_json(
        sorted(
            targets,
            key=lambda item: (
                item["surface"],
                item["path"],
                item["op"],
                tuple(item["managed_prompt_sections"]),
            ),
        )
    )


def _compiled_mutation_semantic_tokens(
    proposal: MutationProposal,
) -> frozenset[str]:
    fragments: list[str] = []
    for mutation in proposal.mutations:
        for operation in mutation.operations:
            value = operation.value
            if not isinstance(value, str):
                continue
            if operation.path == "/system_prompt":
                managed = [
                    match.group(2)
                    for match in _MANAGED_PROMPT_SECTION.finditer(value)
                ]
                fragments.extend(managed or [value])
            else:
                fragments.append(value)
    return frozenset(
        token
        for fragment in fragments
        for token in _SEMANTIC_TOKEN.findall(fragment.lower())
    )


def compiled_mutation_semantic_similarity(
    left: MutationProposal,
    right: MutationProposal,
) -> float:
    """Return a lightweight near-duplicate score for executable text edits.

    The score is intentionally conservative: proposals must edit the same
    executable targets, and short scalar/string values are left to exact
    compiled-mutation deduplication. For substantive text, overlap coefficient
    catches paraphrases where one intervention mostly restates another.
    """

    if compiled_mutation_target_signature(
        left
    ) != compiled_mutation_target_signature(right):
        return 0.0
    left_tokens = _compiled_mutation_semantic_tokens(left)
    right_tokens = _compiled_mutation_semantic_tokens(right)
    if min(len(left_tokens), len(right_tokens)) < 6:
        return 0.0
    return len(left_tokens & right_tokens) / min(
        len(left_tokens), len(right_tokens)
    )


def _action_semantic_tokens(action: HarnessAction) -> frozenset[str]:
    text_fields = (
        action.hypothesis,
        action.expected_effect,
        *action.preserve,
        *(
            atom.value
            for atom in action.edit_atoms
            if isinstance(atom.value, str)
        ),
    )
    return frozenset(
        token
        for text in text_fields
        for token in _SEMANTIC_TOKEN.findall(text.lower())
    )


def harness_action_target_signature(action: HarnessAction) -> str:
    targets = []
    for atom in action.edit_atoms:
        field_name = atom.field.strip().lower()
        if atom.kind == "set":
            field_name = "/" + field_name.lstrip("/").replace(".", "/")
        elif atom.kind in {"prompt_upsert_section", "prompt_delete_section"}:
            # Managed section IDs are organizational labels, not independent
            # executable targets. Treat every managed prompt edit as an edit
            # to /system_prompt so relabeling cannot evade semantic dedupe.
            field_name = "/system_prompt"
        kind = (
            "prompt_edit"
            if atom.kind in {
                "prompt_upsert_section",
                "prompt_delete_section",
            }
            else atom.kind
        )
        targets.append(
            {
                "kind": kind,
                "field": field_name,
            }
        )
    return digest_json(
        sorted(
            targets,
            key=lambda item: (item["kind"], item["field"]),
        )
    )


def harness_action_semantic_similarity(
    left_action: HarnessAction,
    right_action: HarnessAction,
) -> float:
    """Compare proposed text deltas that address the same action targets."""

    if harness_action_target_signature(
        left_action
    ) != harness_action_target_signature(right_action):
        return 0.0
    left_tokens = _action_semantic_tokens(left_action)
    right_tokens = _action_semantic_tokens(right_action)
    if min(len(left_tokens), len(right_tokens)) < 6:
        return 0.0
    return len(left_tokens & right_tokens) / min(
        len(left_tokens), len(right_tokens)
    )


@dataclass(frozen=True)
class HarnessPolicyOutput:
    action: HarnessAction
    action_metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class HarnessPolicyBatch:
    outputs: tuple[HarnessPolicyOutput, ...]
    records: tuple[Mapping[str, Any], ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)


class HarnessActionPolicy(Protocol):
    def propose(
        self,
        *,
        context: OuterContext,
        archive: Mapping[str, Any],
        count: int,
        budget: BudgetMeter,
    ) -> HarnessPolicyBatch: ...


@dataclass(frozen=True)
class HarnessFieldTarget:
    surface: str
    path: str


DEFAULT_NEXAU_FIELD_TARGETS: Mapping[str, HarnessFieldTarget] = {
    "system_prompt": HarnessFieldTarget("harness", "/system_prompt"),
    "max_context_tokens": HarnessFieldTarget("harness", "/max_context_tokens"),
    "max_iterations": HarnessFieldTarget("harness", "/max_iterations"),
    "tool_call_mode": HarnessFieldTarget("harness", "/tool_call_mode"),
    "temperature": HarnessFieldTarget("harness", "/llm/temperature"),
    "top_p": HarnessFieldTarget("harness", "/llm/top_p"),
    "max_tokens": HarnessFieldTarget("harness", "/llm/max_tokens"),
    "enable_thinking": HarnessFieldTarget(
        "harness", "/llm/enable_thinking"
    ),
    "compaction.threshold": HarnessFieldTarget(
        "harness", "/context_compaction/threshold"
    ),
    "compaction.max_context_tokens": HarnessFieldTarget(
        "harness", "/context_compaction/max_context_tokens"
    ),
    "compaction.keep_iterations": HarnessFieldTarget(
        "harness", "/context_compaction/keep_iterations"
    ),
    "compaction.compaction_strategy": HarnessFieldTarget(
        "harness", "/context_compaction/compaction_strategy"
    ),
    "skills": HarnessFieldTarget("harness", "/skills"),
}


class HarnessActionCompiler:
    """Compile semantic actions against outer-visible state into bounded mutations."""

    def __init__(
        self,
        field_targets: Mapping[str, HarnessFieldTarget] | None = None,
        *,
        actor: str = "harnessopt",
    ) -> None:
        self.field_targets = dict(field_targets or DEFAULT_NEXAU_FIELD_TARGETS)
        self.actor = actor

    @staticmethod
    def _visible(context: OuterContext, target: HarnessFieldTarget) -> Any:
        component = context.component_views.get(target.surface)
        if not isinstance(component, Mapping):
            raise ValueError(
                f"outer context does not expose component {target.surface!r}"
            )
        if target.path not in component:
            raise ValueError(
                f"outer context does not expose {target.surface}:{target.path}"
            )
        return component[target.path]

    @staticmethod
    def _section_markers(section_id: str) -> tuple[str, str]:
        # Section IDs are structural labels generated by an LLM. Their case
        # carries no semantics, while managed markers are canonically lower
        # case. Normalize case so an otherwise valid `SYSTEM_INSTRUCTIONS`
        # proposal does not discard the entire candidate batch. Keep every
        # other syntax restriction strict (spaces, punctuation, and length).
        section_id = section_id.lower()
        if _PROMPT_SECTION_ID.fullmatch(section_id) is None:
            raise ValueError(f"invalid HarnessOpt prompt section ID: {section_id!r}")
        return (
            f"<!-- HARNESSOPT:{section_id} -->",
            f"<!-- /HARNESSOPT:{section_id} -->",
        )

    @classmethod
    def _upsert_prompt_section(
        cls, prompt: str, section_id: str, content: Any
    ) -> str:
        if (
            not isinstance(content, str)
            or not content.strip()
            or len(content) > 4000
        ):
            raise ValueError(
                "prompt_upsert_section requires 1..4000 characters of content"
            )
        start, end = cls._section_markers(section_id)
        block = f"{start}\n{content.strip()}\n{end}"
        pattern = re.compile(
            re.escape(start) + r".*?" + re.escape(end), re.DOTALL
        )
        updated, count = pattern.subn(block, prompt)
        if count > 1:
            raise ValueError(f"prompt contains duplicate managed section {section_id!r}")
        if count == 1:
            return updated
        return prompt.rstrip() + "\n\n" + block + "\n"

    @classmethod
    def _delete_prompt_section(cls, prompt: str, section_id: str) -> str:
        start, end = cls._section_markers(section_id)
        pattern = re.compile(
            r"\n{0,2}" + re.escape(start) + r".*?" + re.escape(end) + r"\n{0,2}",
            re.DOTALL,
        )
        updated, count = pattern.subn("\n\n", prompt)
        if count != 1:
            raise ValueError(
                f"prompt_delete_section expected one section {section_id!r}, "
                f"found {count}"
            )
        return updated.strip() + "\n"

    def compile(
        self, *, context: OuterContext, action: HarnessAction
    ) -> MutationProposal:
        initial: dict[tuple[str, str], Any] = {}
        working: dict[tuple[str, str], Any] = {}

        def resolve_target(field_name: str) -> HarnessFieldTarget:
            target = self.field_targets.get(field_name)
            if target is not None:
                return target
            pointer = (
                field_name
                if field_name.startswith("/")
                else "/" + field_name.replace(".", "/")
            )
            matches = {
                (candidate.surface, candidate.path): candidate
                for candidate in self.field_targets.values()
                if candidate.path == pointer
            }
            if len(matches) == 1:
                return next(iter(matches.values()))
            raise ValueError(f"unknown HarnessOpt field: {field_name!r}")

        def current(field_name: str) -> tuple[HarnessFieldTarget, Any]:
            target = resolve_target(field_name)
            key = (target.surface, target.path)
            if key not in working:
                value = self._visible(context, target)
                initial[key] = value
                working[key] = value
            return target, working[key]

        for atom in action.edit_atoms:
            if atom.kind == "set":
                target, _ = current(atom.field)
                working[(target.surface, target.path)] = atom.value
                continue
            if atom.kind in {"prompt_upsert_section", "prompt_delete_section"}:
                target, prompt = current("system_prompt")
                if not isinstance(prompt, str):
                    raise ValueError("outer-visible system_prompt must be a string")
                updated = (
                    self._upsert_prompt_section(prompt, atom.field, atom.value)
                    if atom.kind == "prompt_upsert_section"
                    else self._delete_prompt_section(prompt, atom.field)
                )
                working[(target.surface, target.path)] = updated
                continue
            target, profiles = current("skills")
            if not isinstance(profiles, list) or any(
                not isinstance(item, str) for item in profiles
            ):
                raise ValueError("outer-visible skills must be a string list")
            updated_profiles = list(profiles)
            if atom.kind == "profile_add":
                if atom.value in updated_profiles:
                    raise ValueError(f"profile is already selected: {atom.value}")
                updated_profiles.append(str(atom.value))
            elif atom.kind == "profile_remove":
                if atom.value not in updated_profiles:
                    raise ValueError(f"profile is not selected: {atom.value}")
                updated_profiles.remove(str(atom.value))
            elif atom.kind == "profile_swap":
                if atom.field not in updated_profiles:
                    raise ValueError(f"profile is not selected: {atom.field}")
                if atom.value in updated_profiles and atom.value != atom.field:
                    raise ValueError(f"profile is already selected: {atom.value}")
                index = updated_profiles.index(atom.field)
                updated_profiles[index] = str(atom.value)
            else:  # pragma: no cover - guarded by HarnessEditAtom
                raise ValueError(f"unsupported HarnessOpt edit kind: {atom.kind}")
            working[(target.surface, target.path)] = updated_profiles

        by_surface: dict[str, list[MutationOp]] = {}
        for (surface, path), value in working.items():
            if value == initial[(surface, path)]:
                continue
            by_surface.setdefault(surface, []).append(
                MutationOp(op="replace", path=path, value=value)
            )
        if not by_surface:
            raise ValueError("HarnessAction compiles to no state change")
        mutations = tuple(
            Mutation(surface=surface, operations=tuple(operations))
            for surface, operations in sorted(by_surface.items())
        )
        return MutationProposal(
            proposal_id=action.proposal_id,
            actor=self.actor,
            mutations=mutations,
            rationale=action.hypothesis,
            expected_effect={
                "axis": action.axis,
                "description": action.expected_effect,
                "edit_count": len(action.edit_atoms),
            },
            evidence_ids=action.evidence_ids,
        )


def _extract_json_object(text: str) -> Mapping[str, Any]:
    decoder = json.JSONDecoder()
    source = str(text or "").strip()
    for index, character in enumerate(source):
        if character != "{":
            continue
        try:
            value, _ = decoder.raw_decode(source[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, Mapping):
            return value
    raise ValueError("model response contains no JSON object")


def _clip_json(value: Any, limit: int) -> Any:
    rendered = json.dumps(jsonable(value), ensure_ascii=False, default=str)
    if len(rendered) <= limit:
        return jsonable(value)
    return {"truncated": True, "chars": len(rendered), "preview": rendered[:limit]}


def default_harnessopt_context(
    context: OuterContext, archive: Mapping[str, Any]
) -> Mapping[str, Any]:
    evidence = []
    for item in context.evidence:
        evidence.append(
            {
                "evidence_id": item.get("evidence_id"),
                "task_id": item.get("task_id"),
                "reward": item.get("reward"),
                "metrics": _clip_json(item.get("metrics", {}), 1500),
                "feedback": _clip_json(item.get("feedback", {}), 2500),
                "output": _clip_json(item.get("output"), 1500),
                "trace": _clip_json(item.get("trace", ()), 6000),
            }
        )
    current_harness = jsonable(context.component_views.get("harness", {}))
    update_summary = {
        key: jsonable(value)
        for key, value in context.train_summary.items()
        if key not in {"state_id", "record_artifacts"}
    }
    return {
        "round_index": context.round_index,
        "current_harness": current_harness,
        "mutable_set_fields": sorted(current_harness),
        "update_summary": update_summary,
        "known_evidence_ids": [
            item["evidence_id"]
            for item in evidence
            if item.get("evidence_id")
        ],
        "evidence": evidence,
        "capability_contract": jsonable(context.capability_contract),
        "optimizer_memory": {
            "operator_statistics": jsonable(
                archive.get("operator_statistics", {})
            ),
            "recent_attempts": jsonable(archive.get("attempts", [])[-12:]),
            "successful_actions": jsonable(
                archive.get("successful_actions", [])[-8:]
            ),
            "invalid_signatures": jsonable(
                archive.get("invalid_signatures", [])[-16:]
            ),
        },
    }


class ModelHarnessActionPolicy:
    """Sample independent typed Harness actions from any EvoGate ModelAdapter."""

    SYSTEM_PROMPT = """\
You are the proposal policy inside HarnessOpt. Produce exactly one sparse,
evidence-grounded intervention on the mutable agent harness.

One response maps to one executable candidate and one reward. Do not combine
unrelated experiments. Prefer one edit atom; use at most two when a cross-field
invariant requires it. Never modify the model, evaluator, tasks, tools,
credentials, budgets, or protected implementation.

Treat optimizer_memory.recent_attempts as tested interventions, including
zero-credit and negative results. Do not retry the same target and causal
mechanism by changing wording, thresholds, or examples. Move to a different
field, axis, or genuinely different mechanism when an archived direction lacks
statistically positive reward.

In optimizer_memory.operator_statistics, raw_mean_reward describes observed
score direction while mean_learning_reward is confidence-adjusted credit.
Never treat a positive raw mean with zero confidence-adjusted credit as a
proven improvement.

Allowed edit atoms:
- {"kind":"set","field":"<exact mutable_set_fields JSON Pointer or declared logical alias>","value":<typed value>}
- {"kind":"prompt_upsert_section","field":"<stable-section-id>","value":"<instructions>"}
- {"kind":"prompt_delete_section","field":"<stable-section-id>"}
- {"kind":"profile_add","value":"<registered profile id>"}
- {"kind":"profile_remove","value":"<registered profile id>"}
- {"kind":"profile_swap","field":"<old id>","value":"<new id>"}

For a managed prompt section, field is a short stable section ID and value is
only the new instruction delta (at most 4000 characters). Never copy or restate
the full current prompt inside a managed section.

For evidence_ids, copy IDs only from known_evidence_ids (equivalently,
evidence[*].evidence_id). Never cite state_id, checkpoint IDs, component
digests, or any other identifier. Use an empty list when no listed evidence
supports the action.

Return only one JSON object:
{
  "axis": "prompt|search|inference|context|profiles",
  "hypothesis": "causal, falsifiable explanation",
  "expected_effect": "measurable expected outcome",
  "evidence_ids": ["only IDs present in the context"],
  "edit_atoms": [{"kind":"...", "field":"...", "value":"..."}],
  "preserve": ["important successful behavior to retain"]
}
"""

    def __init__(
        self,
        *,
        model: ModelAdapter,
        model_component: Mapping[str, Any],
        temperature: float = 0.8,
        max_tokens: int = 2048,
        seed: int = 0,
        max_prompt_chars: int = 48000,
        system_prompt: str | None = None,
        proposal_focuses: Sequence[str] = (),
        seed_actions: Sequence[Mapping[str, Any]] = (),
        context_builder: Callable[
            [OuterContext, Mapping[str, Any]], Mapping[str, Any]
        ] = default_harnessopt_context,
    ) -> None:
        self.model = model
        self.model_component = dict(model_component)
        self.temperature = float(temperature)
        self.max_tokens = int(max_tokens)
        self.seed = int(seed)
        self.max_prompt_chars = int(max_prompt_chars)
        self.system_prompt = str(system_prompt or self.SYSTEM_PROMPT)
        self.proposal_focuses = tuple(str(item) for item in proposal_focuses)
        self.seed_actions = tuple(dict(item) for item in seed_actions)
        self.context_builder = context_builder

    def descriptor(self) -> Mapping[str, Any]:
        return {
            "policy": f"{type(self).__module__}.{type(self).__qualname__}",
            "model": self.model_component,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "seed": self.seed,
            "proposal_focuses": list(self.proposal_focuses),
            "seed_action_count": len(self.seed_actions),
        }

    def propose(
        self,
        *,
        context: OuterContext,
        archive: Mapping[str, Any],
        count: int,
        budget: BudgetMeter,
    ) -> HarnessPolicyBatch:
        payload = self.context_builder(context, archive)
        rendered_context = json.dumps(
            payload, ensure_ascii=False, default=str
        )
        if len(rendered_context) > self.max_prompt_chars:
            payload = {
                "round_index": context.round_index,
                "current_harness": payload.get("current_harness", {}),
                "update_summary": payload.get("update_summary", {}),
                "evidence": _clip_json(payload.get("evidence", []), 16000),
                "capability_contract": payload.get("capability_contract", {}),
                "optimizer_memory": _clip_json(
                    payload.get("optimizer_memory", {}), 8000
                ),
            }
            rendered_context = json.dumps(
                payload, ensure_ascii=False, default=str
            )
        outputs: list[HarnessPolicyOutput] = []
        records: list[Mapping[str, Any]] = []
        known_evidence = {
            str(item.get("evidence_id"))
            for item in context.evidence
            if item.get("evidence_id")
        }
        for sample_index in range(count):
            proposal_id = (
                f"hopt-r{context.round_index:03d}-s{sample_index:02d}"
            )
            prior_actions = [
                {
                    "proposal_id": output.action.proposal_id,
                    "axis": output.action.axis,
                    "hypothesis": output.action.hypothesis,
                    "edit_targets": [
                        {
                            "kind": atom.kind,
                            "field": atom.field,
                        }
                        for atom in output.action.edit_atoms
                    ],
                }
                for output in outputs
            ]
            diversity_directive = {
                "batch_sample": sample_index + 1,
                "batch_size": count,
                "prior_valid_actions": prior_actions,
                "required_focus": (
                    self.proposal_focuses[
                        sample_index % len(self.proposal_focuses)
                    ]
                    if self.proposal_focuses
                    else None
                ),
                "requirement": (
                    "Propose a causally distinct intervention. Do not merely "
                    "paraphrase a prior trigger, threshold, target field, or "
                    "algorithm example. Prefer a different mutable axis or "
                    "field; if the same target is necessary, use a genuinely "
                    "different mechanism and falsifiable hypothesis."
                ),
            }
            rendered = (
                rendered_context
                + "\n\nBATCH_DIVERSITY:\n"
                + json.dumps(
                    diversity_directive,
                    ensure_ascii=False,
                    default=str,
                )
            )
            if sample_index < len(self.seed_actions):
                record: dict[str, Any] = {
                    "sample_index": sample_index,
                    "proposal_id": proposal_id,
                    "status": "seeded",
                    "usage": {},
                }
                try:
                    parsed = dict(self.seed_actions[sample_index])
                    parsed["proposal_id"] = proposal_id
                    action = HarnessAction.from_dict(parsed)
                except (TypeError, ValueError) as exc:
                    record["status"] = "invalid_seed"
                    record["error"] = f"{type(exc).__name__}: {exc}"
                else:
                    outputs.append(
                        HarnessPolicyOutput(
                            action=action,
                            action_metadata={
                                "sample_index": sample_index,
                                "policy": "preregistered_seed",
                            },
                        )
                    )
                    record["action"] = action.to_dict()
                records.append(record)
                continue
            response = self.model.generate(
                ModelRequest(
                    messages=(
                        {"role": "system", "content": self.system_prompt},
                        {"role": "user", "content": rendered},
                    ),
                    model_component=self.model_component,
                    metadata={
                        "generation": {
                            "temperature": self.temperature,
                            "max_tokens": self.max_tokens,
                            "seed": (
                                self.seed
                                + context.round_index * 1000
                                + sample_index
                            ),
                            "chat_template_kwargs": {"enable_thinking": False},
                        },
                        "purpose": "harnessopt.propose",
                        "sample_index": sample_index,
                    },
                ),
                budget,
            )
            record: dict[str, Any] = {
                "sample_index": sample_index,
                "proposal_id": proposal_id,
                "response": response.text,
                "usage": jsonable(response.usage),
            }
            try:
                parsed = dict(_extract_json_object(response.text))
                parsed["proposal_id"] = proposal_id
                dropped_action_fields = sorted(
                    set(parsed) - _ACTION_FIELDS
                )
                for field_name in dropped_action_fields:
                    parsed.pop(field_name)
                dropped_atom_fields: dict[str, list[str]] = {}
                raw_atoms = parsed.get("edit_atoms")
                if isinstance(raw_atoms, list):
                    sanitized_atoms: list[Any] = []
                    for atom_index, atom in enumerate(raw_atoms):
                        if not isinstance(atom, Mapping):
                            sanitized_atoms.append(atom)
                            continue
                        unknown_fields = sorted(
                            set(atom) - _EDIT_ATOM_FIELDS
                        )
                        if unknown_fields:
                            dropped_atom_fields[str(atom_index)] = (
                                unknown_fields
                            )
                        sanitized_atoms.append(
                            {
                                key: value
                                for key, value in atom.items()
                                if key in _EDIT_ATOM_FIELDS
                            }
                        )
                    parsed["edit_atoms"] = sanitized_atoms
                action = HarnessAction.from_dict(parsed)
                unknown_evidence = sorted(
                    set(action.evidence_ids) - known_evidence
                )
                action_metadata: dict[str, Any] = {
                    "sample_index": sample_index,
                    "policy": "model",
                }
                if dropped_action_fields:
                    record["dropped_unknown_action_fields"] = (
                        dropped_action_fields
                    )
                    action_metadata["dropped_unknown_action_fields"] = (
                        dropped_action_fields
                    )
                if dropped_atom_fields:
                    record["dropped_unknown_edit_atom_fields"] = (
                        dropped_atom_fields
                    )
                    action_metadata[
                        "dropped_unknown_edit_atom_fields"
                    ] = dropped_atom_fields
                if unknown_evidence:
                    action = replace(
                        action,
                        evidence_ids=tuple(
                            evidence_id
                            for evidence_id in action.evidence_ids
                            if evidence_id in known_evidence
                        ),
                    )
                    record["dropped_unknown_evidence_ids"] = unknown_evidence
                    action_metadata["dropped_unknown_evidence_ids"] = (
                        unknown_evidence
                    )
                outputs.append(
                    HarnessPolicyOutput(
                        action=action,
                        action_metadata={
                            **action_metadata,
                            "policy_training_example": {
                                "schema": (
                                    "evogate.harnessopt-policy-example/v1"
                                ),
                                "system": self.system_prompt,
                                "user": rendered,
                                "response": json.dumps(
                                    {
                                        key: value
                                        for key, value in action.to_dict().items()
                                        if key != "proposal_id"
                                    },
                                    ensure_ascii=False,
                                    sort_keys=True,
                                ),
                                "response_format": "plain_text",
                                "served_model": self.model_component.get(
                                    "served_model"
                                ),
                            },
                        },
                    )
                )
                record["status"] = "valid"
                record["action"] = action.to_dict()
            except (TypeError, ValueError) as exc:
                record["status"] = "invalid"
                record["error"] = f"{type(exc).__name__}: {exc}"
            records.append(record)
        return HarnessPolicyBatch(
            outputs=tuple(outputs),
            records=tuple(records),
            metadata={
                "requested": count,
                "valid": len(outputs),
                "invalid": count - len(outputs),
            },
        )


class StaticHarnessActionPolicy:
    """Deterministic policy useful for conformance and CPU-only smoke tests."""

    def __init__(
        self,
        actions: Sequence[HarnessAction | Mapping[str, Any]]
        | Mapping[int, Sequence[HarnessAction | Mapping[str, Any]]],
    ) -> None:
        self.actions = actions

    def descriptor(self) -> Mapping[str, Any]:
        return {"policy": f"{type(self).__module__}.{type(self).__qualname__}"}

    def propose(
        self,
        *,
        context: OuterContext,
        archive: Mapping[str, Any],
        count: int,
        budget: BudgetMeter,
    ) -> HarnessPolicyBatch:
        del archive, budget
        source = (
            self.actions.get(context.round_index, ())
            if isinstance(self.actions, Mapping)
            else self.actions
        )
        normalized = [
            item if isinstance(item, HarnessAction) else HarnessAction.from_dict(item)
            for item in source
        ][:count]
        return HarnessPolicyBatch(
            outputs=tuple(
                HarnessPolicyOutput(action=item, action_metadata={"policy": "static"})
                for item in normalized
            ),
            metadata={"requested": count, "valid": len(normalized), "invalid": 0},
        )


def _initial_archive() -> dict[str, Any]:
    return {
        "schema": "evogate.harnessopt-archive/v1",
        "rounds_seen": 0,
        "attempts": [],
        "successful_actions": [],
        "operator_statistics": {},
        "operator_statistics_schema": "raw-and-learning/v2",
        "operator_statistics_scope": "retained_attempts",
        "invalid_signatures": [],
    }


class HarnessOptOptimizer:
    """Reward-indexed discrete Harness optimizer on EvoGate's native protocol."""

    def __init__(
        self,
        *,
        policy: HarnessActionPolicy,
        compiler: HarnessActionCompiler | None = None,
        proposal_count: int = 3,
        proposal_attempt_multiplier: int = 1,
        max_archive_entries: int = 256,
        semantic_duplicate_threshold: float | None = None,
        semantic_archive_window: int = 0,
        semantic_archive_threshold: float | None = None,
        origin_component: tuple[str, Any] | None = None,
    ) -> None:
        if proposal_count < 1:
            raise ValueError("HarnessOpt proposal_count must be positive")
        if proposal_attempt_multiplier < 1:
            raise ValueError(
                "HarnessOpt proposal_attempt_multiplier must be positive"
            )
        if max_archive_entries < 1:
            raise ValueError("HarnessOpt max_archive_entries must be positive")
        if (
            semantic_duplicate_threshold is not None
            and not 0.0 < semantic_duplicate_threshold <= 1.0
        ):
            raise ValueError(
                "HarnessOpt semantic_duplicate_threshold must be in (0, 1]"
            )
        if semantic_archive_window < 0:
            raise ValueError(
                "HarnessOpt semantic_archive_window must be nonnegative"
            )
        if (
            semantic_archive_threshold is not None
            and not 0.0 < semantic_archive_threshold <= 1.0
        ):
            raise ValueError(
                "HarnessOpt semantic_archive_threshold must be in (0, 1]"
            )
        if (
            semantic_archive_threshold is not None
            and semantic_duplicate_threshold is None
        ):
            raise ValueError(
                "HarnessOpt semantic_archive_threshold requires "
                "semantic_duplicate_threshold"
            )
        self.policy = policy
        self.compiler = compiler or HarnessActionCompiler()
        self.proposal_count = int(proposal_count)
        self.proposal_attempt_multiplier = int(
            proposal_attempt_multiplier
        )
        self.max_archive_entries = int(max_archive_entries)
        self.semantic_duplicate_threshold = (
            float(semantic_duplicate_threshold)
            if semantic_duplicate_threshold is not None
            else None
        )
        self.semantic_archive_window = int(semantic_archive_window)
        self.semantic_archive_threshold = (
            float(semantic_archive_threshold)
            if semantic_archive_threshold is not None
            else self.semantic_duplicate_threshold
        )
        self.origin_component = origin_component

    def capabilities(self) -> Mapping[str, Any]:
        descriptor = getattr(self.policy, "descriptor", None)
        return {
            "isolated": False,
            "mode": "in-process-harnessopt",
            "learning": "non-parametric archive",
            "policy": descriptor() if callable(descriptor) else {},
        }

    def initialize(
        self, *, store: ArtifactStore, budget: BudgetMeter
    ) -> OptimizerState:
        del budget
        archive = store.put_json(_initial_archive(), kind="optimizer.harnessopt.archive")
        descriptor_method = getattr(self.policy, "descriptor", None)
        descriptor = (
            descriptor_method()
            if callable(descriptor_method)
            else {"policy": f"{type(self.policy).__module__}.{type(self.policy).__qualname__}"}
        )
        algorithm = store.put_json(
            {
                "schema": "evogate.harnessopt/v1",
                "proposal_count": self.proposal_count,
                "proposal_attempt_multiplier": (
                    self.proposal_attempt_multiplier
                ),
                "max_archive_entries": self.max_archive_entries,
                "semantic_duplicate_threshold": (
                    self.semantic_duplicate_threshold
                ),
                "semantic_archive_window": self.semantic_archive_window,
                "semantic_archive_threshold": (
                    self.semantic_archive_threshold
                ),
                "policy": descriptor,
            },
            kind="optimizer.algorithm",
        )
        components: dict[str, ArtifactRef] = {
            "archive": archive,
            "algorithm": algorithm,
        }
        if self.origin_component is not None:
            name, value = self.origin_component
            components[str(name)] = store.put_json(value, kind=str(name))
        state = OptimizerState(
            components=components,
            metadata={"algorithm": "HarnessOpt", "parameter_learning": False},
        )
        store.put_optimizer_state(state)
        return state

    def propose(
        self,
        *,
        context: OuterContext,
        state: OptimizerState,
        store: ArtifactStore,
        budget: BudgetMeter,
    ) -> ProposalBatch:
        archive_ref = state.components.get("archive")
        if archive_ref is None:
            raise ValueError("HarnessOpt optimizer state has no archive")
        archive = dict(store.get_json(archive_ref))
        if (
            archive.get("operator_statistics_schema")
            != "raw-and-learning/v2"
        ):
            archive["operator_statistics"] = (
                self._statistics_from_attempts(
                    list(archive.get("attempts", []))
                )
            )
            archive["operator_statistics_schema"] = (
                "raw-and-learning/v2"
            )
            archive["operator_statistics_scope"] = "retained_attempts"
        policy_batch = self.policy.propose(
            context=context,
            archive=archive,
            count=(
                self.proposal_count
                * self.proposal_attempt_multiplier
            ),
            budget=budget,
        )
        proposals: list[MutationProposal] = []
        actions: dict[str, Mapping[str, Any]] = {}
        compilation_records: list[dict[str, Any]] = []
        seen_proposal_ids: set[str] = set()
        seen_mutations: dict[str, str] = {}
        semantic_pool: list[tuple[str, HarnessAction, str]] = []
        archive_semantic_pool: list[tuple[str, HarnessAction]] = []
        if (
            self.semantic_duplicate_threshold is not None
            and self.semantic_archive_window > 0
        ):
            for attempt in list(archive.get("attempts", []))[
                -self.semantic_archive_window :
            ]:
                if not isinstance(attempt, Mapping):
                    continue
                semantic = attempt.get("action")
                if not isinstance(semantic, Mapping):
                    continue
                try:
                    prior_action = HarnessAction.from_dict(semantic)
                except (TypeError, ValueError):
                    continue
                archive_semantic_pool.append(
                    (
                        str(
                            attempt.get("proposal_id")
                            or prior_action.proposal_id
                        ),
                        prior_action,
                    )
                )
        duplicate_mutations = 0
        semantic_duplicate_mutations = 0
        semantic_batch_duplicate_mutations = 0
        semantic_archive_duplicate_mutations = 0
        compile_invalid = 0
        for output in policy_batch.outputs:
            action = output.action
            if action.proposal_id in seen_proposal_ids:
                compile_invalid += 1
                compilation_records.append(
                    {
                        "proposal_id": action.proposal_id,
                        "status": "invalid",
                        "error": "duplicate proposal ID",
                    }
                )
                continue
            seen_proposal_ids.add(action.proposal_id)
            try:
                proposal = self.compiler.compile(context=context, action=action)
            except (TypeError, ValueError) as exc:
                compile_invalid += 1
                compilation_records.append(
                    {
                        "proposal_id": action.proposal_id,
                        "status": "invalid",
                        "error": f"{type(exc).__name__}: {exc}",
                        "action": action.to_dict(),
                    }
                )
                continue
            mutation_signature = compiled_mutation_signature(proposal)
            target_signature = compiled_mutation_target_signature(proposal)
            semantic_target_signature = harness_action_target_signature(action)
            duplicate_of = seen_mutations.get(mutation_signature)
            if duplicate_of is not None:
                duplicate_mutations += 1
                compilation_records.append(
                    {
                        "proposal_id": action.proposal_id,
                        "status": "duplicate",
                        "error": "duplicate compiled mutation semantics",
                        "duplicate_of": duplicate_of,
                        "mutation_signature": mutation_signature,
                        "semantic_target_signature": semantic_target_signature,
                        "action": action.to_dict(),
                        "proposal": jsonable(proposal),
                    }
                )
                continue
            semantic_duplicate_of: str | None = None
            semantic_similarity = 0.0
            semantic_duplicate_scope: str | None = None
            if self.semantic_duplicate_threshold is not None:
                for prior_id, prior_action in archive_semantic_pool:
                    similarity = harness_action_semantic_similarity(
                        action,
                        prior_action,
                    )
                    if similarity > semantic_similarity:
                        semantic_similarity = similarity
                        semantic_duplicate_of = (
                            prior_id
                            if similarity
                            >= float(self.semantic_archive_threshold)
                            else None
                        )
                        semantic_duplicate_scope = (
                            "archive"
                            if semantic_duplicate_of is not None
                            else None
                        )
                for _prior_id, prior_action, cluster_root in semantic_pool:
                    similarity = harness_action_semantic_similarity(
                        action,
                        prior_action,
                    )
                    if similarity > semantic_similarity:
                        semantic_similarity = similarity
                        semantic_duplicate_of = (
                            cluster_root
                            if similarity
                            >= self.semantic_duplicate_threshold
                            else None
                        )
                        semantic_duplicate_scope = (
                            "batch"
                            if semantic_duplicate_of is not None
                            else None
                        )
                semantic_pool.append(
                    (
                        action.proposal_id,
                        action,
                        semantic_duplicate_of or action.proposal_id,
                    )
                )
            if semantic_duplicate_of is not None:
                semantic_duplicate_mutations += 1
                if semantic_duplicate_scope == "archive":
                    semantic_archive_duplicate_mutations += 1
                else:
                    semantic_batch_duplicate_mutations += 1
                compilation_records.append(
                    {
                        "proposal_id": action.proposal_id,
                        "status": (
                            "semantic_archive_duplicate"
                            if semantic_duplicate_scope == "archive"
                            else "semantic_duplicate"
                        ),
                        "error": "near-duplicate compiled mutation semantics",
                        "duplicate_of": semantic_duplicate_of,
                        "duplicate_scope": semantic_duplicate_scope,
                        "semantic_similarity": semantic_similarity,
                        "semantic_duplicate_threshold": (
                            self.semantic_duplicate_threshold
                        ),
                        "semantic_archive_threshold": (
                            self.semantic_archive_threshold
                        ),
                        "mutation_signature": mutation_signature,
                        "target_signature": target_signature,
                        "semantic_target_signature": semantic_target_signature,
                        "action": action.to_dict(),
                        "proposal": jsonable(proposal),
                    }
                )
                continue
            seen_mutations[mutation_signature] = action.proposal_id
            if self.semantic_duplicate_threshold is None:
                semantic_pool.append(
                    (
                        action.proposal_id,
                        action,
                        action.proposal_id,
                    )
                )
            if len(proposals) >= self.proposal_count:
                compilation_records.append(
                    {
                        "proposal_id": action.proposal_id,
                        "status": "surplus",
                        "reason": "distinct candidate quota already filled",
                        "mutation_signature": mutation_signature,
                        "target_signature": target_signature,
                        "semantic_target_signature": semantic_target_signature,
                        "action": action.to_dict(),
                        "proposal": jsonable(proposal),
                    }
                )
                continue
            proposals.append(proposal)
            actions[action.proposal_id] = {
                **dict(output.action_metadata),
                "semantic_action": action.to_dict(),
                "action_signature": action.signature(),
                "mutation_signature": mutation_signature,
                "target_signature": target_signature,
                "semantic_target_signature": semantic_target_signature,
            }
            compilation_records.append(
                {
                    "proposal_id": action.proposal_id,
                    "status": "compiled",
                    "mutation_signature": mutation_signature,
                    "target_signature": target_signature,
                    "semantic_target_signature": semantic_target_signature,
                    "action": action.to_dict(),
                    "proposal": jsonable(proposal),
                }
            )
        transcript = store.put_json(
            {
                "schema": "evogate.harnessopt-proposal-batch/v1",
                "policy_records": list(policy_batch.records),
                "compilation_records": compilation_records,
                "metadata": dict(policy_batch.metadata),
            },
            kind="optimizer.harnessopt.proposals",
        )
        return ProposalBatch(
            proposals=tuple(proposals),
            actions=actions,
            artifacts=(transcript,),
            metadata={
                **dict(policy_batch.metadata),
                "requested": self.proposal_count,
                "sampled": int(
                    policy_batch.metadata.get(
                        "requested",
                        len(policy_batch.records),
                    )
                ),
                "proposal_attempt_multiplier": (
                    self.proposal_attempt_multiplier
                ),
                "compiled": len(proposals),
                "compile_invalid": compile_invalid,
                "duplicate_mutations": duplicate_mutations,
                "semantic_duplicate_mutations": (
                    semantic_duplicate_mutations
                ),
                "semantic_batch_duplicate_mutations": (
                    semantic_batch_duplicate_mutations
                ),
                "semantic_archive_duplicate_mutations": (
                    semantic_archive_duplicate_mutations
                ),
                "semantic_duplicate_threshold": (
                    self.semantic_duplicate_threshold
                ),
                "semantic_archive_window": self.semantic_archive_window,
                "semantic_archive_threshold": (
                    self.semantic_archive_threshold
                ),
                "optimizer_state_id": state.state_id,
            },
        )

    @staticmethod
    def _update_stat(
        statistics: dict[str, Any],
        key: str,
        *,
        raw_reward: float,
        learning_reward: float,
        valid: bool,
        statistically_positive: bool,
    ) -> None:
        row = dict(statistics.get(key, {}))
        count = int(row.get("count", 0)) + 1
        raw_reward_sum = (
            float(row.get("raw_reward_sum", 0.0)) + raw_reward
        )
        raw_reward_sq_sum = (
            float(row.get("raw_reward_sq_sum", 0.0))
            + raw_reward * raw_reward
        )
        raw_variance = max(
            0.0,
            raw_reward_sq_sum / count
            - (raw_reward_sum / count) ** 2,
        )
        learning_reward_sum = (
            float(
                row.get(
                    "learning_reward_sum",
                    row.get("reward_sum", 0.0),
                )
            )
            + learning_reward
        )
        learning_reward_sq_sum = (
            float(
                row.get(
                    "learning_reward_sq_sum",
                    row.get("reward_sq_sum", 0.0),
                )
            )
            + learning_reward * learning_reward
        )
        learning_variance = max(
            0.0,
            learning_reward_sq_sum / count
            - (learning_reward_sum / count) ** 2,
        )
        row.update(
            {
                "count": count,
                "raw_reward_sum": raw_reward_sum,
                "raw_reward_sq_sum": raw_reward_sq_sum,
                "raw_mean_reward": raw_reward_sum / count,
                "raw_reward_std": math.sqrt(raw_variance),
                "learning_reward_sum": learning_reward_sum,
                "learning_reward_sq_sum": learning_reward_sq_sum,
                "mean_learning_reward": (
                    learning_reward_sum / count
                ),
                "learning_reward_std": math.sqrt(
                    learning_variance
                ),
                # Backward-compatible names retain their original
                # confidence-adjusted credit semantics.
                "reward_sum": learning_reward_sum,
                "reward_sq_sum": learning_reward_sq_sum,
                "mean_reward": learning_reward_sum / count,
                "reward_std": math.sqrt(learning_variance),
                "valid_count": int(row.get("valid_count", 0)) + int(valid),
                "invalid_count": int(row.get("invalid_count", 0)) + int(not valid),
                "statistically_positive_count": int(
                    row.get("statistically_positive_count", 0)
                )
                + int(statistically_positive),
            }
        )
        statistics[key] = row

    @classmethod
    def _statistics_from_attempts(
        cls,
        attempts: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        statistics: dict[str, Any] = {}
        for attempt in attempts:
            semantic = attempt.get("action")
            if not isinstance(semantic, Mapping):
                continue
            try:
                action = HarnessAction.from_dict(semantic)
            except (TypeError, ValueError):
                continue
            raw_reward = float(attempt.get("reward", 0.0) or 0.0)
            learning_reward = float(
                attempt.get("learning_reward", raw_reward) or 0.0
            )
            statistically_positive = bool(
                attempt.get(
                    "statistically_positive",
                    learning_reward > 0.0,
                )
            )
            keys = {f"axis:{action.axis}"}
            keys.update(
                f"kind:{atom.kind}" for atom in action.edit_atoms
            )
            for key in keys:
                cls._update_stat(
                    statistics,
                    key,
                    raw_reward=raw_reward,
                    learning_reward=learning_reward,
                    valid=bool(attempt.get("valid", False)),
                    statistically_positive=statistically_positive,
                )
        return statistics

    def learn(
        self,
        *,
        state: OptimizerState,
        transitions: Sequence[OptimizerTransition],
        store: ArtifactStore,
        budget: BudgetMeter,
    ) -> OptimizerState:
        del budget
        archive_ref = state.components.get("archive")
        if archive_ref is None:
            raise ValueError("HarnessOpt optimizer state has no archive")
        archive = dict(store.get_json(archive_ref))
        attempts = list(archive.get("attempts", []))
        successes = list(archive.get("successful_actions", []))
        invalid_signatures = list(archive.get("invalid_signatures", []))
        for transition in transitions:
            semantic = transition.action.get("semantic_action")
            action = (
                HarnessAction.from_dict(semantic)
                if isinstance(semantic, Mapping)
                else None
            )
            valid = (
                transition.assessment.failure_reason is None
                and not transition.assessment.integrity_flags
                and transition.assessment.outcome_score is not None
            )
            reward = float(transition.reward.total)
            confidence_z = float(
                transition.metadata.get("confidence_z", 0.0) or 0.0
            )
            delta_sem = transition.assessment.outcome_delta_sem
            confidence_margin = (
                confidence_z * float(delta_sem)
                if delta_sem is not None
                else None
            )
            if confidence_z > 0.0 and confidence_margin is None:
                learning_reward = 0.0
            elif confidence_margin is not None:
                learning_reward = math.copysign(
                    max(0.0, abs(reward) - confidence_margin),
                    reward,
                )
            else:
                learning_reward = reward
            uncertainty_available = (
                confidence_z <= 0.0 or delta_sem is not None
            )
            statistically_positive = learning_reward > 0.0
            signature = (
                str(transition.action.get("action_signature") or "")
                or (action.signature() if action else "")
            )
            attempt = {
                "round_index": transition.round_index,
                "proposal_id": transition.proposal.proposal_id,
                "signature": signature,
                "action": action.to_dict() if action else None,
                "valid": valid,
                "reward": reward,
                "learning_reward": learning_reward,
                "reward_components": dict(transition.reward.components),
                "outcome_score": transition.assessment.outcome_score,
                "outcome_score_sem": (
                    transition.assessment.outcome_score_sem
                ),
                "outcome_delta_sem": delta_sem,
                "confidence_z": confidence_z,
                "confidence_margin": confidence_margin,
                "uncertainty_available": uncertainty_available,
                "statistically_positive": statistically_positive,
                "outcome_behavior_fingerprints": list(
                    transition.assessment.outcome_behavior_fingerprints
                ),
                "outcome_behavior_equivalent": (
                    transition.assessment.outcome_behavior_equivalent
                ),
                "failure_reason": transition.assessment.failure_reason,
                "integrity_flags": list(transition.assessment.integrity_flags),
                "candidate_state_id": transition.assessment.candidate_state_id,
            }
            attempts.append(attempt)
            if valid and statistically_positive:
                successes.append(attempt)
            if not valid and signature and signature not in invalid_signatures:
                invalid_signatures.append(signature)
        attempts = attempts[-self.max_archive_entries :]
        successes = sorted(
            successes[-self.max_archive_entries :],
            key=lambda item: (
                float(
                    item.get(
                        "learning_reward",
                        item.get("reward", 0.0),
                    )
                ),
                str(item.get("proposal_id", "")),
            ),
        )
        invalid_signatures = invalid_signatures[-self.max_archive_entries :]
        statistics = self._statistics_from_attempts(attempts)
        updated_archive = {
            "schema": "evogate.harnessopt-archive/v1",
            "rounds_seen": int(archive.get("rounds_seen", 0)) + 1,
            "attempts": attempts,
            "successful_actions": successes,
            "operator_statistics": statistics,
            "operator_statistics_schema": "raw-and-learning/v2",
            "operator_statistics_scope": "retained_attempts",
            "invalid_signatures": invalid_signatures,
        }
        updated_ref = store.put_json(
            updated_archive, kind="optimizer.harnessopt.archive"
        )
        components = dict(state.components)
        components["archive"] = updated_ref
        return OptimizerState(
            components=components,
            step=state.step + 1,
            parent_id=state.state_id,
            metadata={
                **dict(state.metadata),
                "last_transition_count": len(transitions),
                "parameter_learning": False,
            },
        )
