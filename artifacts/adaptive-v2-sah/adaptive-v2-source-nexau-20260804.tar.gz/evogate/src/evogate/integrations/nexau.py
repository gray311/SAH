from __future__ import annotations

import hashlib
import json
import os
import subprocess
import uuid
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..budget import BudgetMeter
from ..protocols import CommandSpec, PluginSet, Sandbox
from ..sandbox import LocalProcessSandbox
from ..types import AgentState, BudgetUsage, EpisodeResult, MutationProposal, TaskCase
from ._agent_common import AgentTaskSource, ExpectedOutputEvaluator, worker_payload
from ._common import (
    NoProposalOuter,
    remaining_timeout,
    resolve_executable,
    resolve_path,
)


_HARNESS_FIELDS = {
    "system_prompt",
    "system_prompt_suffix",
    "tool_call_mode",
    "max_context_tokens",
    "max_iterations",
    "timeout",
    "llm",
    "run",
    "skills",
    "context_compaction",
}
_LLM_FIELDS = {
    "temperature",
    "max_tokens",
    "top_p",
    "frequency_penalty",
    "presence_penalty",
    "stream",
    "enable_thinking",
}
_RUN_FIELDS = {"context", "state", "config"}
_COMPACTION_FIELDS = {
    "max_context_tokens",
    "auto_compact",
    "emergency_compact_enabled",
    "threshold",
    "compaction_strategy",
    "keep_iterations",
    "keep_user_rounds",
}


def _verify_skill_directory(
    path: Path, expected_hashes: Mapping[str, Any]
) -> dict[str, str]:
    root = path.resolve()
    if not root.is_dir():
        raise ValueError(f"NexAU skill directory does not exist: {root}")
    if path.is_symlink() or any(item.is_symlink() for item in root.rglob("*")):
        raise ValueError(f"NexAU skill directory may not contain symlinks: {root}")
    expected = {str(name): str(digest) for name, digest in expected_hashes.items()}
    if not expected:
        raise ValueError(f"NexAU skill directory has no pinned file hashes: {root}")
    actual_files = {
        item.relative_to(root).as_posix()
        for item in root.rglob("*")
        if item.is_file()
    }
    if actual_files != set(expected):
        raise ValueError(f"NexAU skill file manifest mismatch: {root}")
    for name, digest in expected.items():
        relative = Path(name)
        if relative.is_absolute() or not relative.parts or ".." in relative.parts:
            raise ValueError(f"invalid NexAU skill manifest path: {name!r}")
        observed = hashlib.sha256((root / relative).read_bytes()).hexdigest()
        if observed != digest:
            raise ValueError(f"NexAU skill hash mismatch: {root / relative}")
    return expected


def resolve_skill_registry(
    value: Mapping[str, Any] | None, *, base_dir: Path | str = "."
) -> dict[str, dict[str, Any]]:
    """Resolve and verify a protected registry of selectable NexAU skills."""

    base = Path(base_dir).resolve()
    registry: dict[str, dict[str, Any]] = {}
    for raw_id, raw_spec in dict(value or {}).items():
        skill_id = str(raw_id)
        if not skill_id or not isinstance(raw_spec, Mapping):
            raise ValueError("NexAU skill registry entries require an ID and mapping")
        unknown = set(raw_spec) - {"path", "files_sha256"}
        if unknown:
            raise ValueError(
                f"unknown NexAU skill registry fields for {skill_id!r}: "
                f"{sorted(unknown)}"
            )
        raw_path = Path(str(raw_spec.get("path") or ""))
        path = raw_path if raw_path.is_absolute() else base / raw_path
        path = path.resolve()
        expected = _verify_skill_directory(
            path, dict(raw_spec.get("files_sha256") or {})
        )
        registry[skill_id] = {
            "path": str(path),
            "files_sha256": expected,
        }
    return registry


class NexAUHarnessValidator:
    """Semantic validation for the normalized mutable NexAU harness surface."""

    def __init__(self, skill_registry: Mapping[str, Any] | None = None) -> None:
        self.skill_ids = frozenset(str(item) for item in dict(skill_registry or {}))

    @staticmethod
    def _number(
        row: Mapping[str, Any],
        name: str,
        *,
        minimum: float,
        maximum: float,
        integer: bool = False,
    ) -> None:
        if name not in row:
            return
        value = row[name]
        valid_type = (
            isinstance(value, int) and not isinstance(value, bool)
            if integer
            else isinstance(value, (int, float)) and not isinstance(value, bool)
        )
        if not valid_type or not minimum <= float(value) <= maximum:
            kind = "integer" if integer else "number"
            raise ValueError(
                f"NexAU harness {name} must be a {kind} in "
                f"[{minimum:g}, {maximum:g}]"
            )

    def validate(
        self,
        *,
        baseline: AgentState,
        candidate: AgentState,
        proposal: MutationProposal,
        components: Mapping[str, Any],
    ) -> None:
        del baseline, candidate, proposal
        harness = components.get("harness")
        if not isinstance(harness, Mapping):
            raise ValueError("NexAU harness component must be a mapping")
        unknown = set(harness) - _HARNESS_FIELDS
        if unknown:
            raise ValueError(f"unsupported NexAU harness fields: {sorted(unknown)}")
        prompt = harness.get("system_prompt")
        if prompt is not None and (
            not isinstance(prompt, str) or not 40 <= len(prompt) <= 16000
        ):
            raise ValueError("NexAU system_prompt must contain 40..16000 characters")
        self._number(
            harness, "max_context_tokens", minimum=8192, maximum=200000, integer=True
        )
        self._number(
            harness, "max_iterations", minimum=1, maximum=80, integer=True
        )
        if harness.get("tool_call_mode") not in {None, "structured", "xml"}:
            raise ValueError("NexAU tool_call_mode must be structured or xml")

        llm = harness.get("llm", {})
        if not isinstance(llm, Mapping):
            raise ValueError("NexAU harness.llm must be a mapping")
        unknown_llm = set(llm) - _LLM_FIELDS
        if unknown_llm:
            raise ValueError(
                f"unsupported NexAU harness.llm fields: {sorted(unknown_llm)}"
            )
        self._number(llm, "temperature", minimum=0.0, maximum=2.0)
        self._number(llm, "max_tokens", minimum=256, maximum=32768, integer=True)
        self._number(llm, "top_p", minimum=0.0, maximum=1.0)
        if "enable_thinking" in llm and not isinstance(
            llm["enable_thinking"], bool
        ):
            raise ValueError(
                "NexAU harness enable_thinking must be boolean"
            )

        run = harness.get("run", {})
        if not isinstance(run, Mapping) or set(run) - _RUN_FIELDS:
            raise ValueError("NexAU harness.run contains unsupported fields")

        selected = harness.get("skills", [])
        if (
            not isinstance(selected, list)
            or len(selected) > 4
            or len(set(map(str, selected))) != len(selected)
            or any(not isinstance(item, str) for item in selected)
        ):
            raise ValueError("NexAU harness.skills must be a unique string list of size <= 4")
        unknown_skills = set(selected) - self.skill_ids
        if unknown_skills:
            raise ValueError(
                f"NexAU harness selected unregistered skills: {sorted(unknown_skills)}"
            )

        compaction = harness.get("context_compaction", {})
        if not isinstance(compaction, Mapping):
            raise ValueError("NexAU context_compaction must be a mapping")
        unknown_compaction = set(compaction) - _COMPACTION_FIELDS
        if unknown_compaction:
            raise ValueError(
                "unsupported NexAU context_compaction fields: "
                f"{sorted(unknown_compaction)}"
            )
        self._number(
            compaction,
            "max_context_tokens",
            minimum=8192,
            maximum=200000,
            integer=True,
        )
        self._number(compaction, "threshold", minimum=0.5, maximum=0.9)
        self._number(
            compaction, "keep_iterations", minimum=1, maximum=8, integer=True
        )
        self._number(
            compaction, "keep_user_rounds", minimum=0, maximum=8, integer=True
        )
        strategy = compaction.get("compaction_strategy")
        if strategy not in {None, "tool_result_compaction", "llm_summary"}:
            raise ValueError("unsupported NexAU compaction strategy")
        outer_context = harness.get("max_context_tokens")
        inner_context = compaction.get("max_context_tokens")
        if (
            outer_context is not None
            and inner_context is not None
            and outer_context != inner_context
        ):
            raise ValueError(
                "NexAU max_context_tokens must match context_compaction.max_context_tokens"
            )


class NexAUInnerRuntime:
    """Execute a protected NexAU YAML agent with a bounded mutable overlay."""

    def __init__(
        self,
        *,
        agent_config: Path | str,
        python_executable: Path | str,
        runs_dir: Path | str,
        cwd: Path | str = ".",
        api_key_env: str = "LLM_API_KEY",
        timeout_seconds: float = 1800.0,
        passthrough_env: Sequence[str] = (),
        python_paths: Sequence[Path | str] = (),
        skill_registry: Mapping[str, Any] | None = None,
        execution_capabilities: Mapping[str, Any] | None = None,
    ) -> None:
        config_path = Path(agent_config).resolve()
        if not config_path.is_file():
            raise ValueError(f"NexAU agent config does not exist: {config_path}")
        executable = Path(python_executable).expanduser()
        if not executable.is_absolute():
            executable = Path.cwd() / executable
        self.agent_config = config_path
        self.python_executable = str(executable.absolute())
        self.runs_dir = Path(runs_dir).resolve()
        self.cwd = Path(cwd).resolve()
        self.api_key_env = api_key_env
        self.timeout_seconds = float(timeout_seconds)
        env_names = {str(name) for name in passthrough_env}
        env_names.add(api_key_env)
        self.passthrough_env = tuple(sorted(env_names))
        self.python_paths = tuple(str(Path(item).resolve()) for item in python_paths)
        self.skill_registry = resolve_skill_registry(skill_registry)
        defaults = {
            "backend": "nexau-python",
            "strength": "process",
            "network_isolation": False,
            "read_only_root": False,
            "verifier_separate": False,
            "security_boundary": False,
            "adapter_contract": "nexau-python/v1",
        }
        defaults.update(dict(execution_capabilities or {}))
        self.execution_capabilities = defaults

    def _prepare_run(self, *, task: TaskCase, run_root: Path) -> Mapping[str, Any]:
        """Trusted hook for benchmark adapters to prepare a fresh task workspace."""

        del task, run_root
        return {}

    def _finalize_result(
        self, *, task: TaskCase, run_root: Path, payload: Mapping[str, Any]
    ) -> Any:
        """Trusted hook for benchmark adapters to select a verifier-saved result."""

        del task, run_root
        return payload.get("result")

    def capabilities(self) -> Mapping[str, Any]:
        return dict(self.execution_capabilities)

    def preflight(self) -> Mapping[str, Any]:
        """Verify that the configured interpreter can import NexAU.

        This catches a subtle but destructive configuration error where
        dereferencing ``venv/bin/python`` executes the base interpreter and
        loses the virtualenv's installed packages.
        """

        executable = Path(self.python_executable)
        if not executable.is_file():
            raise ValueError(
                f"NexAU Python executable does not exist: {self.python_executable}"
            )
        environment = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "LANG": "C.UTF-8",
        }
        if self.python_paths:
            environment["PYTHONPATH"] = os.pathsep.join(self.python_paths)
        completed = subprocess.run(
            [
                self.python_executable,
                "-c",
                (
                    "import json, nexau, sys; "
                    "print(json.dumps({'executable': sys.executable, "
                    "'nexau': nexau.__file__}))"
                ),
            ],
            cwd=self.cwd,
            env=environment,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if completed.returncode:
            detail = (completed.stderr or completed.stdout)[-2000:]
            raise ValueError(
                "configured NexAU interpreter failed import preflight: "
                f"{detail.strip()}"
            )
        try:
            descriptor = json.loads(completed.stdout.strip().splitlines()[-1])
        except (IndexError, json.JSONDecodeError) as exc:
            raise ValueError(
                "configured NexAU interpreter emitted no preflight descriptor"
            ) from exc
        return {
            "ok": True,
            "configured_executable": self.python_executable,
            "runtime_executable": descriptor.get("executable"),
            "nexau_module": descriptor.get("nexau"),
        }

    def run(
        self,
        *,
        state: AgentState,
        components: Mapping[str, Any],
        task: TaskCase,
        sandbox: Sandbox,
        budget: BudgetMeter,
    ) -> EpisodeResult:
        if not isinstance(task.input, Mapping) or task.input.get("adapter") != "nexau/v1":
            raise ValueError("NexAUInnerRuntime received a non-NexAU TaskCase")
        message = task.input.get("message", task.input.get("payload"))
        if not isinstance(message, str) and not isinstance(message, list):
            raise ValueError("NexAU task input requires string or message-list 'message'")
        run_id = f"{task.task_id}-{uuid.uuid4().hex[:12]}"
        run_root = self.runs_dir / run_id
        if run_root.exists():
            raise RuntimeError(f"refusing to reuse NexAU run directory: {run_root}")
        run_root.mkdir(parents=True, exist_ok=False)
        prepared_context = dict(self._prepare_run(task=task, run_root=run_root))
        request = {
            "schema": "evogate.nexau-request/v1",
            "agent_config": str(self.agent_config),
            "api_key_env": self.api_key_env,
            "task_id": task.task_id,
            "state_id": state.state_id,
            "episode_seed": task.seed,
            "message": message,
            "task_context": {
                key: value
                for key, value in task.input.items()
                if key not in {"adapter", "message", "payload"}
            }
            | prepared_context,
            "model": dict(components.get("model", {})),
            "harness": dict(components.get("harness", {})),
            "skill_registry": self.skill_registry,
            "run_dir": str(run_root),
        }
        worker = Path(__file__).with_name("workers") / "nexau_worker.py"
        environment = {
            "EVOGATE_RUN_DIR": str(run_root),
            "XDG_CACHE_HOME": str(run_root / "xdg-cache"),
            "XDG_CONFIG_HOME": str(run_root / "xdg-config"),
            "XDG_DATA_HOME": str(run_root / "xdg-data"),
        }
        environment.update(
            {name: os.environ[name] for name in self.passthrough_env if name in os.environ}
        )
        if self.python_paths:
            environment["PYTHONPATH"] = os.pathsep.join(self.python_paths)
        result = sandbox.run(
            CommandSpec(
                argv=(self.python_executable, str(worker)),
                cwd=self.cwd,
                env=environment,
                stdin=json.dumps(request, ensure_ascii=False).encode("utf-8"),
                timeout_seconds=remaining_timeout(budget, self.timeout_seconds),
                network="host",
                read_only_root=False,
            )
        )
        payload = worker_payload(result.stdout, result.stderr, "evogate.nexau-result/v1")
        usage_row = dict(payload.get("usage", {}))
        usage = BudgetUsage(
            tokens=int(usage_row.get("tokens", 0)),
            tool_calls=int(usage_row.get("tool_calls", 0)),
            wall_seconds=result.wall_seconds,
        )
        budget.consume(usage)
        error = payload.get("error")
        if not error and result.returncode:
            error = f"nexau worker exited {result.returncode}"
        if error:
            (run_root / "worker_error.json").write_text(
                json.dumps(
                    {
                        "schema": "evogate.nexau-worker-error/v1",
                        "error": str(error),
                        "traceback": payload.get("traceback"),
                        "returncode": result.returncode,
                        "stderr": result.stderr.decode("utf-8", "replace")[-8000:],
                        "lifecycle": list(result.lifecycle),
                    },
                    indent=2,
                    ensure_ascii=False,
                    default=str,
                )
                + "\n",
                encoding="utf-8",
            )
        final_result = self._finalize_result(
            task=task, run_root=run_root, payload=payload
        )
        return EpisodeResult(
            task_id=task.task_id,
            output={
                "adapter": "nexau/v1",
                "result": final_result,
                "agent_state": payload.get("agent_state"),
                "run_id": run_id,
                "sampling_seed": payload.get("sampling_seed"),
            },
            trace=tuple(
                item for item in payload.get("trace", ()) if isinstance(item, dict)
            ),
            usage=usage,
            error=str(error) if error else None,
        )


def create_plugins(config: Mapping[str, Any], base_dir: Path) -> PluginSet:
    """Evaluation-only NexAU factory; supply an outer system to evolve it."""

    tasks = AgentTaskSource("nexau/v1", dict(config["splits"]), base_dir=base_dir)
    return PluginSet(
        tasks=tasks,
        inner=NexAUInnerRuntime(
            agent_config=resolve_path(str(config["agent_config"]), base_dir),
            python_executable=(
                resolve_executable(str(config["python_executable"]), base_dir)
                if config.get("python_executable")
                else os.sys.executable
            ),
            runs_dir=resolve_path(str(config.get("runs_dir", "nexau-runs")), base_dir),
            cwd=base_dir,
            api_key_env=str(config.get("api_key_env", "LLM_API_KEY")),
            timeout_seconds=float(config.get("timeout_seconds", 1800.0)),
            passthrough_env=tuple(config.get("passthrough_env", ())),
            python_paths=tuple(
                resolve_path(str(item), base_dir)
                for item in config.get("python_paths", ())
            ),
            skill_registry=resolve_skill_registry(
                dict(config.get("skill_registry", {})), base_dir=base_dir
            ),
            execution_capabilities=dict(config.get("execution_capabilities", {})),
        ),
        evaluator=ExpectedOutputEvaluator(
            tasks.targets,
            output_pointer=str(config.get("output_pointer", "/result")),
            error_reward=float(config.get("error_reward", 0.0)),
        ),
        outer=NoProposalOuter(),
        sandbox=LocalProcessSandbox(),
        candidate_validator=NexAUHarnessValidator(
            dict(config.get("skill_registry", {}))
        ),
        metadata={"integration": "nexau", "factory_mode": "evaluation-only"},
    )
