"""Dependency-isolated bridge for NexAU 0.4.x agents."""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
import sys
import traceback
from enum import Enum
from pathlib import Path
from typing import Any, Mapping


_AGENT_FIELDS = {
    "system_prompt",
    "system_prompt_suffix",
    "tool_call_mode",
    "max_context_tokens",
    "max_iterations",
    "timeout",
}
_LLM_FIELDS = {
    "temperature",
    "max_tokens",
    "top_p",
    "frequency_penalty",
    "presence_penalty",
    "stream",
    "enable_thinking",
}
_CONTEXT_COMPACTION_FIELDS = {
    "max_context_tokens",
    "auto_compact",
    "emergency_compact_enabled",
    "threshold",
    "compaction_strategy",
    "keep_iterations",
    "keep_user_rounds",
}


def _jsonable(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        return {
            field.name: _jsonable(getattr(value, field.name))
            for field in dataclasses.fields(value)
        }
    if hasattr(value, "model_dump"):
        return _jsonable(value.model_dump(mode="json"))
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def _registered_skill(
    skill_id: str, registry: Mapping[str, Any]
) -> Any:
    row = registry.get(skill_id)
    if not isinstance(row, Mapping):
        raise ValueError(f"NexAU harness selected unregistered skill: {skill_id}")
    path = Path(str(row.get("path") or "")).resolve()
    expected = {
        str(name): str(digest)
        for name, digest in dict(row.get("files_sha256") or {}).items()
    }
    if not path.is_dir() or not expected:
        raise ValueError(f"invalid protected NexAU skill registry entry: {skill_id}")
    if path.is_symlink() or any(item.is_symlink() for item in path.rglob("*")):
        raise ValueError(f"protected NexAU skill contains a symlink: {skill_id}")
    actual = {
        item.relative_to(path).as_posix()
        for item in path.rglob("*")
        if item.is_file()
    }
    if actual != set(expected):
        raise ValueError(f"protected NexAU skill manifest mismatch: {skill_id}")
    for name, digest in expected.items():
        relative = Path(name)
        if relative.is_absolute() or not relative.parts or ".." in relative.parts:
            raise ValueError(f"invalid protected NexAU skill file: {skill_id}/{name}")
        observed = hashlib.sha256((path / relative).read_bytes()).hexdigest()
        if observed != digest:
            raise ValueError(f"protected NexAU skill hash mismatch: {skill_id}/{name}")
    from nexau.archs.main_sub.skill import Skill

    return Skill.from_folder(path)


def _apply_overlay(
    config: Any,
    model: Mapping[str, Any],
    harness: Mapping[str, Any],
    skill_registry: Mapping[str, Any],
) -> None:
    unknown = set(harness) - _AGENT_FIELDS - {
        "llm",
        "run",
        "skills",
        "context_compaction",
    }
    if unknown:
        raise ValueError(f"unsupported NexAU harness fields: {sorted(unknown)}")
    for field in _AGENT_FIELDS:
        if field in harness:
            setattr(config, field, harness[field])
    if "system_prompt" in harness:
        config.system_prompt_type = "string"
    llm = getattr(config, "llm_config", None)
    if llm is None:
        raise ValueError("NexAU agent config requires llm_config")
    served_model = model.get("served_model", model.get("model"))
    if served_model:
        llm.model = str(served_model)
    if model.get("base_url"):
        llm.base_url = str(model["base_url"])
    if model.get("api_type"):
        llm.api_type = str(model["api_type"])
    llm_overlay = harness.get("llm", {})
    if not isinstance(llm_overlay, Mapping):
        raise TypeError("NexAU harness.llm must be a mapping")
    unknown_llm = set(llm_overlay) - _LLM_FIELDS
    if unknown_llm:
        raise ValueError(f"unsupported NexAU harness.llm fields: {sorted(unknown_llm)}")
    for field, value in llm_overlay.items():
        if field == "enable_thinking":
            if not isinstance(value, bool):
                raise TypeError("NexAU harness.llm.enable_thinking must be boolean")
            extra_body = llm.extra_params.setdefault("extra_body", {})
            if not isinstance(extra_body, dict):
                raise TypeError("NexAU llm_config.extra_body must be a mapping")
            chat_template_kwargs = extra_body.setdefault(
                "chat_template_kwargs", {}
            )
            if not isinstance(chat_template_kwargs, dict):
                raise TypeError(
                    "NexAU llm_config chat_template_kwargs must be a mapping"
                )
            chat_template_kwargs["enable_thinking"] = value
        else:
            setattr(llm, field, value)

    if "skills" in harness:
        selected = harness["skills"]
        if (
            not isinstance(selected, list)
            or any(not isinstance(item, str) for item in selected)
            or len(set(selected)) != len(selected)
        ):
            raise TypeError("NexAU harness.skills must be a unique string list")
        config.skills = [
            _registered_skill(skill_id, skill_registry)
            for skill_id in selected
        ]

    if "context_compaction" in harness:
        compaction = harness["context_compaction"]
        if not isinstance(compaction, Mapping):
            raise TypeError("NexAU harness.context_compaction must be a mapping")
        unknown_compaction = set(compaction) - _CONTEXT_COMPACTION_FIELDS
        if unknown_compaction:
            raise ValueError(
                "unsupported NexAU context_compaction fields: "
                f"{sorted(unknown_compaction)}"
            )
        if (
            "max_context_tokens" in harness
            and compaction.get("max_context_tokens") is not None
            and harness["max_context_tokens"]
            != compaction["max_context_tokens"]
        ):
            raise ValueError(
                "NexAU max_context_tokens must match "
                "context_compaction.max_context_tokens"
            )
        from nexau.archs.main_sub.execution.middleware.context_compaction import (
            ContextCompactionMiddleware,
        )

        retained = [
            item
            for item in (config.middlewares or [])
            if not isinstance(item, ContextCompactionMiddleware)
        ]
        config.middlewares = [
            *retained,
            ContextCompactionMiddleware(**dict(compaction)),
        ]


def _apply_sampling_seed(config: Any, value: Any) -> int | None:
    if value is None:
        return None
    # EvoGate derives an unsigned 64-bit paired seed. OpenAI-compatible
    # servers commonly validate a signed 63-bit integer.
    sampling_seed = int(value) % (2**63 - 1)
    config.llm_config.set_param("seed", sampling_seed)
    return sampling_seed


def _event_dict(event: Any) -> dict[str, Any]:
    normalized = _jsonable(event)
    if isinstance(normalized, dict):
        return normalized
    return {"type": type(event).__name__, "value": normalized}


def _run(request: dict[str, Any]) -> dict[str, Any]:
    from nexau import Agent, AgentConfig
    from nexau.archs.main_sub.execution.hooks import HookResult, Middleware
    from nexau.archs.main_sub.execution.middleware.agent_events_middleware import (
        AgentEventsMiddleware,
    )

    class UsageAccountingMiddleware(Middleware):
        """Count completed calls once, independently of emitted trace events."""

        def __init__(self) -> None:
            self.tokens = 0
            self.tool_calls = 0

        def after_model(self, hook_input: Any) -> Any:
            response = hook_input.model_response
            if response is not None:
                usage = response.usage
                if isinstance(usage, Mapping):
                    total = usage.get("total_tokens", 0)
                else:
                    total = getattr(usage, "total_tokens", 0)
                self.tokens += int(total or 0)
            return HookResult.no_changes()

        def after_tool(self, hook_input: Any) -> Any:
            self.tool_calls += 1
            return HookResult.no_changes()

    config = AgentConfig.from_yaml(Path(request["agent_config"]))
    model = dict(request.get("model", {}))
    harness = dict(request.get("harness", {}))
    skill_registry = dict(request.get("skill_registry", {}))
    _apply_overlay(config, model, harness, skill_registry)
    sampling_seed = _apply_sampling_seed(
        config, request.get("episode_seed")
    )
    api_key = os.environ.get(str(request.get("api_key_env", "LLM_API_KEY")))
    if api_key:
        config.llm_config.api_key = api_key
    events: list[dict[str, Any]] = []
    accounting = UsageAccountingMiddleware()
    event_middleware = AgentEventsMiddleware(
        session_id=f"evogate-{request['task_id']}",
        on_event=lambda event: events.append(_event_dict(event)),
    )
    config.middlewares = [*(config.middlewares or []), accounting, event_middleware]
    agent = Agent(config=config)
    run_options = harness.get("run", {})
    if not isinstance(run_options, Mapping):
        raise TypeError("NexAU harness.run must be a mapping")
    unknown_run = set(run_options) - {"context", "state", "config"}
    if unknown_run:
        raise ValueError(f"unsupported NexAU harness.run fields: {sorted(unknown_run)}")
    context = {
        "working_directory": str(request["run_dir"]),
        **dict(request.get("task_context", {})),
        **dict(run_options.get("context", {})),
    }
    result = agent.run(
        message=request["message"],
        context=context,
        state=run_options.get("state"),
        config=run_options.get("config"),
    )
    agent_state = None
    if isinstance(result, tuple):
        result, agent_state = result
    return {
        "schema": "evogate.nexau-result/v1",
        "status": "success",
        "result": _jsonable(result),
        "agent_state": _jsonable(agent_state),
        "sampling_seed": sampling_seed,
        "trace": events,
        "usage": {"tokens": accounting.tokens, "tool_calls": accounting.tool_calls},
    }


def main() -> int:
    request = json.load(sys.stdin)
    try:
        result = _run(request)
    except BaseException as exc:
        result = {
            "schema": "evogate.nexau-result/v1",
            "status": "error",
            "error": f"{type(exc).__name__}: {exc}",
            "traceback": traceback.format_exc(limit=40),
            "trace": [],
            "usage": {},
        }
    sys.stdout.write(json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
