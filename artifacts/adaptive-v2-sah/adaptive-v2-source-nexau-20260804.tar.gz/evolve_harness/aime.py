"""Pinned AIME task loading and exact-answer evaluation helpers.

The public benchmark manifest contains problem statements and split membership
only.  Ground-truth answers live in a verifier-only manifest and are never
placed in the NexAU task context or outer proposer prompt.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Iterable, Mapping


ROOT = Path(__file__).resolve().parents[1]
BENCHMARK_PATH = (
    ROOT / "evolve_harness" / "configs" / "benchmarks" / "harness_only_aime2024.jsonl"
)
ANSWER_MANIFEST_PATH = (
    ROOT
    / "evolve_harness"
    / "configs"
    / "benchmarks"
    / "verifier"
    / "aime_2022_2024_answers.json"
)

INITIAL_SYSTEM_PROMPT = (
    "You solve one AIME competition mathematics problem. Work independently "
    "and reason carefully. Check algebra, arithmetic, boundary cases, and the "
    "problem's exact question before committing. The answer is an integer "
    "from 000 through 999. End with exactly one final answer in the form "
    "\\boxed{NNN}, using three digits and no text after it. Do not refer to "
    "other benchmark questions, memorized answer keys, evaluators, or hidden "
    "feedback."
)

_BOXED = re.compile(r"\\boxed\s*\{\s*([0-9]{1,3})\s*\}")
_FINAL = re.compile(
    r"(?:final\s+answer|answer\s+is)\s*[:=]?\s*\$?\s*([0-9]{1,3})\b",
    re.IGNORECASE,
)


def load_jsonl(path: Path = BENCHMARK_PATH) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError(f"AIME row is not a mapping: {path}")
                rows.append(value)
    return rows


def load_answer_manifest(path: Path = ANSWER_MANIFEST_PATH) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("schema") != "adaptive.aime-answer-manifest/v1":
        raise ValueError(f"unsupported AIME answer manifest: {path}")
    answers = value.get("answers")
    if not isinstance(answers, dict):
        raise ValueError(f"AIME answer manifest has no answer mapping: {path}")
    return value


def answer_for(aime_id: str, path: Path = ANSWER_MANIFEST_PATH) -> int:
    manifest = load_answer_manifest(path)
    raw = manifest["answers"].get(aime_id)
    if raw is None:
        raise KeyError(f"unknown AIME problem ID: {aime_id}")
    answer = int(raw)
    if not 0 <= answer <= 999:
        raise ValueError(f"invalid AIME answer for {aime_id}: {raw!r}")
    return answer


def extract_answer(text: str) -> int | None:
    """Extract the last explicit AIME answer without evaluating expressions."""

    source = str(text or "")
    boxed = _BOXED.findall(source)
    if boxed:
        return int(boxed[-1])
    final = _FINAL.findall(source)
    if final:
        return int(final[-1])
    return None


def evaluate_response(*, aime_id: str, response: str) -> dict[str, Any]:
    expected = answer_for(aime_id)
    predicted = extract_answer(response)
    correct = predicted == expected
    return {
        "correct": correct,
        "combined_score": 1.0 if correct else 0.0,
        "score": 1.0 if correct else 0.0,
        "valid": 1.0 if predicted is not None else 0.0,
        "answer_extracted": predicted is not None,
        "predicted_answer": predicted,
        "expected_answer": expected,
        "error": None if predicted is not None else "no_integer_answer_extracted",
    }


def rows_for_split(
    split: str, rows: Iterable[Mapping[str, Any]] | None = None
) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    for row in rows if rows is not None else load_jsonl():
        metadata = dict(row.get("metadata") or {})
        if split in metadata.get("evogate_splits", []):
            selected.append(dict(row))
    return selected
