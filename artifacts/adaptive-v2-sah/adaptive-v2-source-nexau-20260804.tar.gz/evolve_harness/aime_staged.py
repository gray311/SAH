"""Shared fail-closed helpers for staged AIME harness evaluation."""
from __future__ import annotations

import hashlib
import json
import os
import random
import statistics
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Mapping, Sequence

from evogate.checkpoints import open_store
from evolve_harness.aime import extract_answer


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL_PATH = (
    ROOT / "evolve_harness/configs/benchmarks/aime_scaleup_protocol.json"
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_protocol() -> dict[str, Any]:
    value = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
    if value.get("schema") != "adaptive.aime-scaleup-protocol/v1":
        raise RuntimeError("unsupported AIME scale-up protocol")
    return value


def verify_file(path: Path, expected: str) -> None:
    observed = sha256_file(path)
    if observed != expected:
        raise RuntimeError(
            f"sealed manifest hash mismatch for {path}: {observed} != {expected}"
        )


def exclusive_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(
        path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
    except BaseException:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        raise
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def exclusive_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(
        path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644
    )
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write(value)
        handle.flush()
        os.fsync(handle.fileno())
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def load_rows(path: Path, *, expected_year: int) -> list[dict[str, Any]]:
    rows = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(rows) != 30 or any(
        int(row["metadata"]["year"]) != expected_year for row in rows
    ):
        raise RuntimeError(
            f"expected exactly 30 AIME {expected_year} rows in {path}"
        )
    return sorted(
        rows,
        key=lambda row: (
            str(row["metadata"]["part"]),
            int(row["metadata"]["problem_number"]),
        ),
    )


def load_answers(path: Path, *, expected_year: int) -> dict[str, int]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if int(value.get("year", -1)) != expected_year:
        raise RuntimeError(f"wrong answer-manifest year in {path}")
    answers = {str(key): int(item) for key, item in value["answers"].items()}
    if len(answers) != 30:
        raise RuntimeError(f"expected 30 verifier answers in {path}")
    return answers


def stable_seed(base_seed: int, role: str, aime_id: str) -> int:
    return int.from_bytes(
        hashlib.sha256(f"{base_seed}:{role}:{aime_id}".encode()).digest()[:8],
        "big",
    ) % (2**63 - 1)


def request_completion(
    *,
    base_url: str,
    model: str,
    prompt: str,
    harness: Mapping[str, Any],
    seed: int,
    common_max_tokens: int,
) -> dict[str, Any]:
    llm = dict(harness.get("llm") or {})
    if int(llm.get("max_tokens", common_max_tokens)) != common_max_tokens:
        raise RuntimeError("finalist violates the common max-token ceiling")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": str(harness["system_prompt"])},
            {"role": "user", "content": prompt},
        ],
        "temperature": float(llm.get("temperature", 0.6)),
        "top_p": float(llm.get("top_p", 0.95)),
        "max_tokens": common_max_tokens,
        "seed": seed,
        "stream": False,
        "chat_template_kwargs": {
            "enable_thinking": bool(llm.get("enable_thinking", False))
        },
    }
    request = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer local-no-auth",
        },
        method="POST",
    )
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=1200) as response:
                return json.load(response)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(2**attempt)
    raise RuntimeError(f"completion failed after three attempts: {last_error}")


def evaluate_variants(
    *,
    variants: Sequence[Mapping[str, Any]],
    rows: Sequence[Mapping[str, Any]],
    base_seeds: Sequence[int],
    role: str,
    answers: Mapping[str, int],
    base_url: str,
    model: str,
    workers: int,
    common_max_tokens: int,
) -> list[dict[str, Any]]:
    """Evaluate variants with problem×seed×variant interleaving."""

    jobs = [
        (row, base_seed, variant)
        for row in rows
        for base_seed in base_seeds
        for variant in variants
    ]

    def run(job: tuple[Mapping[str, Any], int, Mapping[str, Any]]) -> dict[str, Any]:
        row, base_seed, variant = job
        metadata = dict(row["metadata"])
        aime_id = str(metadata["aime_id"])
        request_seed = stable_seed(base_seed, role, aime_id)
        started = time.monotonic()
        response = request_completion(
            base_url=base_url,
            model=model,
            prompt=str(row["input"]),
            harness=dict(variant["harness"]),
            seed=request_seed,
            common_max_tokens=common_max_tokens,
        )
        choice = dict(response.get("choices", [{}])[0])
        message = dict(choice.get("message") or {})
        content = str(message.get("content") or "")
        reasoning = str(message.get("reasoning_content") or "")
        predicted = extract_answer(content)
        expected = int(answers[aime_id])
        return {
            "label": variant["label"],
            "state_id": variant["state_id"],
            "aime_id": aime_id,
            "base_seed": base_seed,
            "request_seed": request_seed,
            "predicted_answer": predicted,
            "expected_answer": expected,
            "correct": predicted == expected,
            "answer_extracted": predicted is not None,
            "finish_reason": choice.get("finish_reason"),
            "content": content,
            "reasoning_content": reasoning,
            "usage": response.get("usage", {}),
            "elapsed_seconds": time.monotonic() - started,
        }

    records: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(run, job) for job in jobs]
        for future in as_completed(futures):
            records.append(future.result())
    results: list[dict[str, Any]] = []
    for variant in variants:
        selected = [
            item for item in records if item["state_id"] == variant["state_id"]
        ]
        selected.sort(key=lambda item: (item["aime_id"], item["base_seed"]))
        completion_tokens = sum(
            int(dict(item.get("usage") or {}).get("completion_tokens") or 0)
            for item in selected
        )
        correct = sum(bool(item["correct"]) for item in selected)
        results.append(
            {
                "label": variant["label"],
                "state_id": variant["state_id"],
                "harness": dict(variant["harness"]),
                "correct": correct,
                "total": len(selected),
                "accuracy": correct / len(selected),
                "answers_extracted": sum(
                    bool(item["answer_extracted"]) for item in selected
                ),
                "completion_tokens": completion_tokens,
                "mean_completion_tokens": completion_tokens / len(selected),
                "results": selected,
            }
        )
    return results


def paired_analysis(
    candidate: Mapping[str, Any],
    baseline: Mapping[str, Any],
    *,
    bootstrap_seed: int,
    samples: int,
) -> dict[str, Any]:
    left = {
        (str(item["aime_id"]), int(item["base_seed"])): bool(item["correct"])
        for item in candidate["results"]
    }
    right = {
        (str(item["aime_id"]), int(item["base_seed"])): bool(item["correct"])
        for item in baseline["results"]
    }
    if set(left) != set(right):
        raise RuntimeError("paired result tables do not match")
    by_problem: dict[str, list[float]] = {}
    for key, value in left.items():
        by_problem.setdefault(key[0], []).append(float(value) - float(right[key]))
    problem_deltas = [statistics.fmean(values) for values in by_problem.values()]
    observed = statistics.fmean(problem_deltas)
    rng = random.Random(bootstrap_seed)
    bootstrap = sorted(
        statistics.fmean(rng.choice(problem_deltas) for _ in problem_deltas)
        for _ in range(samples)
    )
    return {
        "accuracy_delta": observed,
        "cluster_bootstrap_one_sided_90_lcb": bootstrap[int(samples * 0.10)],
        "cluster_bootstrap_two_sided_95_ci": [
            bootstrap[int(samples * 0.025)],
            bootstrap[int(samples * 0.975) - 1],
        ],
        "cluster_unit": "problem",
        "problems": len(problem_deltas),
        "paired_samples": len(left),
        "candidate_only_correct": sum(left[key] and not right[key] for key in left),
        "baseline_only_correct": sum(right[key] and not left[key] for key in left),
    }


def confirmed_archive(
    run_dir: Path, archive_size: int, *, maximum_tie_expansion: int = 8
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    store = open_store(run_dir)
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    initial_state_id = str(summary["initial_state_id"])
    initial_state = store.get_state(initial_state_id)
    initial = {
        "label": "initial",
        "state_id": initial_state_id,
        "harness": store.get_json(initial_state.components["harness"]),
    }
    confirmed: dict[str, dict[str, Any]] = {}
    for ref_name, checkpoint_id in store.list_checkpoint_refs().items():
        if "/candidates/" not in ref_name:
            continue
        checkpoint = store.get_checkpoint(checkpoint_id)
        if checkpoint.kind != "candidate" or not checkpoint.metadata.get(
            "promotion_shortlisted"
        ):
            continue
        if not {"outcome", "promotion"}.issubset(checkpoint.evaluations):
            continue
        outcome = store.get_json(checkpoint.evaluations["outcome"])
        promotion = store.get_json(checkpoint.evaluations["promotion"])
        score = statistics.fmean(
            [float(outcome["score"]), float(promotion["score"])]
        )
        state = store.get_state(checkpoint.state_id)
        row = {
            "label": str(checkpoint.metadata["proposal_id"]),
            "state_id": checkpoint.state_id,
            "harness": store.get_json(state.components["harness"]),
            "screen_score": float(outcome["score"]),
            "confirmation_score": float(promotion["score"]),
            "two_seed_calibration_score": score,
            "checkpoint_id": checkpoint_id,
        }
        previous = confirmed.get(checkpoint.state_id)
        if previous is None or score > previous["two_seed_calibration_score"]:
            confirmed[checkpoint.state_id] = row
    ranked = sorted(
        confirmed.values(),
        key=lambda item: item["two_seed_calibration_score"],
        reverse=True,
    )
    if len(ranked) > archive_size:
        cutoff = ranked[archive_size - 1]["two_seed_calibration_score"]
        ranked = [
            item
            for item in ranked
            if item["two_seed_calibration_score"] >= cutoff
        ]
    if len(ranked) > maximum_tie_expansion:
        raise RuntimeError(
            "archive cutoff tie exceeds preregistered expansion; a third "
            "AIME-2022 confirmation seed is required before hidden selection"
        )
    return initial, ranked
