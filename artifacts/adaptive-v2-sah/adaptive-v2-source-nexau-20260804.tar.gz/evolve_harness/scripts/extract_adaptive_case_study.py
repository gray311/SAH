#!/usr/bin/env python3
"""Extract an auditable round-by-round Adaptive EvoGate case-study record."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any

from evogate.ledger import EventLedger


PROMPT_SECTION_RE = re.compile(
    r"<!-- HARNESSOPT:([A-Za-z0-9_.-]+) -->\n"
    r"(.*?)\n<!-- /HARNESSOPT:\1 -->",
    re.DOTALL,
)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def artifact_path(run: Path, digest: str) -> Path:
    algorithm, separator, value = digest.partition(":")
    if algorithm != "sha256" or not separator or len(value) != 64:
        raise ValueError(f"invalid artifact digest: {digest}")
    return run / "artifacts" / "objects" / value[:2] / value[2:]


def artifact(run: Path, ref: dict[str, Any] | str) -> Any:
    digest = ref if isinstance(ref, str) else str(ref["digest"])
    return read_json(artifact_path(run, digest))


def digest_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def prompt_sections(prompt: str) -> dict[str, str]:
    return {
        match.group(1): match.group(2).strip()
        for match in PROMPT_SECTION_RE.finditer(prompt)
    }


def compact_evidence(item: dict[str, Any]) -> dict[str, Any]:
    trace = item.get("trace")
    trace_rows = list(trace) if isinstance(trace, (list, tuple)) else []
    type_counts = Counter(
        str(row.get("type") or "UNKNOWN")
        for row in trace_rows
        if isinstance(row, dict)
    )
    tool_observations: list[dict[str, Any]] = []
    for row in trace_rows:
        if not isinstance(row, dict) or row.get("type") != "TOOL_CALL_RESULT":
            continue
        content = row.get("content")
        parsed: Any = None
        if isinstance(content, str):
            try:
                parsed = json.loads(content)
            except json.JSONDecodeError:
                parsed = None
        if not isinstance(parsed, dict):
            continue
        observation = {
            key: parsed.get(key)
            for key in (
                "error",
                "error_type",
                "success",
                "improved",
                "best_score",
                "check_index",
            )
            if parsed.get(key) is not None
        }
        metrics = parsed.get("metrics")
        if isinstance(metrics, dict):
            observation["metrics"] = {
                key: metrics.get(key)
                for key in ("score", "sum_radii", "valid", "validity")
                if metrics.get(key) is not None
            }
        if observation:
            tool_observations.append(observation)
    output = item.get("output")
    output_row = dict(output) if isinstance(output, dict) else {}
    return {
        "evidence_id": item.get("evidence_id"),
        "task_id": item.get("task_id"),
        "reward": item.get("reward"),
        "metrics": item.get("metrics"),
        "feedback": item.get("feedback"),
        "run_id": output_row.get("run_id"),
        "trace_event_counts": dict(sorted(type_counts.items())),
        "tool_observations": tool_observations,
    }


def evaluation_record(
    run: Path, summary: dict[str, Any] | None
) -> dict[str, Any] | None:
    if summary is None:
        return None
    repeat_records = [
        artifact(run, dict(ref))
        for ref in summary.get("record_artifacts", [])
        if isinstance(ref, dict)
    ]
    return {
        "split": summary.get("split"),
        "state_id": summary.get("state_id"),
        "score": summary.get("score"),
        "score_sem": summary.get("score_sem"),
        "repeat_scores": [row.get("reward") for row in repeat_records],
        "behavior_fingerprints": summary.get("behavior_fingerprints", []),
        "integrity_flags": summary.get("integrity_flags", []),
        "usage": summary.get("usage", {}),
        "summary_ref": summary.get("_ref"),
    }


def controller_from_state(run: Path, state_id: str) -> dict[str, Any]:
    digest = state_id.removeprefix("sha256:")
    state = read_json(
        run / "artifacts" / "optimizer-states" / f"{digest}.json"
    )
    ref = dict(state.get("components") or {}).get("controller")
    return artifact(run, dict(ref)) if isinstance(ref, dict) else {}


def optimizer_state(run: Path, state_id: str) -> dict[str, Any]:
    digest = state_id.removeprefix("sha256:")
    return read_json(
        run / "artifacts" / "optimizer-states" / f"{digest}.json"
    )


def state_component(
    run: Path, state_id: str, component_name: str
) -> tuple[dict[str, Any] | None, Any]:
    if not state_id:
        return None, None
    digest = state_id.removeprefix("sha256:")
    state = read_json(run / "artifacts" / "states" / f"{digest}.json")
    ref = dict(state.get("components") or {}).get(component_name)
    if not isinstance(ref, dict):
        return None, None
    return dict(ref), artifact(run, dict(ref))


def extract(task_root: Path) -> dict[str, Any]:
    task_root = task_root.resolve()
    campaign = read_json(task_root / "campaign_summary.json")
    task_ids = list((campaign.get("tasks") or {}).keys())
    if len(task_ids) != 1:
        raise ValueError("task root must contain exactly one campaign task")
    task = task_ids[0]
    resolved_config_path = task_root / "resolved-configs" / f"{task}.json"
    resolved_config = read_json(resolved_config_path)
    optimizer_config = dict(
        dict(resolved_config.get("plugins") or {})
        .get("config", {})
        .get("optimizer", {})
    )
    proposer_seed = int(optimizer_config.get("seed", 0))
    run = task_root / "runs" / task
    events_path = run / "events.jsonl"
    events = read_jsonl(events_path)
    ledger_status = EventLedger(events_path).verify()
    event_counts = Counter(
        str(event.get("event") or "UNKNOWN") for event in events
    )
    episode_records = [
        artifact(run, dict(event["payload"]["record"]))
        for event in events
        if event.get("event") == "episode_finished"
    ]
    episode_split_counts = Counter(
        str(record.get("split") or "UNKNOWN")
        for record in episode_records
    )

    current_round: int | None = None
    by_round: dict[int, dict[str, list[dict[str, Any]]]] = {}
    for event in events:
        name = str(event.get("event") or "")
        payload = dict(event.get("payload") or {})
        if name == "round_started":
            current_round = int(payload["round"])
        event_round = payload.get("round", current_round)
        if event_round is None:
            continue
        round_index = int(event_round)
        row = by_round.setdefault(round_index, {})
        row.setdefault(name, []).append(event)

    rounds: list[dict[str, Any]] = []
    proposer_system: str | None = None
    for round_index in sorted(by_round):
        indexed = by_round[round_index]
        proposal_event = indexed["proposals_received"][0]
        proposal_payload = dict(proposal_event["payload"])
        context_ref = dict(proposal_payload["context"])
        context = dict(artifact(run, context_ref))
        harness = dict(
            dict(context.get("component_views") or {}).get("harness") or {}
        )
        system_prompt = str(harness.pop("/system_prompt", ""))

        batch_ref = dict(proposal_payload["batch_artifacts"][0])
        batch = dict(artifact(run, batch_ref))
        batch_metadata = dict(proposal_payload.get("batch_metadata") or {})
        pre_round_optimizer_state = optimizer_state(
            run, str(batch_metadata["optimizer_state_id"])
        )
        optimizer_archive_ref = dict(
            dict(pre_round_optimizer_state.get("components") or {})[
                "archive"
            ]
        )
        optimizer_archive = dict(artifact(run, optimizer_archive_ref))
        compilation_by_id = {
            str(item.get("proposal_id")): dict(item)
            for item in batch.get("compilation_records", [])
            if isinstance(item, dict)
        }
        policy_samples: list[dict[str, Any]] = []
        for item in batch.get("policy_records", []):
            if not isinstance(item, dict):
                continue
            proposal_id = str(item.get("proposal_id"))
            compilation = compilation_by_id.get(proposal_id, {})
            policy_samples.append(
                {
                    "proposal_id": proposal_id,
                    "sample_index": item.get("sample_index"),
                    "policy_status": item.get("status"),
                    "policy_error": item.get("error"),
                    "action": item.get("action"),
                    "raw_response": item.get("response"),
                    "usage": item.get("usage"),
                    "compilation_status": compilation.get("status"),
                    "compilation_reason": (
                        compilation.get("reason")
                        or compilation.get("error")
                    ),
                    "duplicate_of": compilation.get("duplicate_of"),
                    "duplicate_scope": compilation.get("duplicate_scope"),
                    "semantic_similarity": compilation.get(
                        "semantic_similarity"
                    ),
                    "executed": proposal_id
                    in set(proposal_payload.get("proposal_ids", [])),
                }
            )

        built_state_by_proposal: dict[str, str] = {}
        for event in indexed.get("candidate_built", []):
            payload = dict(event["payload"])
            built_state_by_proposal[str(payload["proposal_id"])] = str(
                payload["candidate_state_id"]
            )

        evaluations: dict[tuple[str, str], dict[str, Any]] = {}
        for event in indexed.get("evaluation_finished", []):
            payload = dict(event["payload"])
            summary_ref = dict(payload["summary"])
            summary = dict(artifact(run, summary_ref))
            summary["_ref"] = summary_ref
            evaluations[
                (str(summary["state_id"]), str(summary["split"]))
            ] = summary

        transition_by_proposal: dict[str, dict[str, Any]] = {}
        transition_ref_by_proposal: dict[str, dict[str, Any]] = {}
        training_example_by_proposal: dict[str, dict[str, Any]] = {}
        exact_user_prompt: str | None = None
        for event in indexed.get("optimizer_transition", []):
            payload = dict(event["payload"])
            proposal_id = str(payload["proposal_id"])
            transition_ref = dict(payload["transition"])
            transition = dict(artifact(run, transition_ref))
            transition_by_proposal[proposal_id] = transition
            transition_ref_by_proposal[proposal_id] = transition_ref
            example = (
                dict(transition.get("action") or {})
                .get("policy_training_example")
            )
            if isinstance(example, dict):
                training_example_by_proposal[proposal_id] = example
                if proposer_system is None:
                    proposer_system = str(example.get("system") or "")
                if exact_user_prompt is None:
                    exact_user_prompt = str(example.get("user") or "")

        base_user_prompt: str | None = None
        if exact_user_prompt:
            base_user_prompt = exact_user_prompt.split(
                "\n\nBATCH_DIVERSITY:\n", 1
            )[0]
        prior_valid_actions: list[dict[str, Any]] = []
        prompt_reconstruction_checks: list[bool] = []
        for item in policy_samples:
            sample_index = int(item.get("sample_index") or 0)
            diversity_directive = {
                "batch_sample": sample_index + 1,
                "batch_size": len(policy_samples),
                "prior_valid_actions": prior_valid_actions,
                "requirement": (
                    "Propose a causally distinct intervention. Do not merely "
                    "paraphrase a prior trigger, threshold, target field, or "
                    "algorithm example. Prefer a different mutable axis or "
                    "field; if the same target is necessary, use a genuinely "
                    "different mechanism and falsifiable hypothesis."
                ),
            }
            reconstructed_user_prompt: str | None = None
            if base_user_prompt is not None:
                reconstructed_user_prompt = (
                    base_user_prompt
                    + "\n\nBATCH_DIVERSITY:\n"
                    + json.dumps(
                        diversity_directive,
                        ensure_ascii=False,
                        default=str,
                    )
                )
            exact_example = training_example_by_proposal.get(
                str(item.get("proposal_id"))
            )
            exact_example_user = (
                str(exact_example.get("user") or "")
                if exact_example is not None
                else None
            )
            reconstruction_verified = (
                reconstructed_user_prompt == exact_example_user
                if exact_example_user is not None
                else None
            )
            if reconstruction_verified is not None:
                prompt_reconstruction_checks.append(
                    reconstruction_verified
                )
            item.update(
                {
                    "generation_seed": (
                        proposer_seed + round_index * 1000 + sample_index
                    ),
                    "diversity_directive": diversity_directive,
                    "user_prompt_sha256": (
                        digest_text(reconstructed_user_prompt)
                        if reconstructed_user_prompt is not None
                        else None
                    ),
                    "user_prompt_chars": (
                        len(reconstructed_user_prompt)
                        if reconstructed_user_prompt is not None
                        else None
                    ),
                    "executed_prompt_reconstruction_verified": (
                        reconstruction_verified
                    ),
                    "served_model": (
                        exact_example.get("served_model")
                        if exact_example is not None
                        else proposal_payload.get(
                            "batch_metadata", {}
                        ).get("policy_served_model")
                    ),
                }
            )
            action = item.get("action")
            if item.get("policy_status") == "valid" and isinstance(
                action, dict
            ):
                prior_valid_actions.append(
                    {
                        "proposal_id": action.get("proposal_id"),
                        "axis": action.get("axis"),
                        "hypothesis": action.get("hypothesis"),
                        "edit_targets": [
                            {
                                "kind": atom.get("kind"),
                                "field": atom.get("field"),
                            }
                            for atom in action.get("edit_atoms", [])
                            if isinstance(atom, dict)
                        ],
                    }
                )

        executed_candidates = []
        decisions = {
            str(event["payload"]["proposal_id"]): dict(event["payload"])
            for event in indexed.get("candidate_decided", [])
        }
        for proposal_id in proposal_payload.get("proposal_ids", []):
            proposal_id = str(proposal_id)
            state_id = built_state_by_proposal.get(proposal_id)
            harness_ref, candidate_harness = state_component(
                run, str(state_id or ""), "harness"
            )
            transition = transition_by_proposal.get(proposal_id, {})
            assessment = dict(transition.get("assessment") or {})
            reward = dict(transition.get("reward") or {})
            executed_candidates.append(
                {
                    "proposal_id": proposal_id,
                    "state_id": state_id,
                    "candidate_harness_ref": harness_ref,
                    "candidate_harness": candidate_harness,
                    "semantic_action": dict(
                        transition.get("action") or {}
                    ).get("semantic_action"),
                    "transition_ref": transition_ref_by_proposal.get(
                        proposal_id
                    ),
                    "outcome": evaluation_record(
                        run,
                        evaluations.get((str(state_id), "outcome")),
                    ),
                    "promotion": evaluation_record(
                        run,
                        evaluations.get((str(state_id), "promotion")),
                    ),
                    "reward": {
                        "total": reward.get("total"),
                        "components": reward.get("components", {}),
                        "metadata": reward.get("metadata", {}),
                    },
                    "assessment": assessment,
                    "public_decision": decisions.get(proposal_id),
                }
            )

        prompt_payload: dict[str, Any] = {}
        if base_user_prompt:
            try:
                prompt_payload = dict(json.loads(base_user_prompt))
            except (json.JSONDecodeError, TypeError, ValueError):
                prompt_payload = {}
        rendered_optimizer_memory = dict(
            prompt_payload.get("optimizer_memory") or {}
        )
        optimizer_memory_is_clipped = bool(
            rendered_optimizer_memory.get("truncated")
            and "preview" in rendered_optimizer_memory
        )
        recent_attempts = list(
            rendered_optimizer_memory.get("recent_attempts") or []
        )

        selection = (
            dict(indexed["selection_decided"][0]["payload"])
            if indexed.get("selection_decided")
            else None
        )
        finished = (
            dict(indexed["round_finished"][0]["payload"])
            if indexed.get("round_finished")
            else None
        )
        update_event = (
            dict(indexed["optimizer_updated"][0]["payload"])
            if indexed.get("optimizer_updated")
            else None
        )
        controller: dict[str, Any] = {}
        if update_event:
            controller = controller_from_state(
                run, str(update_event["optimizer_state_id"])
            )
        training_history = list(controller.get("training_history") or [])

        rounds.append(
            {
                "round": round_index,
                "context_ref": context_ref,
                "context_state_id": dict(context.get("state") or {}).get(
                    "state_id"
                ),
                "harness_fields": harness,
                "prompt_sections": prompt_sections(system_prompt),
                "system_prompt": system_prompt,
                "update_summary": context.get("train_summary"),
                "evidence": [
                    compact_evidence(dict(item))
                    for item in context.get("evidence", [])
                    if isinstance(item, dict)
                ],
                "outer_history": context.get("history", []),
                "base_user_prompt": base_user_prompt,
                "base_user_prompt_sha256": (
                    digest_text(base_user_prompt)
                    if base_user_prompt
                    else None
                ),
                "base_user_prompt_chars": (
                    len(base_user_prompt) if base_user_prompt else None
                ),
                "prompt_user_sha256": (
                    digest_text(exact_user_prompt)
                    if exact_user_prompt
                    else None
                ),
                "prompt_user_chars": (
                    len(exact_user_prompt)
                    if exact_user_prompt
                    else None
                ),
                "executed_prompt_reconstructions_verified": (
                    all(prompt_reconstruction_checks)
                    if prompt_reconstruction_checks
                    else None
                ),
                "optimizer_memory": {
                    "prompt_representation_clipped": (
                        optimizer_memory_is_clipped
                    ),
                    "prompt_source_chars": (
                        rendered_optimizer_memory.get("chars")
                        if optimizer_memory_is_clipped
                        else None
                    ),
                    "prompt_preview": (
                        rendered_optimizer_memory.get("preview")
                        if optimizer_memory_is_clipped
                        else None
                    ),
                    "recent_attempt_count": (
                        None
                        if optimizer_memory_is_clipped
                        else len(recent_attempts)
                    ),
                    "recent_attempts": (
                        None
                        if optimizer_memory_is_clipped
                        else recent_attempts
                    ),
                    "successful_actions": (
                        None
                        if optimizer_memory_is_clipped
                        else rendered_optimizer_memory.get(
                            "successful_actions", []
                        )
                    ),
                    "operator_statistics": (
                        None
                        if optimizer_memory_is_clipped
                        else rendered_optimizer_memory.get(
                            "operator_statistics", {}
                        )
                    ),
                    "invalid_signatures": (
                        None
                        if optimizer_memory_is_clipped
                        else rendered_optimizer_memory.get(
                            "invalid_signatures", []
                        )
                    ),
                    "archive_attempt_count": len(
                        optimizer_archive.get("attempts") or []
                    ),
                    "archive_successful_action_count": len(
                        optimizer_archive.get("successful_actions") or []
                    ),
                    "archive_invalid_signature_count": len(
                        optimizer_archive.get("invalid_signatures") or []
                    ),
                },
                "optimizer_archive_ref": optimizer_archive_ref,
                "optimizer_archive": optimizer_archive,
                "batch_ref": batch_ref,
                "batch_metadata": batch_metadata,
                "outer_usage": proposal_payload.get("outer_usage"),
                "policy_samples": policy_samples,
                "executed_candidates": executed_candidates,
                "selection": selection,
                "round_finished": finished,
                "controller": {
                    "confirmed_record": controller.get("confirmed_record"),
                    "rounds_since_confirmed_record": controller.get(
                        "rounds_since_confirmed_record"
                    ),
                    "policy_updates": controller.get("policy_updates"),
                    "active_adapter_name": controller.get(
                        "active_adapter_name"
                    ),
                    "last_training_decision": controller.get(
                        "last_training_decision"
                    ),
                    "training_history_last": (
                        training_history[-1] if training_history else None
                    ),
                },
            }
        )

    summary = read_json(run / "summary.json")
    initial_state_id = str(summary.get("initial_state_id") or "")
    initial_evaluations: dict[str, Any] = {}
    final_evaluation_details = None
    for event in events:
        if event.get("event") != "evaluation_finished":
            continue
        payload = dict(event.get("payload") or {})
        if (
            str(payload.get("state_id") or "") == initial_state_id
            and payload.get("split") in {"update", "outcome", "promotion"}
        ):
            initial_ref = dict(payload["summary"])
            initial_summary = dict(artifact(run, initial_ref))
            initial_summary["_ref"] = initial_ref
            split_name = str(payload["split"])
            initial_evaluations.setdefault(
                split_name,
                evaluation_record(run, initial_summary),
            )
        if payload.get("split") != "final":
            continue
        summary_ref = dict(payload["summary"])
        final_summary = dict(artifact(run, summary_ref))
        final_summary["_ref"] = summary_ref
        final_evaluation_details = evaluation_record(run, final_summary)
        break
    adapter_updates = []
    for path in sorted(
        (run / "outer-policy" / "adapters").glob(
            "update-*/sah_training.json"
        )
    ):
        metadata = dict(read_json(path))
        adapter_updates.append(
            {
                "update": path.parent.name,
                "metadata": metadata,
                "relative_path": str(path.relative_to(task_root)),
            }
        )

    return {
        "schema": "adaptive.case-study-extract/v1",
        "task": task,
        "task_root": str(task_root),
        "resolved_config_relative_path": str(
            resolved_config_path.relative_to(task_root)
        ),
        "resolved_config": resolved_config,
        "experiment_id": summary.get("experiment_id"),
        "ledger": ledger_status,
        "event_count": len(events),
        "event_counts": dict(sorted(event_counts.items())),
        "episode_audit": {
            "count": len(episode_records),
            "split_counts": dict(sorted(episode_split_counts.items())),
            "records_with_error": sum(
                record.get("error") is not None
                for record in episode_records
            ),
            "records_with_integrity_flags": sum(
                bool(record.get("integrity_flags"))
                for record in episode_records
            ),
            "records_with_nonfinite_or_missing_reward": sum(
                not isinstance(record.get("reward"), (int, float))
                or not math.isfinite(float(record["reward"]))
                for record in episode_records
            ),
            "records_not_fully_valid": sum(
                float(dict(record.get("metrics") or {}).get("validity", 0.0))
                < 1.0
                for record in episode_records
            ),
        },
        "round_count": len(rounds),
        "proposer_system": proposer_system,
        "rounds": rounds,
        "adapter_updates": adapter_updates,
        "initial_evaluations": initial_evaluations,
        "final_evaluations": summary.get("final_evaluations"),
        "final_evaluation_details": final_evaluation_details,
        "final_state_id": summary.get("final_state_id"),
        "final_working_state_id": summary.get("final_working_state_id"),
        "final_optimizer_state_id": summary.get(
            "final_optimizer_state_id"
        ),
        "campaign_summary": campaign,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_root", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = extract(args.task_root)
    rendered = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
