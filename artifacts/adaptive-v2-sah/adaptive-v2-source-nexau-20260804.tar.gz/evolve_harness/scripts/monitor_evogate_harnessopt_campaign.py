#!/usr/bin/env python3
"""Continuously audit a running HarnessOpt campaign for meaningful results.

This monitor is read-only with respect to the campaign and external vLLM. It
writes supervision snapshots and exits when the campaign reaches a terminal
state or its launcher disappears.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import signal
import time
from datetime import datetime
from pathlib import Path
from typing import Any


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    rows: list[dict[str, Any]] = []
    for line in lines:
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def append_event(path: Path, event: str, **fields: Any) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(
            json.dumps(
                {"time": now(), "event": event, **fields},
                ensure_ascii=False,
            )
            + "\n"
        )
        handle.flush()
        os.fsync(handle.fileno())


def process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, PermissionError):
        return False
    return True


def process_command(pid: int) -> str:
    try:
        return (
            Path(f"/proc/{pid}/cmdline")
            .read_bytes()
            .replace(b"\0", b" ")
            .decode("utf-8", "replace")
            .strip()
        )
    except OSError:
        return ""


def artifact_path(task_run: Path, digest: str) -> Path | None:
    algorithm, separator, value = str(digest).partition(":")
    if algorithm != "sha256" or not separator or len(value) != 64:
        return None
    return task_run / "artifacts" / "objects" / value[:2] / value[2:]


def duplicate_proposal_mutations(
    task_run: Path, events: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    duplicates: list[dict[str, Any]] = []
    for event in events:
        if event.get("event") != "proposals_received":
            continue
        payload = dict(event.get("payload") or {})
        seen: dict[str, str] = {}
        for ref in payload.get("proposals", []):
            if not isinstance(ref, dict):
                continue
            path = artifact_path(task_run, str(ref.get("digest") or ""))
            proposal = read_json(path) if path is not None else None
            if proposal is None:
                continue
            mutation_key = json.dumps(
                proposal.get("mutations", []),
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            )
            proposal_id = str(proposal.get("proposal_id") or "")
            duplicate_of = seen.get(mutation_key)
            if duplicate_of is not None:
                duplicates.append(
                    {
                        "round": payload.get("round"),
                        "proposal_id": proposal_id,
                        "duplicate_of": duplicate_of,
                    }
                )
            else:
                seen[mutation_key] = proposal_id
    return duplicates


def duplicate_candidate_states(
    events: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    seen: dict[tuple[Any, str, str], str] = {}
    duplicates: list[dict[str, Any]] = []
    for event in events:
        if event.get("event") != "candidate_built":
            continue
        payload = dict(event.get("payload") or {})
        key = (
            payload.get("round"),
            str(payload.get("baseline_state_id") or ""),
            str(payload.get("candidate_state_id") or ""),
        )
        proposal_id = str(payload.get("proposal_id") or "")
        duplicate_of = seen.get(key)
        if duplicate_of is not None:
            duplicates.append(
                {
                    "round": payload.get("round"),
                    "proposal_id": proposal_id,
                    "duplicate_of": duplicate_of,
                    "candidate_state_id": key[2],
                }
            )
        else:
            seen[key] = proposal_id
    return duplicates


def task_health(task_run: Path, inner_root: Path) -> dict[str, Any]:
    events_path = task_run / "events.jsonl"
    events = read_jsonl(events_path)
    event_counts: dict[str, int] = {}
    for event in events:
        name = str(event.get("event") or "")
        event_counts[name] = event_counts.get(name, 0) + 1

    episodes: list[dict[str, Any]] = []
    missing_records: list[str] = []
    for event in events:
        if event.get("event") != "episode_finished":
            continue
        record = dict(event.get("payload") or {}).get("record")
        digest = record.get("digest") if isinstance(record, dict) else None
        path = artifact_path(task_run, str(digest or ""))
        value = read_json(path) if path is not None else None
        if value is None:
            missing_records.append(str(digest))
            continue
        episodes.append(value)

    evaluation_summaries: list[dict[str, Any]] = []
    for event in events:
        if event.get("event") != "evaluation_finished":
            continue
        summary = dict(event.get("payload") or {}).get("summary")
        digest = summary.get("digest") if isinstance(summary, dict) else None
        path = artifact_path(task_run, str(digest or ""))
        value = read_json(path) if path is not None else None
        if value is not None:
            evaluation_summaries.append(value)
    score_sems = [
        float(row["score_sem"])
        for row in evaluation_summaries
        if isinstance(row.get("score_sem"), (int, float))
    ]
    rollout_score_sems = [
        float(row["rollout_score_sem"])
        for row in evaluation_summaries
        if isinstance(row.get("rollout_score_sem"), (int, float))
    ]
    measurement_score_sems = [
        float(row["measurement_score_sem"])
        for row in evaluation_summaries
        if isinstance(row.get("measurement_score_sem"), (int, float))
    ]
    rollout_repeat_counts = [
        int(row["rollout_repeats"])
        for row in evaluation_summaries
        if isinstance(row.get("rollout_repeats"), int)
    ]
    selections = [
        dict(event.get("payload") or {})
        for event in events
        if event.get("event") == "selection_decided"
    ]
    paired_delta_sems = [
        float(value)
        for selection in selections
        for value in dict(
            dict(selection.get("metadata") or {}).get(
                "paired_delta_sem", {}
            )
        ).values()
        if isinstance(value, (int, float))
    ]
    uncertainty_missing_selections = sum(
        1
        for selection in selections
        if any(
            value is None
            for value in dict(
                dict(selection.get("metadata") or {}).get(
                    "required_improvements", {}
                )
            ).values()
        )
    )
    semantic_duplicate_batches = []
    for event in events:
        if event.get("event") != "proposals_received":
            continue
        payload = dict(event.get("payload") or {})
        metadata = dict(payload.get("batch_metadata") or {})
        duplicate_count = int(
            metadata.get("semantic_duplicate_mutations", 0) or 0
        )
        if duplicate_count:
            semantic_duplicate_batches.append(
                {
                    "round": payload.get("round"),
                    "requested": metadata.get("requested"),
                    "compiled": metadata.get("compiled"),
                    "semantic_duplicate_mutations": duplicate_count,
                }
            )
    resource_regressive_candidates = []
    for selection in selections:
        metadata = dict(selection.get("metadata") or {})
        cost_gate = dict(metadata.get("working_cost_gate") or {})
        candidates = dict(cost_gate.get("candidates") or {})
        for proposal_id, row in candidates.items():
            if (
                isinstance(row, dict)
                and row.get("eligible") is False
            ):
                resource_regressive_candidates.append(
                    {
                        "round": selection.get("round"),
                        "proposal_id": proposal_id,
                        "ratios": dict(row.get("ratios") or {}),
                        "outcome_improvement": row.get(
                            "outcome_improvement"
                        ),
                    }
                )
    errors = [
        {
            "task_id": row.get("task_id"),
            "split": row.get("split"),
            "error": row.get("error"),
        }
        for row in episodes
        if row.get("error")
    ]
    integrity_failures = [
        {
            "task_id": row.get("task_id"),
            "split": row.get("split"),
            "integrity": row.get("integrity"),
        }
        for row in episodes
        if dict(row.get("integrity") or {}).get("status") != "pass"
    ]
    valid_episodes = [
        row
        for row in episodes
        if float(dict(row.get("metrics") or {}).get("valid", 0.0)) > 0.0
        and not row.get("error")
    ]
    scores = [float(row.get("reward", 0.0)) for row in valid_episodes]
    traces = [len(row.get("trace") or []) for row in valid_episodes]
    token_total = sum(
        int(dict(row.get("usage") or {}).get("tokens", 0))
        for row in episodes
    )
    fingerprinted_episodes = sum(
        1 for row in episodes if row.get("behavior_fingerprint")
    )
    reused_evaluations = sum(
        1
        for row in episodes
        if dict(row.get("evaluation_reuse") or {}).get("reused")
    )
    candidate_decisions = [
        dict(event.get("payload") or {})
        for event in events
        if event.get("event") == "candidate_decided"
    ]
    behavior_equivalent_candidates = sum(
        1
        for row in candidate_decisions
        if "behavior_equivalent" in str(row.get("reason") or "")
    )
    zero_reward_transitions = sum(
        1
        for event in events
        if event.get("event") == "optimizer_transition"
        and float(dict(event.get("payload") or {}).get("reward", 0.0)) == 0.0
    )
    worker_errors = sorted(
        str(path)
        for path in inner_root.rglob("worker_error.json")
        if path.is_file()
    )
    last_event_age = None
    if events_path.is_file():
        last_event_age = max(0.0, time.time() - events_path.stat().st_mtime)
    latest = events[-1] if events else {}
    duplicate_mutations = duplicate_proposal_mutations(task_run, events)
    duplicate_states = duplicate_candidate_states(events)
    training_updates: list[dict[str, Any]] = []
    for metadata_path in sorted(
        task_run.glob(
            "outer-policy/adapters/update-*/sah_training.json"
        )
    ):
        metadata = read_json(metadata_path)
        if metadata is None:
            continue
        history = [
            dict(row)
            for row in metadata.get("training_history", [])
            if isinstance(row, dict)
        ]
        finite = all(
            isinstance(row.get(field), (int, float))
            and math.isfinite(float(row[field]))
            for row in history
            for field in ("nll", "objective", "grad_norm")
        )
        adapter_dir = metadata_path.parent
        training_updates.append(
            {
                "update": adapter_dir.name,
                "steps": int(metadata.get("steps", 0) or 0),
                "examples": int(
                    metadata.get("examples", 0) or 0
                ),
                "max_len": int(
                    metadata.get("max_len", 0) or 0
                ),
                "finite": finite,
                "nll_first": (
                    history[0].get("nll") if history else None
                ),
                "nll_last": (
                    history[-1].get("nll") if history else None
                ),
                "objective_last": (
                    history[-1].get("objective")
                    if history
                    else None
                ),
                "grad_norm_last": (
                    history[-1].get("grad_norm")
                    if history
                    else None
                ),
                "adapter_complete": (
                    (adapter_dir / "adapter_config.json").is_file()
                    and any(adapter_dir.glob("adapter_model.*"))
                ),
            }
        )
    return {
        "exists": task_run.is_dir(),
        "latest_event": latest.get("event"),
        "latest_seq": latest.get("seq"),
        "last_event_age_seconds": last_event_age,
        "event_counts": event_counts,
        "episodes": len(episodes),
        "valid_episodes": len(valid_episodes),
        "episode_errors": errors,
        "integrity_failures": integrity_failures,
        "missing_records": missing_records,
        "worker_error_files": worker_errors,
        "duplicate_proposal_mutations": duplicate_mutations,
        "duplicate_candidate_states": duplicate_states,
        "semantic_duplicate_batches": semantic_duplicate_batches,
        "resource_regressive_candidates": (
            resource_regressive_candidates
        ),
        "score_min": min(scores) if scores else None,
        "score_max": max(scores) if scores else None,
        "score_latest": scores[-1] if scores else None,
        "trace_events_min": min(traces) if traces else None,
        "tokens": token_total,
        "evaluation_batches": len(evaluation_summaries),
        "score_sem_latest": score_sems[-1] if score_sems else None,
        "rollout_score_sem_latest": (
            rollout_score_sems[-1] if rollout_score_sems else None
        ),
        "measurement_score_sem_latest": (
            measurement_score_sems[-1]
            if measurement_score_sems
            else None
        ),
        "rollout_repeats_min": (
            min(rollout_repeat_counts)
            if rollout_repeat_counts
            else None
        ),
        "paired_delta_sem_latest": (
            paired_delta_sems[-1] if paired_delta_sems else None
        ),
        "uncertainty_missing_selections": (
            uncertainty_missing_selections
        ),
        "fingerprinted_episodes": fingerprinted_episodes,
        "reused_evaluations": reused_evaluations,
        "behavior_equivalent_candidates": (
            behavior_equivalent_candidates
        ),
        "zero_reward_transitions": zero_reward_transitions,
        "rounds_finished": event_counts.get("round_finished", 0),
        "proposals_received": event_counts.get("proposals_received", 0),
        "candidates_decided": event_counts.get("candidate_decided", 0),
        "run_failed": event_counts.get("run_failed", 0),
        "run_finished": event_counts.get("run_finished", 0),
        "summary_present": (task_run / "summary.json").is_file(),
        "training_updates": training_updates,
        "training_nonfinite": any(
            not row["finite"] for row in training_updates
        ),
        "training_incomplete": any(
            row["steps"] < 1 or not row["adapter_complete"]
            for row in training_updates
        ),
    }


def campaign_snapshot(
    *,
    run_root: Path,
    launcher_pid: int,
    vllm_pid: int,
    stale_seconds: float,
) -> dict[str, Any]:
    lifecycle = read_jsonl(run_root / "campaign_lifecycle.jsonl")
    summary = read_json(run_root / "campaign_summary.json")
    tasks = []
    for event in lifecycle:
        if event.get("event") == "campaign_prepare":
            tasks = [str(item) for item in event.get("tasks", [])]
            break
    task_rows: dict[str, Any] = {}
    critical: list[str] = []
    warnings: list[str] = []
    for task in tasks:
        safe = task.replace("-", "_")
        row = task_health(
            run_root / "runs" / safe,
            run_root / "inner-runs" / safe,
        )
        task_rows[task] = row
        if row["episode_errors"]:
            critical.append(f"{task}:episode_errors")
        if row["integrity_failures"]:
            critical.append(f"{task}:integrity_failures")
        if row["worker_error_files"]:
            critical.append(f"{task}:worker_errors")
        if row["missing_records"]:
            critical.append(f"{task}:missing_episode_records")
        if row["run_failed"]:
            critical.append(f"{task}:run_failed")
        if row["training_nonfinite"]:
            critical.append(f"{task}:training_nonfinite")
        if row["training_incomplete"]:
            critical.append(f"{task}:training_incomplete")
        if row["uncertainty_missing_selections"]:
            critical.append(f"{task}:selection_uncertainty_missing")
        if row["duplicate_proposal_mutations"]:
            critical.append(f"{task}:duplicate_proposal_mutations")
        if row["duplicate_candidate_states"]:
            critical.append(f"{task}:duplicate_candidate_states")
        if row["semantic_duplicate_batches"]:
            warnings.append(f"{task}:semantic_duplicates_filtered")
        if row["resource_regressive_candidates"]:
            warnings.append(f"{task}:resource_regressions_filtered")
        age = row["last_event_age_seconds"]
        if (
            row["exists"]
            and not row["summary_present"]
            and age is not None
            and age > stale_seconds
        ):
            warnings.append(f"{task}:ledger_stale")
    launcher_alive = process_alive(launcher_pid)
    vllm_alive = process_alive(vllm_pid)
    terminal_status = str((summary or {}).get("status") or "")
    if not launcher_alive and not terminal_status:
        critical.append("launcher_disappeared_without_summary")
    if not vllm_alive:
        critical.append("authorized_vllm_missing")
    status = "critical" if critical else ("warning" if warnings else "healthy")
    return {
        "schema": "evogate.harnessopt-supervision/v1",
        "time": now(),
        "status": status,
        "critical": sorted(set(critical)),
        "warnings": sorted(set(warnings)),
        "launcher": {
            "pid": launcher_pid,
            "alive": launcher_alive,
            "command": process_command(launcher_pid),
        },
        "external_vllm": {
            "pid": vllm_pid,
            "alive": vllm_alive,
            "command": process_command(vllm_pid),
            "lifecycle_owned": False,
        },
        "campaign_status": terminal_status or "running",
        "tasks": task_rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--launcher-pid", type=int, required=True)
    parser.add_argument("--vllm-pid", type=int, required=True)
    parser.add_argument("--poll-seconds", type=float, default=30.0)
    parser.add_argument("--heartbeat-seconds", type=float, default=300.0)
    parser.add_argument("--stale-seconds", type=float, default=1800.0)
    parser.add_argument(
        "--once",
        action="store_true",
        help="Write one health snapshot and exit; useful for preflight tests.",
    )
    args = parser.parse_args()
    if args.poll_seconds < 5 or args.heartbeat_seconds < args.poll_seconds:
        parser.error("invalid polling or heartbeat interval")

    run_root = args.run_root.resolve()
    if not run_root.is_dir():
        parser.error(f"run root does not exist: {run_root}")
    log = run_root / "supervision.jsonl"
    health_path = run_root / "health.json"
    (run_root / "supervision.pid").write_text(
        f"{os.getpid()}\n", encoding="utf-8"
    )
    stopping = False

    def request_stop(signum: int, _frame: Any) -> None:
        nonlocal stopping
        stopping = True
        append_event(log, "supervisor_stop_requested", signal=signum)

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    append_event(
        log,
        "supervisor_start",
        supervisor_pid=os.getpid(),
        launcher_pid=args.launcher_pid,
        external_vllm_pid=args.vllm_pid,
        external_vllm_owned=False,
    )
    last_signature = ""
    last_written = 0.0
    exit_code = 0
    exit_reason = "campaign_completed"
    while not stopping:
        snapshot = campaign_snapshot(
            run_root=run_root,
            launcher_pid=args.launcher_pid,
            vllm_pid=args.vllm_pid,
            stale_seconds=args.stale_seconds,
        )
        health_path.write_text(
            json.dumps(snapshot, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        signature = json.dumps(
            {
                "status": snapshot["status"],
                "critical": snapshot["critical"],
                "warnings": snapshot["warnings"],
                "campaign_status": snapshot["campaign_status"],
                "tasks": {
                    name: {
                        "latest_seq": row["latest_seq"],
                        "episodes": row["episodes"],
                        "reused_evaluations": row[
                            "reused_evaluations"
                        ],
                        "behavior_equivalent_candidates": row[
                            "behavior_equivalent_candidates"
                        ],
                        "rounds_finished": row["rounds_finished"],
                        "run_failed": row["run_failed"],
                    }
                    for name, row in snapshot["tasks"].items()
                },
            },
            sort_keys=True,
        )
        current = time.time()
        if signature != last_signature or current - last_written >= args.heartbeat_seconds:
            append_event(log, "health_snapshot", snapshot=snapshot)
            last_signature = signature
            last_written = current
        terminal = snapshot["campaign_status"]
        if terminal in {"completed", "failed", "interrupted"}:
            exit_code = 0 if terminal == "completed" else 1
            exit_reason = f"campaign_{terminal}"
            break
        if not snapshot["launcher"]["alive"]:
            exit_code = 2
            exit_reason = "launcher_disappeared"
            break
        if args.once:
            exit_code = 1 if snapshot["status"] == "critical" else 0
            exit_reason = "single_snapshot"
            break
        time.sleep(args.poll_seconds)
    if stopping:
        exit_code = 130
        exit_reason = "supervisor_stopped"
    append_event(
        log,
        "supervisor_exit",
        exit_code=exit_code,
        exit_reason=exit_reason,
        external_vllm_shutdown="not_requested_external_service",
        gpu_cleanup_status="monitor launched no GPU process",
    )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
