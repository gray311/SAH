#!/usr/bin/env python3
"""Build a self-contained Adaptive v1 case-study audit zip."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Iterable


PACKAGE_ROOT = "adaptive_v1_cp26_case_study"
CAS_OBJECT_LIMIT = 5 * 1024 * 1024
CAMPAIGN_FILES = (
    "campaign_summary.json",
    "campaign_lifecycle.jsonl",
    "managed_lifecycle.jsonl",
    "cleanup_watchdog.log",
    "health.json",
    "supervision.jsonl",
)
RUN_FILES = ("events.jsonl", "manifest.json", "summary.json")
RUN_ARTIFACT_DIRS = (
    "checkpoint-refs",
    "checkpoints",
    "optimizer-refs",
    "optimizer-states",
    "refs",
    "states",
)
ADAPTER_METADATA_FILES = (
    "README.md",
    "adapter_config.json",
    "chat_template.jinja",
    "sah_training.json",
    "tokenizer_config.json",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_existing_files(
    source_root: Path,
    destination_root: Path,
    relative_paths: Iterable[str],
) -> list[str]:
    copied: list[str] = []
    for relative in relative_paths:
        source = source_root / relative
        if not source.is_file():
            continue
        destination = destination_root / relative
        copy_file(source, destination)
        copied.append(relative)
    return copied


def digest_from_object_path(path: Path) -> str:
    return "sha256:" + path.parent.name + path.name


def build_package(args: argparse.Namespace) -> dict[str, Any]:
    task_root = args.task_root.resolve()
    task = "circle_packing_26"
    run_root = task_root / "runs" / task
    if not (run_root / "events.jsonl").is_file():
        raise FileNotFoundError(f"missing run ledger: {run_root}")

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    checksum_path = output.with_suffix(output.suffix + ".sha256")
    if checksum_path.exists():
        checksum_path.unlink()

    with tempfile.TemporaryDirectory(
        prefix="adaptive-v1-cp26-case-study-"
    ) as temporary:
        staging = Path(temporary) / PACKAGE_ROOT
        staging.mkdir(parents=True)

        copy_file(args.readme.resolve(), staging / "README_CN.md")
        copy_file(args.case_study.resolve(), staging / "CASE_STUDY.md")
        copy_file(
            args.case_data.resolve(),
            staging
            / "case_data"
            / "adaptive_v1_circle_packing_26_case_data.json",
        )
        copy_file(
            args.extractor.resolve(),
            staging / "scripts" / "extract_adaptive_case_study.py",
        )

        campaign_destination = staging / "artifacts" / "campaign"
        copied_campaign_files = copy_existing_files(
            task_root, campaign_destination, CAMPAIGN_FILES
        )
        copied_campaign_files.extend(
            copy_existing_files(
                task_root,
                campaign_destination,
                (
                    f"resolved-configs/{task}.json",
                    f"logs/{task}.run.log",
                    f"logs/{task}.validate.log",
                ),
            )
        )

        run_destination = staging / "artifacts" / "run"
        copied_run_files = copy_existing_files(
            run_root, run_destination, RUN_FILES
        )
        for directory in RUN_ARTIFACT_DIRS:
            source = run_root / "artifacts" / directory
            if source.is_dir():
                shutil.copytree(
                    source,
                    run_destination / "artifacts" / directory,
                )

        objects_source = run_root / "artifacts" / "objects"
        objects_destination = run_destination / "artifacts" / "objects"
        included_objects: list[dict[str, Any]] = []
        excluded_objects: list[dict[str, Any]] = []
        for source in sorted(objects_source.glob("*/*")):
            if not source.is_file():
                continue
            size = source.stat().st_size
            row = {
                "digest": digest_from_object_path(source),
                "size": size,
                "source_relative_path": str(
                    source.relative_to(run_root)
                ),
            }
            if size > args.max_object_bytes:
                row["reason"] = (
                    "large model/optimizer/tokenizer blob excluded from "
                    "review bundle"
                )
                excluded_objects.append(row)
                continue
            destination = (
                objects_destination
                / source.parent.name
                / source.name
            )
            copy_file(source, destination)
            included_objects.append(row)

        batches_source = run_root / "outer-policy" / "batches"
        if batches_source.is_dir():
            shutil.copytree(
                batches_source,
                run_destination / "outer-policy" / "batches",
            )
        adapters_source = run_root / "outer-policy" / "adapters"
        copied_adapter_metadata: list[str] = []
        for update in sorted(adapters_source.glob("update-*")):
            if not update.is_dir():
                continue
            destination = (
                run_destination / "outer-policy" / "adapters" / update.name
            )
            copied = copy_existing_files(
                update, destination, ADAPTER_METADATA_FILES
            )
            copied_adapter_metadata.extend(
                f"{update.name}/{relative}" for relative in copied
            )

        inner_runs_source = task_root / "inner-runs"
        if inner_runs_source.is_dir():
            shutil.copytree(
                inner_runs_source,
                staging / "artifacts" / "inner-runs",
            )

        index = {
            "schema": "adaptive.case-study-audit-bundle/v1",
            "package_root": PACKAGE_ROOT,
            "task": task,
            "purpose": (
                "self-contained text/JSON trajectory review; not a model "
                "checkpoint bundle"
            ),
            "source_task_root": str(task_root),
            "contents": {
                "campaign_files": copied_campaign_files,
                "run_files": copied_run_files,
                "adapter_metadata_files": copied_adapter_metadata,
                "cas_objects_included": len(included_objects),
                "cas_bytes_included": sum(
                    row["size"] for row in included_objects
                ),
                "cas_objects_excluded": len(excluded_objects),
                "cas_bytes_excluded": sum(
                    row["size"] for row in excluded_objects
                ),
            },
            "excluded_cas_objects": excluded_objects,
            "cas_path_rule": (
                "sha256:abcdef... maps to "
                "artifacts/run/artifacts/objects/ab/cdef..."
            ),
        }
        (staging / "ARTIFACT_INDEX.json").write_text(
            json.dumps(index, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

        checksum_rows = []
        for path in sorted(staging.rglob("*")):
            if not path.is_file() or path.name == "SHA256SUMS":
                continue
            checksum_rows.append(
                f"{sha256_file(path)}  {path.relative_to(staging)}"
            )
        (staging / "SHA256SUMS").write_text(
            "\n".join(checksum_rows) + "\n",
            encoding="utf-8",
        )

        with zipfile.ZipFile(
            output,
            mode="w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as archive:
            for path in sorted(staging.rglob("*")):
                if path.is_file():
                    archive.write(
                        path,
                        arcname=str(
                            Path(PACKAGE_ROOT)
                            / path.relative_to(staging)
                        ),
                    )

    with zipfile.ZipFile(output) as archive:
        corrupt = archive.testzip()
        if corrupt is not None:
            raise RuntimeError(f"corrupt zip member: {corrupt}")
        member_count = len(archive.infolist())

    output_sha256 = sha256_file(output)
    checksum_path.write_text(
        f"{output_sha256}  {output.name}\n",
        encoding="utf-8",
    )
    return {
        **index,
        "zip_path": str(output),
        "zip_bytes": output.stat().st_size,
        "zip_sha256": output_sha256,
        "zip_members": member_count,
        "zip_checksum_path": str(checksum_path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_root", type=Path)
    parser.add_argument("--case-study", type=Path, required=True)
    parser.add_argument("--case-data", type=Path, required=True)
    parser.add_argument("--extractor", type=Path, required=True)
    parser.add_argument("--readme", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--max-object-bytes",
        type=int,
        default=CAS_OBJECT_LIMIT,
    )
    args = parser.parse_args()
    result = build_package(args)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
