#!/usr/bin/env python3
"""Package only Adaptive outer-policy records and generated harnesses."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any


PACKAGE_ROOT = "adaptive_v1_cp26_outer_records"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def compact_candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    outcome = candidate.get("outcome")
    promotion = candidate.get("promotion")
    return {
        "proposal_id": candidate.get("proposal_id"),
        "state_id": candidate.get("state_id"),
        "outcome": (
            {
                "repeat_scores": outcome.get("repeat_scores"),
                "mean": outcome.get("score"),
                "sem": outcome.get("score_sem"),
                "usage": outcome.get("usage"),
            }
            if isinstance(outcome, dict)
            else None
        ),
        "promotion": (
            {
                "repeat_scores": promotion.get("repeat_scores"),
                "mean": promotion.get("score"),
                "sem": promotion.get("score_sem"),
                "usage": promotion.get("usage"),
            }
            if isinstance(promotion, dict)
            else None
        ),
        "reward": candidate.get("reward"),
        "assessment": candidate.get("assessment"),
        "decision": candidate.get("public_decision"),
    }


def package(args: argparse.Namespace) -> dict[str, Any]:
    case_data_path = args.case_data.resolve()
    case_data = json.loads(case_data_path.read_text(encoding="utf-8"))
    task_root = args.task_root.resolve()
    run_root = task_root / "runs" / "circle_packing_26"
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    checksum_path = output.with_suffix(output.suffix + ".sha256")
    if checksum_path.exists():
        checksum_path.unlink()

    with tempfile.TemporaryDirectory(
        prefix="adaptive-v1-cp26-outer-records-"
    ) as temporary:
        staging = Path(temporary) / PACKAGE_ROOT
        staging.mkdir(parents=True)
        copy_file(args.readme.resolve(), staging / "README_CN.md")
        copy_file(args.case_study.resolve(), staging / "CASE_STUDY.md")
        copy_file(
            case_data_path,
            staging / "case_data" / "complete_outer_record.json",
        )
        copy_file(
            args.extractor.resolve(),
            staging / "scripts" / "extract_adaptive_case_study.py",
        )
        write_json(
            staging / "experiment_config.json",
            case_data.get("resolved_config"),
        )
        (staging / "outer_policy_versions" / "proposer_system.txt").parent.mkdir(
            parents=True, exist_ok=True
        )
        (
            staging / "outer_policy_versions" / "proposer_system.txt"
        ).write_text(
            str(case_data.get("proposer_system") or "") + "\n",
            encoding="utf-8",
        )

        round_summaries = []
        for round_record in case_data.get("rounds", []):
            round_index = int(round_record["round"])
            round_dir = staging / "rounds" / f"round_{round_index:02d}"
            context = {
                "round": round_index,
                "context_ref": round_record.get("context_ref"),
                "entering_state_id": round_record.get("context_state_id"),
                "entering_harness_fields": round_record.get(
                    "harness_fields"
                ),
                "entering_system_prompt": round_record.get("system_prompt"),
                "managed_prompt_sections": round_record.get(
                    "prompt_sections"
                ),
                "update_summary": round_record.get("update_summary"),
                "evidence": round_record.get("evidence"),
                "outer_history": round_record.get("outer_history"),
                "base_user_prompt": round_record.get("base_user_prompt"),
                "base_user_prompt_sha256": round_record.get(
                    "base_user_prompt_sha256"
                ),
                "base_user_prompt_chars": round_record.get(
                    "base_user_prompt_chars"
                ),
                "optimizer_memory": round_record.get("optimizer_memory"),
                "optimizer_archive_ref": round_record.get(
                    "optimizer_archive_ref"
                ),
                "optimizer_archive": round_record.get("optimizer_archive"),
            }
            write_json(round_dir / "01_context.json", context)
            proposals = {
                "round": round_index,
                "served_model": (
                    round_record.get("batch_metadata") or {}
                ).get("policy_served_model"),
                "batch_ref": round_record.get("batch_ref"),
                "batch_metadata": round_record.get("batch_metadata"),
                "outer_usage": round_record.get("outer_usage"),
                "policy_samples": round_record.get("policy_samples"),
            }
            write_json(round_dir / "02_proposals.json", proposals)

            candidate_harnesses = []
            for candidate in round_record.get("executed_candidates", []):
                candidate_harnesses.append(
                    {
                        "proposal_id": candidate.get("proposal_id"),
                        "state_id": candidate.get("state_id"),
                        "semantic_action": candidate.get("semantic_action"),
                        "candidate_harness_ref": candidate.get(
                            "candidate_harness_ref"
                        ),
                        "candidate_harness": candidate.get(
                            "candidate_harness"
                        ),
                        "decision": candidate.get("public_decision"),
                    }
                )
            write_json(
                round_dir / "03_candidate_harnesses.json",
                {
                    "round": round_index,
                    "candidate_harnesses": candidate_harnesses,
                },
            )
            score_record = {
                "round": round_index,
                "candidates": [
                    compact_candidate(candidate)
                    for candidate in round_record.get(
                        "executed_candidates", []
                    )
                ],
                "selection": round_record.get("selection"),
                "round_finished": round_record.get("round_finished"),
                "controller": round_record.get("controller"),
            }
            write_json(
                round_dir / "04_scores_and_decisions.json",
                score_record,
            )
            round_summaries.append(
                {
                    "round": round_index,
                    "served_model": proposals["served_model"],
                    "sampled": (
                        round_record.get("batch_metadata") or {}
                    ).get("sampled"),
                    "compiled": (
                        round_record.get("batch_metadata") or {}
                    ).get("compiled"),
                    "candidate_harnesses": sum(
                        row["candidate_harness"] is not None
                        for row in candidate_harnesses
                    ),
                    "selection": round_record.get("selection"),
                    "controller": round_record.get("controller"),
                }
            )

        optimizer_config = (
            case_data.get("resolved_config", {})
            .get("plugins", {})
            .get("config", {})
            .get("optimizer", {})
        )
        initial_harness = (
            case_data.get("resolved_config", {})
            .get("initial_components", {})
            .get("harness", {})
        )
        write_json(
            staging
            / "outer_policy_versions"
            / "base"
            / "version.json",
            {
                "version": "base",
                "served_rounds": [0, 1, 2],
                "model_component": optimizer_config.get("model_component"),
                "proposal_temperature": optimizer_config.get("temperature"),
                "proposal_max_tokens": optimizer_config.get("max_tokens"),
                "proposal_seed": optimizer_config.get("seed"),
                "initial_inner_harness": initial_harness,
            },
        )

        update_metadata = {
            row["update"]: row
            for row in case_data.get("adapter_updates", [])
        }
        for update_name, served_rounds in (
            ("update-000", [3, 4, 5, 6]),
            ("update-001", [7, 8, 9]),
        ):
            short_name = update_name.replace("update-", "u")
            destination = (
                staging / "outer_policy_versions" / short_name
            )
            metadata = update_metadata.get(update_name, {})
            write_json(
                destination / "version.json",
                {
                    "version": short_name,
                    "source_update": update_name,
                    "served_rounds": served_rounds,
                    "training": metadata,
                },
            )
            source_adapter = (
                run_root / "outer-policy" / "adapters" / update_name
            )
            for filename in ("adapter_config.json", "sah_training.json"):
                source = source_adapter / filename
                if source.is_file():
                    copy_file(source, destination / filename)
            source_batch = (
                run_root
                / "outer-policy"
                / "batches"
                / f"{update_name}.jsonl"
            )
            if source_batch.is_file():
                copy_file(
                    source_batch, destination / "training_batch.jsonl"
                )

        index = {
            "schema": "adaptive.outer-records-bundle/v1",
            "task": case_data.get("task"),
            "experiment_id": case_data.get("experiment_id"),
            "rounds": round_summaries,
            "counts": {
                "rounds": len(round_summaries),
                "raw_policy_samples": sum(
                    len(row.get("policy_samples") or [])
                    for row in case_data.get("rounds", [])
                ),
                "executed_candidates": sum(
                    len(row.get("executed_candidates") or [])
                    for row in case_data.get("rounds", [])
                ),
                "materialized_candidate_harnesses": sum(
                    candidate.get("candidate_harness") is not None
                    for row in case_data.get("rounds", [])
                    for candidate in row.get("executed_candidates", [])
                ),
                "outer_policy_versions": 3,
            },
            "excluded": [
                "inner-runs",
                "episode records and raw inner traces",
                "CAS object store",
                "adapter_model.safetensors",
                "optimizer.pt",
                "tokenizer blobs",
            ],
        }
        write_json(staging / "OUTER_RECORDS_INDEX.json", index)

        checksum_rows = []
        for path in sorted(staging.rglob("*")):
            if not path.is_file() or path.name == "SHA256SUMS":
                continue
            checksum_rows.append(
                f"{sha256_file(path)}  {path.relative_to(staging)}"
            )
        (staging / "SHA256SUMS").write_text(
            "\n".join(checksum_rows) + "\n",
            encoding="utf-8",
        )

        with zipfile.ZipFile(
            output,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as archive:
            for path in sorted(staging.rglob("*")):
                if path.is_file():
                    archive.write(
                        path,
                        arcname=str(
                            Path(PACKAGE_ROOT)
                            / path.relative_to(staging)
                        ),
                    )

    with zipfile.ZipFile(output) as archive:
        corrupt = archive.testzip()
        if corrupt is not None:
            raise RuntimeError(f"corrupt zip member: {corrupt}")
        member_count = len(archive.infolist())
    output_sha256 = sha256_file(output)
    checksum_path.write_text(
        f"{output_sha256}  {output.name}\n", encoding="utf-8"
    )
    return {
        "zip_path": str(output),
        "zip_bytes": output.stat().st_size,
        "zip_sha256": output_sha256,
        "zip_members": member_count,
        "counts": index["counts"],
        "excluded": index["excluded"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_root", type=Path)
    parser.add_argument("--case-study", type=Path, required=True)
    parser.add_argument("--case-data", type=Path, required=True)
    parser.add_argument("--extractor", type=Path, required=True)
    parser.add_argument("--readme", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(package(args), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
