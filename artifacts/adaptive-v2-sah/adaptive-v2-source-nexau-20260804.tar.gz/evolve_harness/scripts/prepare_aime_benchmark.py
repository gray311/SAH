#!/usr/bin/env python3
"""Materialize the pinned AIME 2022--2024 split and verifier manifest."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
REVISION = "73e1eba765ad5847cdb5d1e2e7aaf7b22b585798"
DATASET = "allenai/aime-2022-2025"
ROWS_ENDPOINT = "https://datasets-server.huggingface.co/rows"
URL_PATTERN = re.compile(
    r"/(?P<year>20[0-9]{2})_AIME_(?P<part>I|II)_Problems/Problem_(?P<number>[0-9]+)"
)


def fetch_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for offset in (0, 100):
        query = urllib.parse.urlencode(
            {
                "dataset": DATASET,
                "config": "default",
                "split": "train",
                "offset": offset,
                "length": 100,
                "revision": REVISION,
            }
        )
        request = urllib.request.Request(
            f"{ROWS_ENDPOINT}?{query}",
            headers={"User-Agent": "adaptive-aime-benchmark/1.0"},
        )
        with urllib.request.urlopen(request, timeout=60) as response:
            payload = json.load(response)
        rows.extend(dict(item["row"]) for item in payload.get("rows", []))
    if len(rows) != 120:
        raise RuntimeError(f"expected 120 pinned AIME rows, received {len(rows)}")
    return rows


def parse_identity(row: dict[str, Any]) -> tuple[int, str, int]:
    match = URL_PATTERN.search(str(row.get("url") or ""))
    if not match:
        raise ValueError(f"cannot parse AIME identity from {row.get('url')!r}")
    return int(match["year"]), match["part"], int(match["number"])


def materialize(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    public: list[dict[str, Any]] = []
    answers: dict[str, str] = {}
    split_by_year = {
        2022: ["update", "outcome"],
        2023: ["promotion"],
        2024: ["final"],
    }
    selected = [row for row in rows if int(row["year"]) in split_by_year]
    selected.sort(key=parse_identity)
    for row in selected:
        year, part, number = parse_identity(row)
        aime_id = f"aime-{year}-{part.lower()}-{number:02d}"
        answers[aime_id] = f"{int(row['answer']):03d}"
        public.append(
            {
                "id": aime_id,
                "input": (
                    f"# {year} AIME {part}, Problem {number}\n\n"
                    f"{str(row['problem']).strip()}\n\n"
                    "Solve the problem and return the requested AIME integer."
                ),
                "metadata": {
                    "benchmark_group": "mathematics",
                    "title": f"{year} AIME {part} Problem {number}",
                    "candidate_name": "response.txt",
                    "evaluator_kind": "aime_exact_match",
                    "official_task_id": "aime2024",
                    "aime_id": aime_id,
                    "year": year,
                    "part": part,
                    "problem_number": number,
                    "evogate_splits": split_by_year[year],
                    "direction": "maximize",
                    "source_url": row["url"],
                },
            }
        )
    if len(public) != 90 or len(answers) != 90:
        raise RuntimeError("expected exactly 90 AIME 2022--2024 problems")
    manifest = {
        "schema": "adaptive.aime-answer-manifest/v1",
        "dataset": DATASET,
        "revision": REVISION,
        "rows_sha256": hashlib.sha256(
            json.dumps(public, sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest(),
        "split_protocol": {
            "update_outcome": "AIME 2022 (30 questions)",
            "promotion": "AIME 2023 (30 questions; feedback hidden)",
            "final": "AIME 2024 (30 questions; evaluate once)",
        },
        "answers": answers,
    }
    return public, manifest


def pilot_rows(public: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Build a preregistered search subset while keeping the full final set."""

    calibration_numbers = {1, 5, 9, 13}
    selected: list[dict[str, Any]] = []
    for source in public:
        metadata = dict(source["metadata"])
        year = int(metadata["year"])
        if year != 2024 and int(metadata["problem_number"]) not in calibration_numbers:
            continue
        metadata["official_task_id"] = "aime2024-pilot"
        selected.append({**source, "metadata": metadata})
    counts = {
        year: sum(int(row["metadata"]["year"]) == year for row in selected)
        for year in (2022, 2023, 2024)
    }
    if counts != {2022: 8, 2023: 8, 2024: 30}:
        raise RuntimeError(f"unexpected AIME pilot split sizes: {counts}")
    return selected


def extended_protocol_rows(
    rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Materialize a clean 2022-search/2023-select/2025-final protocol.

    AIME 2024 is intentionally excluded because earlier pilot and diagnostic
    runs already inspected it.  The 2025 questions are the new final lockbox.
    """

    public: list[dict[str, Any]] = []
    search: list[dict[str, Any]] = []
    answers: dict[str, str] = {}
    selected = sorted(rows, key=parse_identity)
    for row in selected:
        year, part, number = parse_identity(row)
        aime_id = f"aime-{year}-{part.lower()}-{number:02d}"
        answers[aime_id] = f"{int(row['answer']):03d}"
        entry = {
            "id": aime_id,
            "input": (
                f"# {year} AIME {part}, Problem {number}\n\n"
                f"{str(row['problem']).strip()}\n\n"
                "Solve the problem and return the requested AIME integer."
            ),
            "metadata": {
                "benchmark_group": "mathematics",
                "title": f"{year} AIME {part} Problem {number}",
                "candidate_name": "response.txt",
                "evaluator_kind": "aime_exact_match",
                "official_task_id": "aime-2022-2025-public",
                "aime_id": aime_id,
                "year": year,
                "part": part,
                "problem_number": number,
                "direction": "maximize",
                "source_url": row["url"],
            },
        }
        public.append(entry)
        if year == 2022:
            metadata = dict(entry["metadata"])
            metadata.update(
                {
                    "official_task_id": "aime-harness-search",
                    "evogate_splits": [
                        "update",
                        "outcome",
                        "promotion",
                        "final",
                    ],
                }
            )
            search.append({**entry, "metadata": metadata})
    if len(public) != 120 or len(search) != 30 or len(answers) != 120:
        raise RuntimeError(
            "expected 120 public rows, 30 search rows, and 120 answers"
        )
    manifest = {
        "schema": "adaptive.aime-answer-manifest/v1",
        "dataset": DATASET,
        "revision": REVISION,
        "rows_sha256": hashlib.sha256(
            json.dumps(public, sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest(),
        "split_protocol": {
            "search": "AIME 2022 (30 labeled questions)",
            "selection": "AIME 2023 (30 questions; one post-search gate)",
            "excluded": "AIME 2024 (contaminated by prior pilot diagnostics)",
            "final": "AIME 2025 (30 questions; sealed paired evaluation)",
        },
        "answers": answers,
    }
    return public, search, manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "evolve_harness"
        / "configs"
        / "benchmarks"
        / "harness_only_aime2024.jsonl",
    )
    parser.add_argument(
        "--answers",
        type=Path,
        default=ROOT
        / "evolve_harness"
        / "configs"
        / "benchmarks"
        / "verifier"
        / "aime_2022_2024_answers.json",
    )
    parser.add_argument(
        "--pilot-output",
        type=Path,
        default=ROOT
        / "evolve_harness"
        / "configs"
        / "benchmarks"
        / "harness_only_aime2024_pilot.jsonl",
    )
    parser.add_argument(
        "--extended-output",
        type=Path,
        default=ROOT
        / "evolve_harness"
        / "configs"
        / "benchmarks"
        / "aime_2022_2025_public.jsonl",
    )
    parser.add_argument(
        "--search-output",
        type=Path,
        default=ROOT
        / "evolve_harness"
        / "configs"
        / "benchmarks"
        / "harness_only_aime_harness_search.jsonl",
    )
    parser.add_argument(
        "--extended-answers",
        type=Path,
        default=ROOT
        / "evolve_harness"
        / "configs"
        / "benchmarks"
        / "verifier"
        / "aime_2022_2025_answers.json",
    )
    parser.add_argument(
        "--selection-output",
        type=Path,
        default=ROOT
        / "evolve_harness/configs/benchmarks/aime_2023_selection.jsonl",
    )
    parser.add_argument(
        "--selection-answers",
        type=Path,
        default=ROOT
        / "evolve_harness/configs/benchmarks/verifier/aime_2023_selection_answers.json",
    )
    parser.add_argument(
        "--final-output",
        type=Path,
        default=ROOT
        / "evolve_harness/configs/benchmarks/aime_2025_final.jsonl",
    )
    parser.add_argument(
        "--final-answers",
        type=Path,
        default=ROOT
        / "evolve_harness/configs/benchmarks/verifier/aime_2025_final_answers.json",
    )
    parser.add_argument(
        "--scaleup-protocol",
        type=Path,
        default=ROOT
        / "evolve_harness/configs/benchmarks/aime_scaleup_protocol.json",
    )
    args = parser.parse_args()
    source_rows = fetch_rows()
    public, manifest = materialize(source_rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.answers.parent.mkdir(parents=True, exist_ok=True)
    args.pilot_output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in public),
        encoding="utf-8",
    )
    args.answers.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    pilot = pilot_rows(public)
    args.pilot_output.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in pilot),
        encoding="utf-8",
    )
    extended, search, extended_answers = extended_protocol_rows(source_rows)
    args.extended_output.parent.mkdir(parents=True, exist_ok=True)
    args.search_output.parent.mkdir(parents=True, exist_ok=True)
    args.extended_answers.parent.mkdir(parents=True, exist_ok=True)
    args.extended_output.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in extended),
        encoding="utf-8",
    )
    args.search_output.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in search),
        encoding="utf-8",
    )
    args.extended_answers.write_text(
        json.dumps(extended_answers, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    by_year = {
        year: [row for row in extended if int(row["metadata"]["year"]) == year]
        for year in (2023, 2025)
    }
    year_answers = {
        year: {
            row["metadata"]["aime_id"]: extended_answers["answers"][
                row["metadata"]["aime_id"]
            ]
            for row in by_year[year]
        }
        for year in by_year
    }
    for path, rows_for_year in (
        (args.selection_output, by_year[2023]),
        (args.final_output, by_year[2025]),
    ):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            "".join(
                json.dumps(row, ensure_ascii=False) + "\n"
                for row in rows_for_year
            ),
            encoding="utf-8",
        )
    for path, year in (
        (args.selection_answers, 2023),
        (args.final_answers, 2025),
    ):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "schema": "adaptive.aime-answer-manifest/v1",
                    "dataset": DATASET,
                    "revision": REVISION,
                    "year": year,
                    "answers": year_answers[year],
                },
                indent=2,
                ensure_ascii=False,
            )
            + "\n",
            encoding="utf-8",
        )

    def file_sha(path: Path) -> str:
        return hashlib.sha256(path.read_bytes()).hexdigest()

    protocol_identity = hashlib.sha256(
        (
            REVISION
            + file_sha(args.search_output)
            + file_sha(args.selection_output)
            + file_sha(args.final_output)
        ).encode()
    ).hexdigest()

    def derived_seeds(label: str, count: int) -> list[int]:
        return [
            int.from_bytes(
                hashlib.sha256(
                    f"{protocol_identity}:{label}:{index}".encode()
                ).digest()[:8],
                "big",
            )
            % (2**63 - 1)
            for index in range(count)
        ]

    scaleup_protocol = {
        "schema": "adaptive.aime-scaleup-protocol/v1",
        "protocol_id": f"sha256:{protocol_identity}",
        "dataset": DATASET,
        "revision": REVISION,
        "arm": "frozen-weight_harness-only",
        "years": {
            "search": 2022,
            "selection": 2023,
            "excluded_contaminated": 2024,
            "final": 2025,
        },
        "manifests": {
            "search_sha256": file_sha(args.search_output),
            "selection_sha256": file_sha(args.selection_output),
            "selection_answers_sha256": file_sha(args.selection_answers),
            "final_sha256": file_sha(args.final_output),
            "final_answers_sha256": file_sha(args.final_answers),
        },
        "archive_size": 6,
        "selection_seeds": derived_seeds("selection", 3),
        "final_seeds": derived_seeds("final", 5),
        "common_max_tokens": 8192,
        "selection_gate": {
            "minimum_correct_delta": 3,
            "paired_problem_cluster_bootstrap_one_sided_confidence": 0.90,
            "minimum_lcb": 0.0,
            "maximum_completion_token_ratio": 1.20,
        },
        "bootstrap_samples": 10000,
    }
    args.scaleup_protocol.parent.mkdir(parents=True, exist_ok=True)
    args.scaleup_protocol.write_text(
        json.dumps(scaleup_protocol, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "questions": len(public),
                "pilot_questions": len(pilot),
                "output": str(args.output),
                "pilot_output": str(args.pilot_output),
                "answers": str(args.answers),
                "extended_questions": len(extended),
                "search_questions": len(search),
                "extended_output": str(args.extended_output),
                "search_output": str(args.search_output),
                "extended_answers": str(args.extended_answers),
                "selection_output": str(args.selection_output),
                "selection_answers": str(args.selection_answers),
                "final_output": str(args.final_output),
                "final_answers": str(args.final_answers),
                "scaleup_protocol": str(args.scaleup_protocol),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
