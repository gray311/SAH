#!/usr/bin/env python3
"""Evaluate the frozen initial AIME harness against a managed vLLM endpoint."""
from __future__ import annotations

import argparse
import json
import os
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

from evolve_harness.aime import (
    INITIAL_SYSTEM_PROMPT,
    answer_for,
    extract_answer,
    rows_for_split,
)


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def request_completion(
    *, base_url: str, model: str, prompt: str, seed: int, max_tokens: int
) -> dict[str, Any]:
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": INITIAL_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.6,
        "top_p": 0.95,
        "max_tokens": max_tokens,
        "seed": seed,
        "stream": False,
        "chat_template_kwargs": {"enable_thinking": False},
    }
    encoded = json.dumps(payload).encode()
    request = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=encoded,
        headers={"Content-Type": "application/json", "Authorization": "Bearer local-no-auth"},
        method="POST",
    )
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=900) as response:
                return json.load(response)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(2**attempt)
    raise RuntimeError(f"completion failed after three attempts: {last_error}")


def evaluate_one(
    *, row: dict[str, Any], index: int, args: argparse.Namespace
) -> dict[str, Any]:
    metadata = dict(row["metadata"])
    started = time.monotonic()
    response = request_completion(
        base_url=args.base_url,
        model=args.model,
        prompt=str(row["input"]),
        seed=args.seed + index,
        max_tokens=args.max_tokens,
    )
    choice = dict(response.get("choices", [{}])[0])
    message = dict(choice.get("message") or {})
    content = str(message.get("content") or "")
    reasoning = str(message.get("reasoning_content") or "")
    predicted = extract_answer(content)
    expected = answer_for(str(metadata["aime_id"]))
    return {
        "aime_id": metadata["aime_id"],
        "year": metadata["year"],
        "part": metadata["part"],
        "problem_number": metadata["problem_number"],
        "seed": args.seed + index,
        "predicted_answer": predicted,
        "expected_answer": expected,
        "correct": predicted == expected,
        "answer_extracted": predicted is not None,
        "finish_reason": choice.get("finish_reason"),
        "content": content,
        "reasoning_content": reasoning,
        "usage": response.get("usage", {}),
        "elapsed_seconds": time.monotonic() - started,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=23)
    parser.add_argument("--max-tokens", type=int, default=6144)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    if args.workers < 1 or args.max_tokens < 256:
        parser.error("--workers and --max-tokens must be positive")

    rows = rows_for_split("final")
    if len(rows) != 30:
        raise RuntimeError(f"expected 30 AIME 2024 final rows, found {len(rows)}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    lifecycle = args.output.with_suffix(".lifecycle.jsonl")
    with lifecycle.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"time": now(), "event": "initial_baseline_started", "model": args.model}) + "\n")
        handle.flush()
        os.fsync(handle.fileno())

    started = time.monotonic()
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(evaluate_one, row=row, index=index, args=args): index
            for index, row in enumerate(rows)
        }
        for future in as_completed(futures):
            results.append(future.result())
    results.sort(key=lambda item: (str(item["part"]), int(item["problem_number"])))
    correct = sum(bool(item["correct"]) for item in results)
    extracted = sum(bool(item["answer_extracted"]) for item in results)
    payload = {
        "schema": "adaptive.aime-initial-baseline/v1",
        "created_at": now(),
        "model": args.model,
        "base_url": args.base_url,
        "checkpoint": os.environ.get("MODEL_PATH"),
        "harness": {
            "system_prompt": INITIAL_SYSTEM_PROMPT,
            "temperature": 0.6,
            "top_p": 0.95,
            "max_tokens": args.max_tokens,
            "enable_thinking": False,
        },
        "protocol": {
            "benchmark": "AIME 2024 I+II",
            "questions": len(results),
            "samples_per_question": 1,
            "metric": "strict_integer_exact_match",
            "seed_base": args.seed,
        },
        "score": {
            "correct": correct,
            "total": len(results),
            "accuracy": correct / len(results),
            "answers_extracted": extracted,
        },
        "elapsed_seconds": time.monotonic() - started,
        "results": results,
    }
    args.output.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with lifecycle.open("a", encoding="utf-8") as handle:
        handle.write(
            json.dumps(
                {
                    "time": now(),
                    "event": "initial_baseline_finished",
                    "exit_reason": "all AIME 2024 questions evaluated",
                    "correct": correct,
                    "total": len(results),
                }
            )
            + "\n"
        )
        handle.flush()
        os.fsync(handle.fileno())
    print(json.dumps(payload["score"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
