#!/usr/bin/env python3
"""Run the one-shot paired AIME-2025 final after verifying a winner lock."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

from evogate.checkpoints import open_store
from evolve_harness.aime_staged import (
    ROOT,
    evaluate_variants,
    exclusive_json,
    load_answers,
    load_protocol,
    load_rows,
    paired_analysis,
    sha256_file,
    verify_file,
)


FINAL_ROWS = ROOT / "evolve_harness/configs/benchmarks/aime_2025_final.jsonl"
FINAL_ANSWERS = (
    ROOT / "evolve_harness/configs/benchmarks/verifier/aime_2025_final_answers.json"
)


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def harness_sha(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--winner-lock", type=Path, required=True)
    parser.add_argument("--winner-lock-sha", type=Path, required=True)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("sealed final output exists; refusing rerun")
    expected_lock_sha = args.winner_lock_sha.read_text(encoding="utf-8").strip()
    if sha256_file(args.winner_lock) != expected_lock_sha:
        raise RuntimeError("winner lock hash mismatch")
    lock = json.loads(args.winner_lock.read_text(encoding="utf-8"))
    protocol = load_protocol()
    if lock.get("protocol_id") != protocol["protocol_id"]:
        raise RuntimeError("winner lock protocol mismatch")

    # No AIME-2025 path is opened before every winner-lock check above passes.
    manifests = dict(protocol["manifests"])
    verify_file(FINAL_ROWS, manifests["final_sha256"])
    verify_file(FINAL_ANSWERS, manifests["final_answers_sha256"])
    rows = load_rows(FINAL_ROWS, expected_year=2025)
    answers = load_answers(FINAL_ANSWERS, expected_year=2025)

    store = open_store(Path(lock["run_dir"]))
    initial_state = store.get_state(str(lock["initial_state_id"]))
    winner_state = store.get_state(str(lock["winner_state_id"]))
    initial_harness = store.get_json(initial_state.components["harness"])
    winner_harness = store.get_json(winner_state.components["harness"])
    if harness_sha(initial_harness) != lock["initial_harness_sha256"]:
        raise RuntimeError("initial harness differs from winner lock")
    if harness_sha(winner_harness) != lock["winner_harness_sha256"]:
        raise RuntimeError("winner harness differs from winner lock")
    variants = [
        {"label": "initial", "state_id": initial_state.state_id, "harness": initial_harness},
        {"label": lock["winner_label"], "state_id": winner_state.state_id, "harness": winner_harness},
    ]
    results = evaluate_variants(
        variants=variants,
        rows=rows,
        base_seeds=[int(item) for item in protocol["final_seeds"]],
        role="final",
        answers=answers,
        base_url=args.base_url,
        model=args.model,
        workers=args.workers,
        common_max_tokens=int(protocol["common_max_tokens"]),
    )
    paired = paired_analysis(
        results[1],
        results[0],
        bootstrap_seed=int(
            hashlib.sha256(
                f"{protocol['protocol_id']}:final-bootstrap".encode()
            ).hexdigest()[:16],
            16,
        ),
        samples=int(protocol["bootstrap_samples"]),
    )
    payload = {
        "schema": "adaptive.aime-sealed-final/v1",
        "created_at": now(),
        "protocol_id": protocol["protocol_id"],
        "winner_lock": str(args.winner_lock),
        "winner_lock_sha256": expected_lock_sha,
        "initial": results[0],
        "winner": results[1],
        "paired_analysis": paired,
    }
    exclusive_json(args.output, payload)
    print(
        json.dumps(
            {
                "initial": f"{results[0]['correct']}/{results[0]['total']}",
                "winner": f"{results[1]['correct']}/{results[1]['total']}",
                "delta": paired["accuracy_delta"],
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
