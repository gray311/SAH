#!/usr/bin/env python3
"""Freeze an archive and select one AIME harness on the 2023 gate only."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

from evolve_harness.aime_staged import (
    ROOT,
    confirmed_archive,
    evaluate_variants,
    exclusive_json,
    exclusive_text,
    load_answers,
    load_protocol,
    load_rows,
    paired_analysis,
    sha256_file,
    verify_file,
)


SELECTION_ROWS = ROOT / "evolve_harness/configs/benchmarks/aime_2023_selection.jsonl"
SELECTION_ANSWERS = (
    ROOT
    / "evolve_harness/configs/benchmarks/verifier/aime_2023_selection_answers.json"
)


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")

    protocol = load_protocol()
    manifests = dict(protocol["manifests"])
    verify_file(SELECTION_ROWS, manifests["selection_sha256"])
    verify_file(SELECTION_ANSWERS, manifests["selection_answers_sha256"])
    output = args.output_dir / "aime_2023_selection.json"
    archive_lock = args.output_dir / "aime_archive_lock.json"
    winner_lock = args.output_dir / "aime_winner_lock.json"
    winner_sha = args.output_dir / "aime_winner_lock.sha256"
    if any(path.exists() for path in (output, archive_lock, winner_lock, winner_sha)):
        raise RuntimeError("staged selection output already exists; refusing rerun")

    initial, archive = confirmed_archive(
        args.run_dir, int(protocol["archive_size"])
    )
    archive_payload = {
        "schema": "adaptive.aime-archive-lock/v1",
        "created_at": now(),
        "protocol_id": protocol["protocol_id"],
        "run_dir": str(args.run_dir.resolve()),
        "initial_state_id": initial["state_id"],
        "archive": archive,
        "selection_manifest_sha256": manifests["selection_sha256"],
    }
    exclusive_json(archive_lock, archive_payload)

    rows = load_rows(SELECTION_ROWS, expected_year=2023)
    answers = load_answers(SELECTION_ANSWERS, expected_year=2023)
    variants = [initial, *archive]
    results = evaluate_variants(
        variants=variants,
        rows=rows,
        base_seeds=[int(item) for item in protocol["selection_seeds"]],
        role="selection",
        answers=answers,
        base_url=args.base_url,
        model=args.model,
        workers=args.workers,
        common_max_tokens=int(protocol["common_max_tokens"]),
    )
    baseline = results[0]
    gate = dict(protocol["selection_gate"])
    assessed = []
    for index, result in enumerate(results[1:]):
        paired = paired_analysis(
            result,
            baseline,
            bootstrap_seed=int(
                hashlib.sha256(
                    f"{protocol['protocol_id']}:selection-bootstrap:{index}".encode()
                ).hexdigest()[:16],
                16,
            ),
            samples=int(protocol["bootstrap_samples"]),
        )
        correct_delta = int(result["correct"]) - int(baseline["correct"])
        token_ratio = float(result["completion_tokens"]) / max(
            1.0, float(baseline["completion_tokens"])
        )
        parse_delta = int(result["answers_extracted"]) - int(
            baseline["answers_extracted"]
        )
        passed = (
            correct_delta >= int(gate["minimum_correct_delta"])
            and paired["cluster_bootstrap_one_sided_90_lcb"]
            > float(gate["minimum_lcb"])
            and token_ratio <= float(gate["maximum_completion_token_ratio"])
            and parse_delta >= -1
        )
        result["paired_vs_initial"] = paired
        result["selection_gate"] = {
            "passed": passed,
            "correct_delta": correct_delta,
            "completion_token_ratio": token_ratio,
            "parseability_delta": parse_delta,
        }
        assessed.append(result)
    passing = [item for item in assessed if item["selection_gate"]["passed"]]
    def selection_key(item):
        return (
            item["selection_gate"]["correct_delta"],
            item["paired_vs_initial"]["cluster_bootstrap_one_sided_90_lcb"],
            -item["selection_gate"]["completion_token_ratio"],
        )

    best_key = max((selection_key(item) for item in passing), default=None)
    best = (
        [item for item in passing if selection_key(item) == best_key]
        if best_key is not None
        else []
    )
    winner = best[0] if len(best) == 1 else None
    ambiguous_tie = len(best) > 1
    payload = {
        "schema": "adaptive.aime-selection/v1",
        "created_at": now(),
        "protocol_id": protocol["protocol_id"],
        "archive_lock": str(archive_lock),
        "archive_lock_sha256": sha256_file(archive_lock),
        "baseline": baseline,
        "candidates": assessed,
        "gate_passed": winner is not None,
        "ambiguous_selection_tie": ambiguous_tie,
        "winner_state_id": winner["state_id"] if winner else None,
    }
    exclusive_json(output, payload)
    if winner is None:
        print(
            json.dumps(
                {
                    "gate_passed": False,
                    "ambiguous_selection_tie": ambiguous_tie,
                    "final_opened": False,
                }
            )
        )
        return 3

    winner_payload = {
        "schema": "adaptive.aime-winner-lock/v1",
        "created_at": now(),
        "protocol_id": protocol["protocol_id"],
        "selection_output": str(output),
        "selection_output_sha256": sha256_file(output),
        "run_dir": str(args.run_dir.resolve()),
        "initial_state_id": initial["state_id"],
        "initial_harness_sha256": hashlib.sha256(
            json.dumps(initial["harness"], sort_keys=True).encode()
        ).hexdigest(),
        "winner_label": winner["label"],
        "winner_state_id": winner["state_id"],
        "winner_harness_sha256": hashlib.sha256(
            json.dumps(winner["harness"], sort_keys=True).encode()
        ).hexdigest(),
        "selection_gate": winner["selection_gate"],
    }
    exclusive_json(winner_lock, winner_payload)
    exclusive_text(winner_sha, sha256_file(winner_lock) + "\n")
    print(
        json.dumps(
            {
                "gate_passed": True,
                "winner": winner["label"],
                "winner_lock_sha256": sha256_file(winner_lock),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
