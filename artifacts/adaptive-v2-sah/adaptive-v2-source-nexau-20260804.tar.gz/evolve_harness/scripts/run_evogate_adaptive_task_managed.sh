#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 7 ] || [ "$#" -gt 9 ]; then
  echo \
    "usage: $0 TASK SERVING_GPU TRAINING_GPU PORT RUN_ROOT SERVICE_DIR SEED [ROUNDS [RESTORE_CAMPAIGN_ROOT]]" \
    >&2
  exit 2
fi

TASK=$1
SERVING_GPU=$2
TRAINING_GPU=$3
PORT=$4
RUN_ROOT=$5
SERVICE_DIR=$6
SEED=$7
ROUNDS=${8:-10}
RESTORE_CAMPAIGN_ROOT=${9:-}
OBJECTIVE_PROTOCOL=${OBJECTIVE_PROTOCOL:-v1}
METHOD_ARM=${METHOD_ARM:-adaptive}
ROLLOUT_REPEATS=${ROLLOUT_REPEATS:-3}
FEEDBACK_REPEATS=${FEEDBACK_REPEATS:-3}
TRAINING_MAX_LENGTH=${TRAINING_MAX_LENGTH:-4096}
INNER_MAX_TOKENS=${INNER_MAX_TOKENS:-4096}
PROPOSER_MAX_TOKENS=${PROPOSER_MAX_TOKENS:-2048}
TRAINING_MAX_SECONDS=${TRAINING_MAX_SECONDS:-3600}
PROMOTION_TOP_K=${PROMOTION_TOP_K:-2}
PROPOSALS=${PROPOSALS:-4}
AIME_STAGED_EVAL=${AIME_STAGED_EVAL:-0}
MAX_WORKING_REGRESSION_RATIO=${MAX_WORKING_REGRESSION_RATIO:-0.10}

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
CAMPAIGN_PYTHON=${CAMPAIGN_PYTHON:-"$ROOT/.venv-nexau/bin/python"}
TRAINING_PYTHON=${TRAINING_PYTHON:-"$CAMPAIGN_PYTHON"}
MODEL=${MODEL_PATH:-Qwen/Qwen3.5-9B}
SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-Qwen3.5-9B}
START_SERVICE="$ROOT/evolve_harness/scripts/start_evogate_qwen_runtime_lora.sh"
STOP_SERVICE="$ROOT/sah_infra/scripts/stop_vllm.sh"
WATCHDOG="$ROOT/evolve_harness/scripts/watch_service_cleanup.py"
HEALTH_MONITOR="$ROOT/evolve_harness/scripts/monitor_evogate_harnessopt_campaign.py"
LAUNCHER="$ROOT/evolve_harness/scripts/run_evogate_harnessopt_campaign.py"
LIFECYCLE="$RUN_ROOT/managed_lifecycle.jsonl"
MANAGER_LOG="$RUN_ROOT/manager.log"
SNAPSHOT_DIR="$RUN_ROOT/managed_snapshots"

resolve_vllm_python() {
  local candidate
  local candidates=()
  if [ -n "${VLLM_PYTHON:-}" ]; then
    candidates+=("$VLLM_PYTHON")
  else
    candidates+=(
      "$ROOT/.venv-adaptive-vllm/bin/python"
      "/home/nli61/.conda/envs/vllm-serve/bin/python"
    )
    candidate=$(command -v python 2>/dev/null || true)
    if [ -n "$candidate" ]; then
      candidates+=("$candidate")
    fi
  fi
  for candidate in "${candidates[@]}"; do
    if [ -x "$candidate" ] &&
       "$candidate" -c 'import vllm' >/dev/null 2>&1; then
      VLLM_PYTHON=$candidate
      export VLLM_PYTHON
      return 0
    fi
  done
  echo \
    "no vLLM-capable Python found; set VLLM_PYTHON or run: ./adaptive.sh setup core" \
    >&2
  return 4
}

resolve_vllm_python

campaign_pid=
watchdog_pid=
training_guard_pid=
health_monitor_pid=
cleanup_started=0

record() {
  local event=$1
  shift
  "$CAMPAIGN_PYTHON" - "$LIFECYCLE" "$event" "$@" <<'PY'
import json
import os
import sys
from datetime import datetime
from pathlib import Path

path = Path(sys.argv[1])
event = sys.argv[2]
fields = {}
for item in sys.argv[3:]:
    key, value = item.split("=", 1)
    if value.isdigit():
        value = int(value)
    fields[key] = value
path.parent.mkdir(parents=True, exist_ok=True)
with path.open("a", encoding="utf-8") as handle:
    handle.write(json.dumps(
        {
            "time": datetime.now().astimezone().isoformat(timespec="seconds"),
            "event": event,
            **fields,
        },
        ensure_ascii=False,
    ) + "\n")
    handle.flush()
    os.fsync(handle.fileno())
PY
}

snapshot() {
  local label=$1
  mkdir -p "$SNAPSHOT_DIR"
  nvidia-smi --query-gpu=index,uuid,memory.used,memory.free,utilization.gpu \
    --format=csv,noheader > "$SNAPSHOT_DIR/gpu_${label}.txt" 2>&1 || true
  nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name,used_memory \
    --format=csv,noheader > \
    "$SNAPSHOT_DIR/gpu_processes_${label}.txt" 2>&1 || true
  ps -eo user=,pid=,ppid=,stat=,etime=,%cpu=,cmd= \
    > "$SNAPSHOT_DIR/processes_${label}.txt" 2>&1 || true
}

gpu_compute_pids() {
  local gpu=$1
  local owner
  owner=$(id -un)
  nvidia-smi -i "$gpu" --query-compute-apps=pid \
    --format=csv,noheader,nounits 2>/dev/null |
    sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p' |
    while read -r pid; do
      process_owner=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
      if [ "$process_owner" = "$owner" ]; then
        echo "$pid"
      fi
    done
}

gpu_all_compute_pids() {
  local gpu=$1
  nvidia-smi -i "$gpu" --query-compute-apps=pid \
    --format=csv,noheader,nounits 2>/dev/null |
    sed -n '/^[[:space:]]*[0-9][0-9]*[[:space:]]*$/p'
}

pid_is_descendant_of() {
  local candidate=$1
  local ancestor=$2
  local parent
  for _ in $(seq 1 64); do
    if [ "$candidate" = "$ancestor" ]; then
      return 0
    fi
    if ! [[ "$candidate" =~ ^[1-9][0-9]*$ ]] ||
       [ "$candidate" -le 1 ]; then
      return 1
    fi
    parent=$(ps -o ppid= -p "$candidate" 2>/dev/null | tr -d ' ')
    if ! [[ "$parent" =~ ^[1-9][0-9]*$ ]] ||
       [ "$parent" = "$candidate" ]; then
      return 1
    fi
    candidate=$parent
  done
  return 1
}

guard_training_gpu() {
  local manager_pid=$1
  local authorized_root_pid=$2
  local occupants
  local foreign
  trap 'exit 0' TERM INT HUP
  while kill -0 "$authorized_root_pid" 2>/dev/null; do
    occupants=$(gpu_all_compute_pids "$TRAINING_GPU" || true)
    foreign=
    for pid in $occupants; do
      if ! pid_is_descendant_of "$pid" "$authorized_root_pid"; then
        foreign="${foreign:+${foreign}_}${pid}"
      fi
    done
    if [ -n "$foreign" ]; then
      record \
        "training_gpu_foreign_process_detected" \
        "training_gpu=$TRAINING_GPU" \
        "foreign_pids=$foreign" \
        "campaign_pid=$authorized_root_pid"
      kill -TERM "$manager_pid" 2>/dev/null || true
      return 4
    fi
    sleep 30
  done
}

stop_training_guard() {
  if [ -z "${training_guard_pid:-}" ] ||
     ! kill -0 "$training_guard_pid" 2>/dev/null; then
    return
  fi
  kill -TERM "$training_guard_pid" 2>/dev/null || true
  wait "$training_guard_pid" 2>/dev/null || true
}

stop_health_monitor() {
  if [ -z "${health_monitor_pid:-}" ] ||
     ! kill -0 "$health_monitor_pid" 2>/dev/null; then
    return
  fi
  kill -TERM "$health_monitor_pid" 2>/dev/null || true
  for _ in $(seq 1 5); do
    if ! kill -0 "$health_monitor_pid" 2>/dev/null; then
      wait "$health_monitor_pid" 2>/dev/null || true
      return
    fi
    sleep 1
  done
  # The monitor may be inside its long poll sleep and defer TERM handling.
  # Never let an already-clean vLLM run remain stuck during handoff.
  record \
    "quality_supervisor_shutdown_escalated" \
    "quality_supervisor_pid=$health_monitor_pid"
  kill -KILL "$health_monitor_pid" 2>/dev/null || true
  wait "$health_monitor_pid" 2>/dev/null || true
}

terminate_campaign() {
  if [ -z "${campaign_pid:-}" ] || ! kill -0 "$campaign_pid" 2>/dev/null; then
    return
  fi
  record "campaign_shutdown_requested" "campaign_pid=$campaign_pid"
  kill -TERM -- "-$campaign_pid" 2>/dev/null || kill -TERM "$campaign_pid"
  for _ in $(seq 1 40); do
    if ! kill -0 "$campaign_pid" 2>/dev/null; then
      return
    fi
    sleep 1
  done
  record "campaign_shutdown_escalated" "campaign_pid=$campaign_pid"
  kill -KILL -- "-$campaign_pid" 2>/dev/null || kill -KILL "$campaign_pid"
}

cleanup() {
  local exit_code=$1
  local reason=$2
  if [ "$cleanup_started" -eq 1 ]; then
    return
  fi
  cleanup_started=1
  trap - EXIT INT TERM HUP
  record "managed_cleanup_start" "exit_code=$exit_code" "reason=$reason"
  stop_training_guard
  terminate_campaign
  stop_health_monitor
  "$STOP_SERVICE" "$SERVICE_DIR" "$reason" || true
  if [ -n "${watchdog_pid:-}" ] && kill -0 "$watchdog_pid" 2>/dev/null; then
    for _ in $(seq 1 20); do
      if ! kill -0 "$watchdog_pid" 2>/dev/null; then
        break
      fi
      sleep 1
    done
  fi
  snapshot "final"
  serving_remaining=$(gpu_compute_pids "$SERVING_GPU")
  training_remaining=
  if [ "$TRAINING_REQUIRED" -eq 1 ]; then
    training_remaining=$(gpu_compute_pids "$TRAINING_GPU")
  fi
  if [ -n "$serving_remaining" ] || [ -n "$training_remaining" ]; then
    record \
      "managed_cleanup_incomplete" \
      "serving_remaining=${serving_remaining//$'\n'/_}" \
      "training_remaining=${training_remaining//$'\n'/_}"
    return 4
  fi
  record "managed_cleanup_complete" "exit_code=$exit_code" "reason=$reason"
  return "$exit_code"
}

on_signal() {
  local signal_name=$1
  record "managed_signal" "signal=$signal_name"
  set +e
  cleanup 130 "signal_$signal_name"
  final_exit=$?
  trap - EXIT INT TERM HUP
  exit "$final_exit"
}

on_exit() {
  local status=$?
  set +e
  cleanup "$status" "manager_exit_$status"
  final_exit=$?
  trap - EXIT INT TERM HUP
  exit "$final_exit"
}

trap 'on_signal INT' INT
trap 'on_signal TERM' TERM
trap 'on_signal HUP' HUP
trap 'on_exit' EXIT

case "$METHOD_ARM" in
  adaptive|sah_every_round|policy_only)
    TRAINING_REQUIRED=1
    ;;
  context_only|stateless_frozen)
    TRAINING_REQUIRED=0
    ;;
  *)
    echo "unsupported METHOD_ARM: $METHOD_ARM" >&2
    exit 3
    ;;
esac

if ! [[ "$SERVING_GPU" =~ ^[0-9]+$ ]] ||
   ! [[ "$PORT" =~ ^[0-9]+$ ]] ||
   ! [[ "$SEED" =~ ^[0-9]+$ ]] ||
   ! [[ "$ROUNDS" =~ ^[1-9][0-9]*$ ]] ||
   ! [[ "$ROLLOUT_REPEATS" =~ ^[1-9][0-9]*$ ]] ||
   ! [[ "$TRAINING_MAX_LENGTH" =~ ^[1-9][0-9]*$ ]] ||
   ! [[ "$INNER_MAX_TOKENS" =~ ^[1-9][0-9]*$ ]] ||
   ! [[ "$PROPOSER_MAX_TOKENS" =~ ^[1-9][0-9]*$ ]] ||
   ! [[ "$TRAINING_MAX_SECONDS" =~ ^[1-9][0-9]*$ ]] ||
   ! [[ "$PROMOTION_TOP_K" =~ ^[1-9][0-9]*$ ]]; then
  echo "GPU IDs, port, seed, and rounds must be explicit positive integers" >&2
  exit 3
fi
if [ "$TRAINING_REQUIRED" -eq 1 ] &&
   ! [[ "$TRAINING_GPU" =~ ^[0-9]+$ ]]; then
  echo "METHOD_ARM=$METHOD_ARM requires an explicit numeric training GPU" >&2
  exit 3
fi
if [ "$TRAINING_REQUIRED" -eq 0 ] &&
   [ "$TRAINING_GPU" != "none" ]; then
  echo "METHOD_ARM=$METHOD_ARM requires TRAINING_GPU=none" >&2
  exit 3
fi
if [ "$OBJECTIVE_PROTOCOL" != "v1" ] &&
   [ "$OBJECTIVE_PROTOCOL" != "v2" ]; then
  echo "OBJECTIVE_PROTOCOL must be v1 or v2" >&2
  exit 3
fi
if [ "$TRAINING_REQUIRED" -eq 1 ] &&
   [ "$SERVING_GPU" = "$TRAINING_GPU" ]; then
  echo "serving and training GPUs must be disjoint" >&2
  exit 3
fi
if [ -e "$RUN_ROOT" ]; then
  echo "refusing non-fresh RUN_ROOT: $RUN_ROOT" >&2
  exit 3
fi
if [ -n "$(gpu_all_compute_pids "$SERVING_GPU")" ]; then
  echo "serving GPU $SERVING_GPU is occupied" >&2
  exit 4
fi
if [ "$TRAINING_REQUIRED" -eq 1 ] &&
   [ -n "$(gpu_all_compute_pids "$TRAINING_GPU")" ]; then
  echo "training GPU $TRAINING_GPU is occupied" >&2
  exit 4
fi

mkdir -p "$RUN_ROOT" "$SERVICE_DIR"
record \
  "managed_start" \
  "manager_pid=$$" \
  "task=$TASK" \
  "method_arm=$METHOD_ARM" \
  "serving_gpu=$SERVING_GPU" \
  "training_gpu=$TRAINING_GPU" \
  "port=$PORT" \
  "seed=$SEED" \
  "rounds=$ROUNDS" \
  "objective_protocol=$OBJECTIVE_PROTOCOL" \
  "rollout_repeats=$ROLLOUT_REPEATS" \
  "feedback_repeats=$FEEDBACK_REPEATS" \
  "training_max_length=$TRAINING_MAX_LENGTH" \
  "inner_max_tokens=$INNER_MAX_TOKENS" \
  "proposer_max_tokens=$PROPOSER_MAX_TOKENS" \
  "training_max_seconds=$TRAINING_MAX_SECONDS" \
  "promotion_top_k=$PROMOTION_TOP_K" \
  "proposals=$PROPOSALS" \
  "aime_staged_eval=$AIME_STAGED_EVAL" \
  "max_working_regression_ratio=$MAX_WORKING_REGRESSION_RATIO" \
  "restore_campaign_root=${RESTORE_CAMPAIGN_ROOT:-none}"
snapshot "before_startup"

"$START_SERVICE" \
  "$MODEL" "$SERVING_GPU" "$PORT" "$SERVICE_DIR" "$VLLM_PYTHON"
service_pid=$(tr -d '[:space:]' < "$SERVICE_DIR/vllm.pid")
record "service_ready" "service_pid=$service_pid" "port=$PORT"

if [[ "$TASK" == aime2024* ]]; then
  record "initial_harness_baseline_start" "served_model=$SERVED_MODEL_NAME"
  PYTHONPATH="$ROOT" "$CAMPAIGN_PYTHON" \
    "$ROOT/evolve_harness/scripts/run_aime_initial_baseline.py" \
    --base-url "http://127.0.0.1:$PORT/v1" \
    --model "$SERVED_MODEL_NAME" \
    --output "$RUN_ROOT/initial_harness_aime2024.json" \
    --seed "$SEED" \
    --max-tokens "$INNER_MAX_TOKENS" \
    --workers 8 \
    > "$RUN_ROOT/initial_harness_runner.log" 2>&1
  baseline_score=$("$CAMPAIGN_PYTHON" -c \
    'import json,sys; d=json.load(open(sys.argv[1])); s=d["score"]; print(str(s["correct"])+"/"+str(s["total"]))' \
    "$RUN_ROOT/initial_harness_aime2024.json")
  record "initial_harness_baseline_complete" "score=$baseline_score"
fi

# Service initialization can take more than a minute.  Revalidate the
# separately allocated training card after that window so a foreign process
# that raced the queue is never handed to the trainer.
if [ "$TRAINING_REQUIRED" -eq 1 ]; then
  training_occupants=$(gpu_all_compute_pids "$TRAINING_GPU")
  if [ -n "$training_occupants" ]; then
    record \
      "training_gpu_occupied_after_service_start" \
      "training_gpu=$TRAINING_GPU" \
      "occupants=${training_occupants//$'\n'/_}"
    echo \
      "training GPU $TRAINING_GPU became occupied during service startup" \
      >&2
    exit 4
  fi
fi

campaign_args=(
  --run-root "$RUN_ROOT"
  --tasks "$TASK"
  --include-unsplit
  --rounds "$ROUNDS"
  --proposals "$PROPOSALS"
  --rollout-repeats "$ROLLOUT_REPEATS"
  --feedback-repeats "$FEEDBACK_REPEATS"
  --method-arm "$METHOD_ARM"
  --plateau-rounds 3
  --objective-protocol "$OBJECTIVE_PROTOCOL"
  --promotion-top-k "$PROMOTION_TOP_K"
  --max-working-regression-ratio "$MAX_WORKING_REGRESSION_RATIO"
  --training-max-length "$TRAINING_MAX_LENGTH"
  --inner-max-tokens "$INNER_MAX_TOKENS"
  --proposer-max-tokens "$PROPOSER_MAX_TOKENS"
  --training-max-seconds "$TRAINING_MAX_SECONDS"
  --training-python "$TRAINING_PYTHON"
  --campaign-seed "$SEED"
  --base-url "http://127.0.0.1:$PORT/v1"
  --served-model "$SERVED_MODEL_NAME"
  --checkpoint "$MODEL"
  --max-parallel 1
)
if [ "$AIME_STAGED_EVAL" = "1" ]; then
  campaign_args+=(--aime-staged-eval)
fi
if [ "$TRAINING_REQUIRED" -eq 1 ]; then
  campaign_args+=(--training-gpu "$TRAINING_GPU")
fi
if [ -n "$RESTORE_CAMPAIGN_ROOT" ]; then
  campaign_args+=(
    --restore-campaign-root "$RESTORE_CAMPAIGN_ROOT"
    --restore-checkpoint latest
  )
fi

setsid env \
  PYTHONPATH="$ROOT/evogate/src:$ROOT" \
  "$CAMPAIGN_PYTHON" "$LAUNCHER" \
  "${campaign_args[@]}" \
  > "$MANAGER_LOG" 2>&1 &
campaign_pid=$!
record "campaign_started" "campaign_pid=$campaign_pid"

if [ "$TRAINING_REQUIRED" -eq 1 ]; then
  guard_training_gpu "$$" "$campaign_pid" \
    > "$RUN_ROOT/training_gpu_guard.log" 2>&1 &
  training_guard_pid=$!
  record \
    "training_gpu_guard_started" \
    "training_guard_pid=$training_guard_pid" \
    "training_gpu=$TRAINING_GPU" \
    "poll_seconds=30"
fi

"$CAMPAIGN_PYTHON" "$HEALTH_MONITOR" \
  --run-root "$RUN_ROOT" \
  --launcher-pid "$campaign_pid" \
  --vllm-pid "$service_pid" \
  --poll-seconds 600 \
  --heartbeat-seconds 600 \
  --stale-seconds 1800 \
  > "$RUN_ROOT/supervision_runner.log" 2>&1 &
health_monitor_pid=$!
record \
  "quality_supervisor_started" \
  "quality_supervisor_pid=$health_monitor_pid" \
  "poll_seconds=600" \
  "stale_seconds=1800"

"$CAMPAIGN_PYTHON" "$WATCHDOG" \
  --campaign-pid "$campaign_pid" \
  --service-supervisor-pid "$service_pid" \
  --gpu "$SERVING_GPU" \
  --lifecycle "$LIFECYCLE" \
  --snapshot-dir "$SNAPSHOT_DIR" \
  > "$RUN_ROOT/cleanup_watchdog.log" 2>&1 &
watchdog_pid=$!
record "cleanup_watchdog_started" "watchdog_pid=$watchdog_pid"

set +e
wait "$campaign_pid"
campaign_exit=$?
set -e
record "campaign_exit_observed" "campaign_pid=$campaign_pid" "exit_code=$campaign_exit"
set +e
cleanup "$campaign_exit" "campaign_exit_$campaign_exit"
final_exit=$?
set -e
  trap - EXIT INT TERM HUP
exit "$final_exit"
