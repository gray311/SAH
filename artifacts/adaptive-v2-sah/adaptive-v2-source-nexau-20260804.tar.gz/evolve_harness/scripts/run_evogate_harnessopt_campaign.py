#!/usr/bin/env python3
"""Launch resolved EvoGate HarnessOpt open-ended runs with bounded concurrency.

The launcher owns only the EvoGate process groups it creates. The Qwen vLLM
endpoint is treated as an externally managed service and is never started,
signalled, or stopped by this script.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

from evogate.artifacts import ArtifactError
from evogate.checkpoints import open_store
from evogate.ledger import EventLedger, LedgerError


ROOT = Path(__file__).resolve().parents[2]
EVOGATE_ROOT = ROOT / "evogate"
CONFIG_ROOT = ROOT / "evolve_harness" / "configs" / "evogate_harnessopt"
BENCHMARK_ROOT = ROOT / "evolve_harness" / "configs" / "benchmarks"
DEFAULT_TASKS = ("ahc039", "ahc058", "qubit-routing")
METHOD_ARMS = (
    "legacy",
    "stateless_frozen",
    "context_only",
    "sah_every_round",
    "policy_only",
    "adaptive",
)
SPLIT_CAPABLE_EVALUATORS = {
    "ahc_optimize_split",
    "aime_exact_match",
    "qubit_optimize_split",
}
SAFE_RESTORE_CHECKPOINT_KINDS = {"promoted", "retained", "final"}


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def append_event(path: Path, event: str, **fields: Any) -> None:
    payload = {"time": now(), "event": event, **fields}
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def task_catalog() -> dict[str, dict[str, Any]]:
    catalog: dict[str, dict[str, Any]] = {}
    for path in sorted(BENCHMARK_ROOT.glob("harness_only_*.jsonl")):
        first_line = path.read_text(encoding="utf-8").splitlines()[0]
        row = json.loads(first_line)
        metadata = dict(row.get("metadata", {}))
        task_id = str(metadata.get("official_task_id") or row.get("id") or "")
        if not task_id:
            raise ValueError(f"task manifest has no official ID: {path}")
        catalog[task_id] = {
            "path": path.resolve(),
            "evaluator_kind": str(metadata.get("evaluator_kind") or ""),
        }
    return catalog


def task_case_multiplier(task_path: Path) -> int:
    """Return the largest logical split size for budget upper bounds."""

    counts = {name: 0 for name in ("update", "outcome", "promotion", "final")}
    for line in task_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        metadata = dict(row.get("metadata") or {})
        requested = metadata.get("evogate_splits")
        splits = list(counts) if requested is None else list(requested)
        for split in splits:
            if split in counts:
                counts[split] += 1
    return max(1, *counts.values())


def resolve_safe_restore_source(
    *,
    campaign_root: Path,
    task_id: str,
    checkpoint_ref: str = "latest",
    expected_model: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Resolve an immutable champion checkpoint for an auditable branch.

    A campaign checkpoint binds one inner state and one optimizer state. Only
    promoted/retained/final checkpoints are safe here because restoring a
    working candidate would silently treat an unpromoted exploratory state as
    the new champion.
    """

    safe_name = task_id.replace("-", "_")
    source_run = (campaign_root / "runs" / safe_name).resolve()
    manifest_path = source_run / "manifest.json"
    ledger_path = source_run / "events.jsonl"
    if not manifest_path.is_file() or not ledger_path.is_file():
        raise ValueError(
            f"restore source for {task_id!r} is not an EvoGate run: "
            f"{source_run}"
        )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    source_task = dict(
        dict(manifest.get("experiment") or {}).get("metadata") or {}
    ).get("official_task_id")
    if source_task != task_id:
        raise ValueError(
            f"restore source task mismatch: expected {task_id!r}, "
            f"found {source_task!r}"
        )
    ledger = EventLedger(ledger_path)
    ledger_status = ledger.verify()
    rows = list(ledger)
    store = open_store(source_run)
    checkpoint = store.resolve_checkpoint(checkpoint_ref)
    if checkpoint.kind not in SAFE_RESTORE_CHECKPOINT_KINDS:
        raise ValueError(
            "campaign restore requires a promoted, retained, or final "
            f"champion checkpoint; {checkpoint_ref!r} resolved to "
            f"kind={checkpoint.kind!r}"
        )
    if checkpoint.optimizer_state_id is None:
        raise ValueError(
            f"restore checkpoint has no optimizer state: "
            f"{checkpoint.checkpoint_id}"
        )
    state = store.get_state(checkpoint.state_id)
    optimizer_state = store.get_optimizer_state(
        checkpoint.optimizer_state_id
    )
    for ref in state.components.values():
        store.get_bytes(ref)
    for ref in optimizer_state.components.values():
        store.get_bytes(ref)
    if checkpoint.parent_checkpoint_id is not None:
        store.get_checkpoint(checkpoint.parent_checkpoint_id)
    for split, ref in checkpoint.evaluations.items():
        summary = store.get_json(ref)
        if (
            not isinstance(summary, dict)
            or summary.get("schema")
            != "evogate.evaluation-summary/v1"
            or summary.get("state_id") != checkpoint.state_id
            or summary.get("split") != split
        ):
            raise ValueError(
                f"restore checkpoint has invalid {split!r} evaluation binding"
            )
    model_ref = state.components.get("model")
    if model_ref is None:
        raise ValueError("restore checkpoint state has no model component")
    model = store.get_json(model_ref)
    if not isinstance(model, dict):
        raise ValueError("restore checkpoint model component is not a mapping")
    source_model = {
        key: str(model.get(key) or "")
        for key in ("provider", "served_model", "checkpoint", "base_url")
    }
    if expected_model is not None:
        mismatches = {
            key: {
                "source": source_model.get(key),
                "requested": str(value),
            }
            for key, value in expected_model.items()
            if source_model.get(key) != str(value)
        }
        if mismatches:
            raise ValueError(
                "restore model deployment differs from the requested "
                f"deployment: {mismatches}; safe campaign restore does not "
                "silently rewrite checkpoint components"
            )
    checkpoint_events = [
        row
        for row in rows
        if row.get("event") == "checkpoint_created"
        and dict(row.get("payload") or {}).get("checkpoint_id")
        == checkpoint.checkpoint_id
    ]
    if len(checkpoint_events) != 1:
        raise ValueError(
            "restore checkpoint must have exactly one checkpoint_created "
            f"event; found {len(checkpoint_events)}"
        )
    checkpoint_seq = int(checkpoint_events[0]["seq"])
    source_round = checkpoint.metadata.get("round")
    round_finished_seq: int | None = None
    if checkpoint.kind in {"promoted", "retained"}:
        round_finished = [
            row
            for row in rows
            if row.get("event") == "round_finished"
            and dict(row.get("payload") or {}).get("round")
            == source_round
        ]
        if len(round_finished) != 1:
            raise ValueError(
                "restore checkpoint must belong to exactly one completed "
                f"round; found {len(round_finished)} round_finished events "
                f"for round {source_round!r}"
            )
        round_finished_seq = int(round_finished[0]["seq"])
        if round_finished_seq <= checkpoint_seq:
            raise ValueError(
                "round_finished must follow the restored champion checkpoint"
            )
    working_state_id = checkpoint.metadata.get("working_state_id")
    return {
        "source_campaign_root": str(campaign_root.resolve()),
        "source_run": str(source_run),
        "source_checkpoint_ref": checkpoint_ref,
        "source_checkpoint_id": checkpoint.checkpoint_id,
        "source_checkpoint_kind": checkpoint.kind,
        "source_checkpoint_label": checkpoint.label,
        "source_state_id": checkpoint.state_id,
        "source_optimizer_state_id": checkpoint.optimizer_state_id,
        "source_model": source_model,
        "source_round": source_round,
        "source_round_finished_seq": round_finished_seq,
        "source_ledger_head": ledger_status["head"],
        "source_ledger_events": ledger_status["events"],
        "source_events_after_checkpoint": len(rows) - checkpoint_seq - 1,
        "source_incomplete_tail_events": (
            len(rows) - round_finished_seq - 1
            if round_finished_seq is not None
            else 0
        ),
        "discarded_working_state_id": (
            working_state_id
            if isinstance(working_state_id, str)
            and working_state_id
            and working_state_id != checkpoint.state_id
            else None
        ),
        "restore_policy": (
            "safe_champion_branch; incomplete tail and unpromoted working "
            "state are not resumed"
        ),
    }


def _resolve_template_paths(config: dict[str, Any], source: Path) -> None:
    plugin = config["plugins"]["config"]
    base = source.parent.resolve()
    for field in ("project_root", "agent_config", "runs_dir"):
        raw = Path(str(plugin[field]))
        plugin[field] = str((raw if raw.is_absolute() else base / raw).resolve())
    executable = Path(str(plugin["python_executable"])).expanduser()
    if not executable.is_absolute():
        executable = base / executable
    plugin["python_executable"] = os.path.abspath(executable)
    for skill in plugin.get("skill_registry", {}).values():
        raw = Path(str(skill["path"]))
        skill["path"] = str((raw if raw.is_absolute() else base / raw).resolve())


def resolved_config(
    *,
    template_path: Path,
    task_id: str,
    task: dict[str, Any],
    run_root: Path,
    base_url: str,
    served_model: str,
    checkpoint: str,
    rounds: int,
    proposals: int,
    allow_unsplit: bool,
    rollout_repeats: int = 3,
    feedback_repeats: int = 3,
    feedback_cache_root: Path | None = None,
    method_arm: str = "legacy",
    training_gpu: str | None = None,
    training_python: str = sys.executable,
    training_max_seconds: int = 3600,
    training_max_length: int = 4096,
    inner_max_tokens: int = 4096,
    proposer_max_tokens: int = 2048,
    plateau_rounds: int = 3,
    campaign_seed: int = 23,
    objective_protocol: str = "v1",
    promotion_top_k: int = 2,
    max_working_regression_ratio: float = 0.10,
) -> dict[str, Any]:
    if method_arm not in METHOD_ARMS:
        raise ValueError(
            f"unknown method arm {method_arm!r}; expected {METHOD_ARMS}"
        )
    if objective_protocol not in {"v1", "v2"}:
        raise ValueError(
            "objective_protocol must be one of: v1, v2"
        )
    config = copy.deepcopy(json.loads(template_path.read_text(encoding="utf-8")))
    _resolve_template_paths(config, template_path)
    safe_name = task_id.replace("-", "_")
    split_capable = task["evaluator_kind"] in SPLIT_CAPABLE_EVALUATORS
    plugin = config["plugins"]["config"]
    plugin["task_files"] = {task_id: str(task["path"])}
    plugin["runs_dir"] = str((run_root / "inner-runs" / safe_name).resolve())
    if feedback_cache_root is not None:
        plugin["feedback_cache_dir"] = str(
            (feedback_cache_root / safe_name).resolve()
        )
    plugin["allow_unsplit"] = bool(allow_unsplit and not split_capable)
    plugin["feedback_repeats"] = feedback_repeats
    plugin["split_map"] = (
        {
            "update": "optimize",
            "outcome": "optimize",
            "promotion": "holdout",
            "final": "final",
        }
        if split_capable
        else {
            "update": "all",
            "outcome": "all",
            "promotion": "all",
            "final": "all",
        }
    )
    settings: dict[str, Any] = {"reward_scale": 1.0}
    config["evaluation"]["confidence_z"] = 0.0
    if task["evaluator_kind"] == "ahc_optimize_split":
        # The benchmark contract and the frozen V7 baseline both report the
        # original 150-case total. Never silently fall back to the pilot's
        # legacy 90/150-case mean scale.
        settings["metadata"] = {"score_aggregation": "total"}
        settings["split_overrides"] = {
            "update": {"repeats": 1},
            "outcome": {"repeats": 3},
            "promotion": {"repeats": 5},
            "final": {"repeats": 10},
        }
        config["evaluation"]["confidence_z"] = 3.0
    elif task["evaluator_kind"] == "qubit_optimize_split":
        settings["split_overrides"] = {
            "update": {
                "trial_mode": "fast",
                "equivalence_check": False,
                "slot_count": 1,
            },
            "outcome": {
                "trial_mode": "fast",
                "equivalence_check": False,
                "slot_count": 1,
            },
            "promotion": {
                "trial_mode": "full",
                "equivalence_check": True,
                "slot_count": 1,
            },
            "final": {
                "trial_mode": "full",
                "equivalence_check": True,
                "slot_count": 1,
            },
        }
    elif task["evaluator_kind"] == "aime_exact_match":
        from evolve_harness.aime import INITIAL_SYSTEM_PROMPT

        plugin["agent_config"] = str((CONFIG_ROOT / "aime_agent.yaml").resolve())
        plugin["skill_registry"] = {}
        plugin["feedback_repeats"] = 1
        settings["split_overrides"] = {
            name: {"repeats": 1}
            for name in ("update", "outcome", "promotion", "final")
        }
        config["evaluation"]["confidence_z"] = 0.0
        harness = config["initial_components"]["harness"]
        harness.update(
            {
                "system_prompt": INITIAL_SYSTEM_PROMPT,
                "max_context_tokens": 16384,
                "max_iterations": 2,
                "tool_call_mode": "structured",
                "skills": [],
            }
        )
        harness["llm"].update(
            {
                "temperature": 0.6,
                "top_p": 0.95,
                "stream": False,
                "enable_thinking": False,
            }
        )
        harness["context_compaction"].update(
            {"max_context_tokens": 16384, "auto_compact": False}
        )
        mutable_paths = [
            "/system_prompt",
            "/llm/temperature",
            "/llm/top_p",
        ]
        config["capabilities"]["harness"]["paths"] = mutable_paths
        config["capabilities"]["harness"]["value_bounds"] = {
            "/llm/temperature": {"min": 0.0, "max": 1.5},
            "/llm/top_p": {"min": 0.5, "max": 1.0},
        }
        config["capabilities"]["harness"]["value_constraints"] = {
            "/system_prompt": {
                "type": "string",
                "min_length": 80,
                "max_length": 12000,
            },
            "/llm/temperature": {"type": "number"},
            "/llm/top_p": {"type": "number"},
        }
        config["outer_visibility"]["harness"] = mutable_paths
        plugin["optimizer"].update(
            {
                "proposal_context_profile": "aime",
                "proposal_task_guidance": (
                    "Use labeled AIME-2022 calibration only to learn generic "
                    "solver-harness behavior. Never copy problem text, IDs, or "
                    "answers into a candidate. Keep native thinking disabled: at "
                    "the shared 8192-token ceiling it can consume the entire "
                    "completion without producing an answer. Cover distinct causal "
                    "mechanisms across the batch; formatting/range reminders are "
                    "low priority when answers are already parseable."
                ),
                "proposal_focuses": [
                    "low-variance sampling for exact-answer reliability",
                    "generic solve-plan decomposition",
                    "independent verification or alternate derivation",
                    "sampling temperature/top-p exploration",
                    "truncation and token-efficiency control",
                    "domain-agnostic arithmetic/algebra sanity checks",
                ],
                "seed_actions": [
                    {
                        "axis": "inference",
                        "hypothesis": (
                            "lower-temperature sampling reduces arithmetic and "
                            "algebraic slips on exact-answer mathematics"
                        ),
                        "expected_effect": (
                            "higher paired AIME exact-match accuracy without extra tokens"
                        ),
                        "evidence_ids": [],
                        "edit_atoms": [
                            {
                                "kind": "set",
                                "field": "/llm/temperature",
                                "value": 0.2,
                            }
                        ],
                        "preserve": ["exact final-answer extraction"],
                    },
                    {
                        "axis": "prompt",
                        "hypothesis": (
                            "explicit plan-solve-verify staging reduces premature "
                            "commitment on unfamiliar competition problems"
                        ),
                        "expected_effect": (
                            "more correct parseable answers without problem-specific memory"
                        ),
                        "evidence_ids": [],
                        "edit_atoms": [
                            {
                                "kind": "prompt_upsert_section",
                                "field": "solve_verify",
                                "value": (
                                    "Before calculating, identify the mathematical "
                                    "structure and write a short solution plan. Carry "
                                    "out the plan without guessing. Before finalizing, "
                                    "independently verify the decisive equation, count, "
                                    "or construction; if the checks disagree, revisit "
                                    "the earliest unsupported step."
                                ),
                            }
                        ],
                        "preserve": ["three-digit boxed final answer"],
                    },
                ],
            }
        )
        plugin["max_parallel_episodes"] = 8
    plugin["task_settings"] = {task_id: settings}
    plugin["optimizer"]["base_url"] = base_url
    plugin["optimizer"]["seed"] = campaign_seed
    plugin["optimizer"]["proposal_count"] = proposals
    plugin["optimizer"]["max_tokens"] = proposer_max_tokens
    plugin["optimizer"]["model_component"].update(
        {
            "served_model": served_model,
            "checkpoint": checkpoint,
            "base_url": base_url,
        }
    )
    config["initial_components"]["model"].update(
        {
            "served_model": served_model,
            "checkpoint": checkpoint,
            "base_url": base_url,
        }
    )
    policy_evolution: dict[str, Any] = {
        "enabled": method_arm != "legacy",
        "mode": (
            "stateless_frozen"
            if method_arm == "stateless_frozen"
            else "context_only"
            if method_arm == "context_only"
            else "policy_every_round"
            if method_arm in {"sah_every_round", "policy_only"}
            else "plateau_triggered"
            if method_arm == "adaptive"
            else "context_only"
        ),
        "expose_archive_to_policy": method_arm in {
            "context_only",
            "sah_every_round",
            "adaptive",
        },
        "freeze_harness": method_arm in {
            "stateless_frozen",
            "policy_only",
        },
        "plateau_rounds": plateau_rounds,
        "total_rounds": rounds,
        "confidence_z": (
            0.0
            if objective_protocol == "v2"
            else float(config["evaluation"].get("confidence_z", 0.0))
        ),
        "absolute_scale": 0.25,
        "record_scale": 0.05,
        "group_rank_weight": 0.20,
        "record_bonus_weight": 0.30,
        "process_tie_weight": 0.10,
        "near_tie_tolerance": 0.005,
        "replay_weight": 0.25,
        "require_signed_contrast": True,
        "adapter_name_prefix": (
            f"EvoGate-{method_arm}-{safe_name}"
        ),
    }
    training_enabled = method_arm in {
        "sah_every_round",
        "policy_only",
        "adaptive",
    }
    if training_enabled:
        if training_gpu is None or not str(training_gpu).isdigit():
            raise ValueError(
                f"method arm {method_arm!r} requires one explicit "
                "numeric training_gpu"
            )
        policy_evolution["training"] = {
            "python_executable": training_python,
            "base_model": checkpoint,
            "gpu_ids": [str(training_gpu)],
            "epochs": 1,
            "learning_rate": 1e-5,
            "rank": 32,
            "alpha": 64,
            "max_length": training_max_length,
            "max_seconds": training_max_seconds,
        }
    plugin["optimizer"]["policy_evolution"] = policy_evolution
    config["experiment_id"] = (
        f"harnessopt-{task_id}-{method_arm}-qwen35-seed{campaign_seed}"
    )
    config["rounds"] = rounds
    config["max_proposals_per_round"] = proposals
    config["evaluation"]["repeats"] = rollout_repeats
    config["evaluation"]["seed"] = campaign_seed
    harness = config["initial_components"]["harness"]
    harness["llm"]["max_tokens"] = inner_max_tokens
    if objective_protocol == "v2":
        config["evaluation"].update(
            {
                "outcome_statistic": "best",
                "promotion_statistic": "mean",
                "final_statistic": "best",
                "promotion_top_k": min(
                    promotion_top_k, proposals
                ),
                "advance_working_on_final_round": False,
            }
        )
        if task["evaluator_kind"] == "aime_exact_match":
            # AIME splits contain independent binary question scores, not
            # repeated samples of one continuous objective. Taking `best`
            # would reduce every candidate that solves at least one question
            # to 1.0 and would also misreport the 30-question final score.
            # Mean is the exact-match accuracy for the preregistered split.
            config["evaluation"].update(
                {
                    "outcome_statistic": "mean",
                    "promotion_statistic": "mean",
                    "final_statistic": "mean",
                }
            )
        plugin["optimizer"]["working_cost_gate"][
            "max_working_regression_ratio"
        ] = max_working_regression_ratio
        promoted_per_round = min(promotion_top_k, proposals)
    else:
        promoted_per_round = proposals
    single_repeat_episode_budget = (
        rounds * (proposals + promoted_per_round + 4) + 5
    )
    case_multiplier = task_case_multiplier(Path(str(task["path"])))
    episode_budget = (
        rollout_repeats * single_repeat_episode_budget * case_multiplier
    )
    max_iterations = int(harness["max_iterations"])
    max_context_tokens = int(harness["max_context_tokens"])
    inner_token_ceiling = episode_budget * max_iterations * max_context_tokens
    proposer_prompt_ceiling = int(
        plugin["optimizer"].get("max_prompt_chars", 48000)
    )
    proposer_output_ceiling = int(plugin["optimizer"].get("max_tokens", 2048))
    proposal_attempt_multiplier = int(
        plugin["optimizer"].get("proposal_attempt_multiplier", 1)
    )
    if proposal_attempt_multiplier < 1:
        raise ValueError(
            "optimizer.proposal_attempt_multiplier must be positive"
        )
    outer_token_ceiling = (
        rounds
        * proposals
        * proposal_attempt_multiplier
        * (proposer_prompt_ceiling + proposer_output_ceiling)
    )
    inner_budget = config["budgets"]["inner"]
    outer_budget = config["budgets"]["outer"]
    training_budget = config["budgets"]["training"]
    inner_budget["episodes"] = episode_budget
    inner_budget["tokens"] = max(
        int(inner_budget.get("tokens") or 0),
        inner_token_ceiling,
    )
    outer_budget["tokens"] = max(
        int(outer_budget.get("tokens") or 0),
        outer_token_ceiling,
    )
    max_policy_updates = (
        max(0, rounds - 1)
        if method_arm in {"sah_every_round", "policy_only"}
        else max(0, rounds - 1) // plateau_rounds
        if method_arm == "adaptive"
        else 0
    )
    training_budget["training_seconds"] = (
        max_policy_updates * training_max_seconds
    )
    training_budget["gpu_seconds"] = (
        max_policy_updates * training_max_seconds
    )
    training_budget["wall_seconds"] = (
        max_policy_updates * (training_max_seconds + 180)
    )
    config["metadata"].update(
        {
            "official_task_id": task_id,
            "evaluator_kind": task["evaluator_kind"],
            "split_generalization": split_capable,
            "resolved_by": "run_evogate_harnessopt_campaign.py",
            "method_arm": method_arm,
            "outer_parameter_learning": training_enabled,
            "campaign_seed": campaign_seed,
            "objective_protocol": objective_protocol,
            "objective_definition": (
                "best_valid_within_matched_rollout_budget"
                if objective_protocol == "v2"
                else "mean_reward"
            ),
            "training_max_length": training_max_length,
            "inner_max_tokens": inner_max_tokens,
            "proposer_max_tokens": proposer_max_tokens,
            "policy_update_rule": (
                "after_3_context_rounds_without_confirmed_public_record"
                if method_arm == "adaptive"
                else "every_round_with_signed_contrast"
                if method_arm in {"sah_every_round", "policy_only"}
                else "disabled"
            ),
            "budget_derivation": {
                "episode_ceiling": episode_budget,
                "task_case_multiplier": case_multiplier,
                "rollout_repeats": rollout_repeats,
                "promotion_top_k": (
                    min(promotion_top_k, proposals)
                    if objective_protocol == "v2"
                    else proposals
                ),
                "feedback_repeats": feedback_repeats,
                "proposal_attempt_multiplier": (
                    proposal_attempt_multiplier
                ),
                "inner_token_ceiling": inner_budget["tokens"],
                "inner_token_formula": (
                    "episodes * harness.max_iterations * "
                    "harness.max_context_tokens"
                ),
                "outer_token_ceiling": outer_budget["tokens"],
                "outer_token_formula": (
                    "rounds * proposals * proposal_attempt_multiplier * "
                    "(max_prompt_chars + proposer_max_tokens)"
                ),
                "max_policy_updates": max_policy_updates,
                "training_seconds": training_budget[
                    "training_seconds"
                ],
                "gpu_seconds": training_budget["gpu_seconds"],
            },
        }
    )
    return config


def probe_vllm(base_url: str, expected_model: str, timeout: float = 10.0) -> dict[str, Any]:
    url = base_url.rstrip("/") + "/models"
    with urllib.request.urlopen(url, timeout=timeout) as response:
        payload = json.load(response)
    model_ids = [
        str(item.get("id"))
        for item in payload.get("data", [])
        if isinstance(item, dict) and item.get("id")
    ]
    if expected_model not in model_ids:
        raise RuntimeError(
            f"vLLM endpoint does not serve {expected_model!r}; available={model_ids}"
        )
    return {"url": url, "models": model_ids}


def terminate_group(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=20)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--tasks", nargs="+", default=list(DEFAULT_TASKS))
    parser.add_argument("--max-parallel", type=int, default=1, choices=range(1, 9))
    parser.add_argument("--rounds", type=int, default=10)
    parser.add_argument("--proposals", type=int, default=3)
    parser.add_argument(
        "--rollout-repeats",
        type=int,
        default=3,
        help="Complete paired inner-agent trajectories per logical split.",
    )
    parser.add_argument(
        "--feedback-repeats",
        type=int,
        default=3,
        help="Verifier repetitions behind each optimize-time tool check.",
    )
    parser.add_argument(
        "--feedback-cache-root",
        type=Path,
        help=(
            "Optional campaign-independent cache root. Each task uses a "
            "separate child directory; seed a new root to reuse exact "
            "candidate feedback without mutating an old run."
        ),
    )
    parser.add_argument(
        "--restore-campaign-root",
        type=Path,
        help=(
            "Start each task as a new auditable branch from the matching task "
            "run in an earlier campaign. Only promoted, retained, or final "
            "champion checkpoints are accepted."
        ),
    )
    parser.add_argument(
        "--restore-checkpoint",
        default="latest",
        help=(
            "Checkpoint ID or named ref in each source task run "
            "(default: latest). When restoring, --rounds is the number of "
            "additional branch rounds."
        ),
    )
    parser.add_argument(
        "--template",
        type=Path,
        default=CONFIG_ROOT / "ahc039.json",
    )
    parser.add_argument("--base-url", default="http://127.0.0.1:18101/v1")
    parser.add_argument("--served-model", default="Qwen3.5-9B")
    parser.add_argument("--checkpoint", default="Qwen/Qwen3.5-9B")
    parser.add_argument(
        "--method-arm",
        choices=METHOD_ARMS,
        default="legacy",
        help=(
            "Unified EvoGate comparison arm. sah_every_round evolves the "
            "harness/context while training every round; policy_only is the "
            "strict frozen-harness causal ablation; adaptive trains only "
            "after the configured context plateau."
        ),
    )
    parser.add_argument(
        "--training-gpu",
        help=(
            "Dedicated free GPU for proposer-only LoRA training; required by "
            "sah_every_round, policy_only, and adaptive, and must not host "
            "vLLM."
        ),
    )
    parser.add_argument(
        "--training-python",
        default=sys.executable,
    )
    parser.add_argument(
        "--training-max-seconds", type=int, default=3600
    )
    parser.add_argument(
        "--training-max-length",
        type=int,
        default=4096,
        help="Maximum proposer-training sequence length.",
    )
    parser.add_argument(
        "--inner-max-tokens",
        type=int,
        default=4096,
        help="Maximum generated tokens per inner-agent model turn.",
    )
    parser.add_argument(
        "--proposer-max-tokens",
        type=int,
        default=2048,
        help="Maximum generated tokens per outer proposer response.",
    )
    parser.add_argument("--plateau-rounds", type=int, default=3)
    parser.add_argument(
        "--objective-protocol",
        choices=("v1", "v2"),
        default="v1",
        help=(
            "v2 optimizes best valid score within a matched rollout budget, "
            "uses bounded working-state exploration, and promotes only top-k."
        ),
    )
    parser.add_argument(
        "--promotion-top-k",
        type=int,
        default=2,
        help="Candidates per round receiving the expensive promotion split.",
    )
    parser.add_argument(
        "--max-working-regression-ratio",
        type=float,
        default=0.10,
        help=(
            "Largest relative outcome regression allowed for exploratory "
            "working-state advancement under objective protocol v2."
        ),
    )
    parser.add_argument(
        "--campaign-seed",
        type=int,
        default=23,
        help="Shared proposer/evaluator seed for a reproducible campaign arm.",
    )
    parser.add_argument(
        "--include-unsplit",
        action="store_true",
        help="Permit fixed-instance tasks without a true holdout/final split.",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Resolve and validate configs without contacting Qwen or launching runs.",
    )
    parser.add_argument(
        "--skip-vllm-check",
        action="store_true",
        help="Skip the read-only /models preflight before launching.",
    )
    parser.add_argument(
        "--aime-staged-eval",
        action="store_true",
        help=(
            "After aime-harness-search completes, select once on AIME 2023 "
            "and run the sealed paired AIME 2025 final before exiting."
        ),
    )
    parser.add_argument("--aime-eval-workers", type=int, default=8)
    args = parser.parse_args()
    if (
        args.rounds < 1
        or args.proposals < 1
        or args.rollout_repeats < 1
        or args.feedback_repeats < 1
        or args.training_max_seconds < 180
        or args.training_max_length < 256
        or args.inner_max_tokens < 256
        or args.proposer_max_tokens < 256
        or args.promotion_top_k < 1
        or not 0.0 <= args.max_working_regression_ratio <= 1.0
        or args.plateau_rounds < 1
        or args.aime_eval_workers < 1
    ):
        parser.error(
            "--rounds, --proposals, --rollout-repeats, and "
            "--feedback-repeats must be positive; token/training/frontier "
            "limits are invalid"
        )
    if (
        args.method_arm in {"policy_only", "adaptive"}
        and (
            args.training_gpu is None
            or not str(args.training_gpu).isdigit()
        )
    ):
        parser.error(
            "--training-gpu is required for policy_only/adaptive and must "
            "be one explicit numeric GPU index"
        )
    if (
        args.restore_campaign_root is None
        and args.restore_checkpoint != "latest"
    ):
        parser.error(
            "--restore-checkpoint requires --restore-campaign-root"
        )

    catalog = task_catalog()
    requested = list(catalog) if args.tasks == ["all"] else list(dict.fromkeys(args.tasks))
    missing = sorted(set(requested) - set(catalog))
    if missing:
        parser.error(f"unknown open-ended tasks: {missing}; available={sorted(catalog)}")
    unsplit = [
        task_id
        for task_id in requested
        if catalog[task_id]["evaluator_kind"] not in SPLIT_CAPABLE_EVALUATORS
    ]
    if unsplit and not args.include_unsplit:
        parser.error(
            "tasks lack independent optimize/holdout/final splits: "
            f"{unsplit}; pass --include-unsplit for an explicit fixed-instance study"
        )

    run_root = args.run_root.resolve()
    restore_campaign_root = (
        args.restore_campaign_root.resolve()
        if args.restore_campaign_root is not None
        else None
    )
    if (
        restore_campaign_root is not None
        and (
            run_root == restore_campaign_root
            or run_root.is_relative_to(restore_campaign_root)
        )
    ):
        parser.error(
            "--run-root must be a fresh path outside the source campaign"
        )
    feedback_cache_root = (
        args.feedback_cache_root.resolve()
        if args.feedback_cache_root is not None
        else None
    )
    run_root.mkdir(parents=True, exist_ok=True)
    (run_root / "campaign.pid").write_text(
        f"{os.getpid()}\n", encoding="utf-8"
    )
    config_dir = run_root / "resolved-configs"
    log_dir = run_root / "logs"
    config_dir.mkdir(exist_ok=True)
    log_dir.mkdir(exist_ok=True)
    events = run_root / "campaign_lifecycle.jsonl"
    append_event(
        events,
        "campaign_prepare",
        tasks=requested,
        rounds=args.rounds,
        proposals=args.proposals,
        rollout_repeats=args.rollout_repeats,
        feedback_repeats=args.feedback_repeats,
        max_parallel=args.max_parallel,
        feedback_cache_root=(
            str(feedback_cache_root)
            if feedback_cache_root is not None
            else None
        ),
        restore_campaign_root=(
            str(restore_campaign_root)
            if restore_campaign_root is not None
            else None
        ),
        restore_checkpoint=(
            args.restore_checkpoint
            if restore_campaign_root is not None
            else None
        ),
        launcher_pid=os.getpid(),
        vllm_lifecycle_owned=False,
        method_arm=args.method_arm,
        training_enabled=args.method_arm in {"policy_only", "adaptive"},
        training_gpu=args.training_gpu,
        training_max_length=args.training_max_length,
        inner_max_tokens=args.inner_max_tokens,
        proposer_max_tokens=args.proposer_max_tokens,
        plateau_rounds=args.plateau_rounds,
        objective_protocol=args.objective_protocol,
        promotion_top_k=args.promotion_top_k,
        max_working_regression_ratio=(
            args.max_working_regression_ratio
        ),
        campaign_seed=args.campaign_seed,
    )

    restore_sources: dict[str, dict[str, Any]] = {}
    if restore_campaign_root is not None:
        for task_id in requested:
            try:
                source = resolve_safe_restore_source(
                    campaign_root=restore_campaign_root,
                    task_id=task_id,
                    checkpoint_ref=args.restore_checkpoint,
                    expected_model={
                        "provider": "vllm",
                        "served_model": args.served_model,
                        "checkpoint": args.checkpoint,
                        "base_url": args.base_url,
                    },
                )
            except (ArtifactError, LedgerError, OSError, ValueError) as exc:
                error = f"{type(exc).__name__}: {exc}"
                append_event(
                    events,
                    "restore_validation_failed",
                    task=task_id,
                    error=error,
                )
                (run_root / "campaign_summary.json").write_text(
                    json.dumps(
                        {
                            "schema": "evogate.harnessopt-campaign/v1",
                            "status": "failed_restore_validation",
                            "method_arm": args.method_arm,
                            "objective_protocol": args.objective_protocol,
                            "budget": {
                                "rounds": args.rounds,
                                "proposals_per_round": args.proposals,
                                "rollout_repeats": args.rollout_repeats,
                                "feedback_repeats": args.feedback_repeats,
                            },
                            "tasks": {
                                task_id: {
                                    "status": "failed_restore_validation",
                                    "error": error,
                                }
                            },
                            "external_vllm": {
                                "managed_by_campaign": False,
                                "cleanup_required": False,
                                "cleanup_status": "not_contacted",
                            },
                        },
                        indent=2,
                        ensure_ascii=False,
                    )
                    + "\n",
                    encoding="utf-8",
                )
                append_event(
                    events,
                    "campaign_exit",
                    status="failed_restore_validation",
                    vllm_cleanup_status="not_contacted",
                )
                return 1
            restore_sources[task_id] = source
            append_event(events, "restore_validated", task=task_id, **source)

    child_env = os.environ.copy()
    python_paths = [str(EVOGATE_ROOT / "src"), str(ROOT)]
    if child_env.get("PYTHONPATH"):
        python_paths.append(child_env["PYTHONPATH"])
    child_env["PYTHONPATH"] = os.pathsep.join(python_paths)
    resolved: dict[str, Path] = {}
    for task_id in requested:
        config = resolved_config(
            template_path=args.template.resolve(),
            task_id=task_id,
            task=catalog[task_id],
            run_root=run_root,
            base_url=args.base_url,
            served_model=args.served_model,
            checkpoint=args.checkpoint,
            rounds=args.rounds,
            proposals=args.proposals,
            allow_unsplit=args.include_unsplit,
            rollout_repeats=args.rollout_repeats,
            feedback_repeats=args.feedback_repeats,
            feedback_cache_root=feedback_cache_root,
            method_arm=args.method_arm,
            training_gpu=args.training_gpu,
            training_python=args.training_python,
            training_max_seconds=args.training_max_seconds,
            training_max_length=args.training_max_length,
            inner_max_tokens=args.inner_max_tokens,
            proposer_max_tokens=args.proposer_max_tokens,
            plateau_rounds=args.plateau_rounds,
            campaign_seed=args.campaign_seed,
            objective_protocol=args.objective_protocol,
            promotion_top_k=args.promotion_top_k,
            max_working_regression_ratio=(
                args.max_working_regression_ratio
            ),
        )
        if task_id in restore_sources:
            config["metadata"]["restore_lineage"] = dict(
                restore_sources[task_id]
            )
            config["metadata"]["budget_derivation"][
                "round_semantics"
            ] = "additional_branch_rounds"
        destination = config_dir / f"{task_id.replace('-', '_')}.json"
        destination.write_text(
            json.dumps(config, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        completed = subprocess.run(
            [sys.executable, "-m", "evogate.cli", "validate", str(destination)],
            cwd=ROOT,
            env=child_env,
            capture_output=True,
            text=True,
            check=False,
        )
        (log_dir / f"{task_id.replace('-', '_')}.validate.log").write_text(
            completed.stdout + completed.stderr,
            encoding="utf-8",
        )
        if completed.returncode:
            append_event(
                events,
                "config_validation_failed",
                task=task_id,
                exit_code=completed.returncode,
            )
            return 1
        resolved[task_id] = destination
        append_event(events, "config_validated", task=task_id, config=str(destination))

    if args.validate_only:
        append_event(
            events,
            "campaign_exit",
            status="validated",
            vllm_cleanup_status="not_contacted",
        )
        print(
            json.dumps(
                {
                    "status": "validated",
                    "method_arm": args.method_arm,
                    "objective_protocol": args.objective_protocol,
                    "tasks": requested,
                    "configs": {key: str(value) for key, value in resolved.items()},
                    "restore_sources": restore_sources,
                },
                indent=2,
            )
        )
        return 0

    if not args.skip_vllm_check:
        service = probe_vllm(args.base_url, args.served_model)
        append_event(
            events,
            "vllm_attached",
            **service,
            ownership="external_user_managed",
        )

    stopping = False

    def request_stop(signum: int, _frame: Any) -> None:
        nonlocal stopping
        stopping = True
        append_event(events, "campaign_stop_requested", signal=signum)

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    pending = requested.copy()
    active: dict[str, tuple[subprocess.Popen[str], Any]] = {}
    results: dict[str, dict[str, Any]] = {}
    append_event(events, "campaign_start", tasks=requested)
    try:
        while pending or active:
            while pending and len(active) < args.max_parallel and not stopping:
                task_id = pending.pop(0)
                safe_name = task_id.replace("-", "_")
                run_dir = run_root / "runs" / safe_name
                if run_dir.exists() and any(run_dir.iterdir()):
                    summary = run_dir / "summary.json"
                    status = "skipped_completed" if summary.is_file() else "blocked_nonempty"
                    results[task_id] = {"status": status, "run_dir": str(run_dir)}
                    append_event(events, "task_skipped", task=task_id, status=status)
                    continue
                log_handle = (log_dir / f"{safe_name}.run.log").open(
                    "a", encoding="utf-8"
                )
                command = [
                    sys.executable,
                    "-m",
                    "evogate.cli",
                    "run",
                    str(resolved[task_id]),
                    "--run-dir",
                    str(run_dir),
                ]
                restore_source = restore_sources.get(task_id)
                if restore_source is not None:
                    command.extend(
                        [
                            "--restore-run",
                            str(restore_source["source_run"]),
                            "--restore-checkpoint",
                            str(restore_source["source_checkpoint_id"]),
                        ]
                    )
                process = subprocess.Popen(
                    command,
                    cwd=ROOT,
                    env=child_env,
                    stdout=log_handle,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    text=True,
                )
                active[task_id] = (process, log_handle)
                append_event(
                    events,
                    "task_start",
                    task=task_id,
                    pid=process.pid,
                    command=command,
                    restore=restore_source,
                )

            if stopping:
                for task_id, (process, log_handle) in list(active.items()):
                    terminate_group(process)
                    log_handle.close()
                    results[task_id] = {
                        "status": "interrupted",
                        "exit_code": process.poll(),
                    }
                    append_event(events, "task_interrupted", task=task_id)
                active.clear()
                break

            finished: list[str] = []
            for task_id, (process, log_handle) in active.items():
                exit_code = process.poll()
                if exit_code is None:
                    continue
                log_handle.close()
                run_dir = run_root / "runs" / task_id.replace("-", "_")
                status = (
                    "completed"
                    if exit_code == 0 and (run_dir / "summary.json").is_file()
                    else "failed"
                )
                results[task_id] = {
                    "status": status,
                    "exit_code": exit_code,
                    "run_dir": str(run_dir),
                }
                append_event(
                    events,
                    "task_exit",
                    task=task_id,
                    status=status,
                    exit_code=exit_code,
                )
                finished.append(task_id)
            for task_id in finished:
                del active[task_id]
            if active and not finished:
                time.sleep(5)
    finally:
        for process, log_handle in active.values():
            terminate_group(process)
            log_handle.close()

    status = (
        "interrupted"
        if stopping
        else (
            "completed"
            if all(
                row["status"] in {"completed", "skipped_completed"}
                for row in results.values()
            )
            and len(results) == len(requested)
            else "failed"
        )
    )
    staged_evaluation: dict[str, Any] | None = None
    if (
        status == "completed"
        and args.aime_staged_eval
        and requested == ["aime-harness-search"]
    ):
        staged_dir = run_root / "aime_staged"
        staged_output = staged_dir / "aime_2023_selection.json"
        staged_log = log_dir / "aime_staged_selection.log"
        command = [
            sys.executable,
            str(
                ROOT
                / "evolve_harness/scripts/run_aime_staged_evaluation.py"
            ),
            "--run-dir",
            str(run_root / "runs/aime_harness_search"),
            "--base-url",
            args.base_url,
            "--model",
            args.served_model,
            "--output-dir",
            str(staged_dir),
            "--workers",
            str(args.aime_eval_workers),
        ]
        append_event(
            events,
            "aime_staged_evaluation_start",
            command=command,
        )
        completed = subprocess.run(
            command,
            cwd=ROOT,
            env=child_env,
            capture_output=True,
            text=True,
            check=False,
        )
        staged_log.write_text(
            completed.stdout + completed.stderr, encoding="utf-8"
        )
        selection_status = (
            "passed" if completed.returncode == 0
            else "no_candidate_passed" if completed.returncode == 3
            else "failed"
        )
        staged_evaluation = {
            "status": selection_status,
            "selection_exit_code": completed.returncode,
            "selection_output": str(staged_output),
            "selection_log": str(staged_log),
            "final_opened": False,
        }
        append_event(
            events,
            "aime_staged_evaluation_exit",
            **staged_evaluation,
        )
        if completed.returncode == 0:
            final_output = staged_dir / "aime_2025_sealed_final.json"
            final_log = log_dir / "aime_sealed_final.log"
            final_command = [
                sys.executable,
                str(
                    ROOT
                    / "evolve_harness/scripts/run_aime_sealed_final.py"
                ),
                "--winner-lock",
                str(staged_dir / "aime_winner_lock.json"),
                "--winner-lock-sha",
                str(staged_dir / "aime_winner_lock.sha256"),
                "--base-url",
                args.base_url,
                "--model",
                args.served_model,
                "--output",
                str(final_output),
                "--workers",
                str(args.aime_eval_workers),
            ]
            append_event(
                events,
                "aime_sealed_final_start",
                command=final_command,
            )
            final_completed = subprocess.run(
                final_command,
                cwd=ROOT,
                env=child_env,
                capture_output=True,
                text=True,
                check=False,
            )
            final_log.write_text(
                final_completed.stdout + final_completed.stderr,
                encoding="utf-8",
            )
            staged_evaluation.update(
                {
                    "status": (
                        "completed"
                        if final_completed.returncode == 0
                        else "failed_final"
                    ),
                    "final_opened": True,
                    "final_exit_code": final_completed.returncode,
                    "final_output": str(final_output),
                    "final_log": str(final_log),
                }
            )
            append_event(
                events,
                "aime_sealed_final_exit",
                exit_code=final_completed.returncode,
                output=str(final_output),
            )
            if final_completed.returncode != 0:
                status = "failed"
        elif completed.returncode != 3:
            status = "failed"
    elif args.aime_staged_eval:
        staged_evaluation = {
            "status": "not_run",
            "reason": (
                "requires one completed aime-harness-search task"
            ),
        }

    summary = {
        "schema": "evogate.harnessopt-campaign/v1",
        "status": status,
        "method_arm": args.method_arm,
        "objective_protocol": args.objective_protocol,
        "budget": {
            "rounds": args.rounds,
            "proposals_per_round": args.proposals,
            "rollout_repeats": args.rollout_repeats,
            "feedback_repeats": args.feedback_repeats,
        },
        "tasks": results,
        "external_vllm": {
            "base_url": args.base_url,
            "served_model": args.served_model,
            "managed_by_campaign": False,
            "cleanup_required": False,
            "cleanup_status": "external_service_not_owned_left_running",
        },
        "restore_sources": restore_sources,
        "aime_staged_evaluation": staged_evaluation,
    }
    (run_root / "campaign_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    append_event(
        events,
        "campaign_exit",
        status=status,
        vllm_cleanup_status="external_service_not_owned_left_running",
    )
    return 0 if status == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
