#!/usr/bin/env python3
"""One-call Qwen proposer smoke without launching an inner benchmark rollout."""
from __future__ import annotations

import argparse
import atexit
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from evogate.artifacts import ArtifactStore
from evogate.budget import BudgetMeter
from evogate.canonical import jsonable
from evogate.config import load_experiment, load_plugins
from evogate.policy import CapabilityPolicy, apply_patch, read_pointer
from evogate.types import AgentState, OuterContext


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _append_event(path: Path, event: str, **fields: Any) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(
            json.dumps(
                {"time": _now(), "event": event, **fields},
                ensure_ascii=False,
            )
            + "\n"
        )
        handle.flush()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=1024,
        help="Bound proposer output tokens for this smoke only.",
    )
    args = parser.parse_args()
    if args.count < 1:
        raise ValueError("--count must be positive")
    if args.max_tokens < 128:
        raise ValueError("--max-tokens must be at least 128")
    run_dir = args.run_dir.resolve()
    run_dir.mkdir(parents=True, exist_ok=False)
    lifecycle_path = run_dir / "experiment_lifecycle.jsonl"
    exit_state = {
        "status": "failed",
        "exit_reason": "process_exited_before_success",
    }
    _append_event(
        lifecycle_path,
        "smoke_start",
        purpose="one bounded HarnessOpt proposer request",
        config=str(args.config.resolve()),
        external_vllm_url="configured_in_experiment",
        vllm_lifecycle_owned=False,
        gpu_process_launched=False,
    )

    def record_exit() -> None:
        _append_event(
            lifecycle_path,
            "smoke_exit",
            **exit_state,
            vllm_shutdown="not_requested_external_service",
            gpu_cleanup_status=(
                "no GPU process launched; authorized external vLLM left running"
            ),
        )

    atexit.register(record_exit)

    loaded = load_experiment(args.config)
    plugins = load_plugins(loaded)
    optimizer = plugins.optimizer
    if optimizer is None or not hasattr(optimizer, "proposal_count"):
        raise TypeError("configured plugin is not HarnessOptOptimizer")
    optimizer.proposal_count = args.count
    if hasattr(optimizer.policy, "max_tokens"):
        optimizer.policy.max_tokens = args.max_tokens
    store = ArtifactStore(run_dir / "artifacts")
    components = {
        name: store.put_json(value, kind=name)
        for name, value in loaded.initial_components.items()
    }
    state = AgentState(
        components=components,
        metadata={"smoke": True, "experiment_id": loaded.spec.experiment_id},
    )
    store.put_state(state)
    visible = {
        component: {
            pointer: read_pointer(loaded.initial_components[component], pointer)
            for pointer in pointers
        }
        for component, pointers in loaded.spec.outer_visibility.items()
    }
    task = plugins.tasks.cases(loaded.spec.evaluation.update_split)[0]
    context = OuterContext(
        experiment_id=loaded.spec.experiment_id,
        round_index=0,
        state=state,
        component_views=visible,
        train_summary={
            "split": loaded.spec.evaluation.update_split,
            "score": 0.0,
            "records": 1,
            "smoke": True,
        },
        history=(),
        capability_contract=CapabilityPolicy.from_dict(
            loaded.spec.capabilities
        ).public_contract(),
        evidence=(
            {
                "evidence_id": "smoke.synthetic.failure",
                "task_id": task.task_id,
                "reward": 0.0,
                "metrics": {
                    "score": 0.0,
                    "valid": 1.0,
                    "feedback_check_count": 4,
                },
                "feedback": {
                    "failure_pattern": (
                        "the agent repeated low-information edits after a "
                        "valid candidate was already saved"
                    )
                },
                "output": "",
                "trace": [],
            },
        ),
    )
    outer_meter = BudgetMeter("outer", loaded.spec.budgets["outer"])
    optimizer_state = optimizer.initialize(store=store, budget=outer_meter)
    batch = optimizer.propose(
        context=context,
        state=optimizer_state,
        store=store,
        budget=outer_meter,
    )
    policy = CapabilityPolicy.from_dict(loaded.spec.capabilities)
    validated = []
    for proposal in batch.proposals:
        policy.validate(proposal)
        values = {
            name: json.loads(json.dumps(value))
            for name, value in loaded.initial_components.items()
        }
        for mutation in proposal.mutations:
            values[mutation.surface] = apply_patch(
                values[mutation.surface], mutation.operations
            )
        candidate = AgentState(
            components={
                name: store.put_json(value, kind=name)
                for name, value in values.items()
            },
            parent_id=state.state_id,
            metadata={"proposal_id": proposal.proposal_id, "smoke": True},
        )
        if plugins.candidate_validator is not None:
            plugins.candidate_validator.validate(
                baseline=state,
                candidate=candidate,
                proposal=proposal,
                components=values,
            )
        validated.append(proposal.proposal_id)
    result = {
        "schema": "harnessopt-qwen-smoke/v1",
        "status": "passed" if validated else "failed_no_valid_proposal",
        "external_vllm": {
            "managed_by_smoke": False,
            "cleanup_required": False,
        },
        "optimizer_state_id": optimizer_state.state_id,
        "proposals": [jsonable(item) for item in batch.proposals],
        "actions": jsonable(batch.actions),
        "validated_proposal_ids": validated,
        "metadata": jsonable(batch.metadata),
        "usage": jsonable(outer_meter.usage),
    }
    (run_dir / "result.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    exit_state.update(
        status=result["status"],
        exit_reason=(
            "proposal generated, compiled, capability-checked, and "
            "candidate-validated"
            if validated
            else "model produced no valid proposal"
        ),
    )
    return 0 if validated else 2


if __name__ == "__main__":
    raise SystemExit(main())
