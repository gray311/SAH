#!/usr/bin/env python3
"""Materialize one EvoGate harness overlay in NexAU without calling a model."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from evogate.config import load_experiment, load_plugins
from evogate.integrations.workers.nexau_worker import _apply_overlay


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument(
        "--skill",
        help="Registered skill ID to materialize; defaults to the first registry entry.",
    )
    args = parser.parse_args()

    loaded = load_experiment(args.config)
    plugins = load_plugins(loaded)
    runtime = plugins.inner
    if not hasattr(runtime, "agent_config") or not hasattr(runtime, "skill_registry"):
        raise TypeError("configured inner runtime is not NexAU")
    registry = dict(runtime.skill_registry)
    skill_id = args.skill or next(iter(registry), None)
    if skill_id is None:
        raise ValueError("configured NexAU runtime has no registered skills")
    if skill_id not in registry:
        raise ValueError(f"unknown registered skill: {skill_id}")

    from nexau import AgentConfig
    from nexau.archs.main_sub.execution.middleware.context_compaction import (
        ContextCompactionMiddleware,
    )

    agent_config = AgentConfig.from_yaml(Path(runtime.agent_config))
    harness = json.loads(json.dumps(loaded.initial_components["harness"]))
    harness["skills"] = [skill_id]
    _apply_overlay(
        agent_config,
        dict(loaded.initial_components["model"]),
        harness,
        registry,
    )
    compaction = [
        item
        for item in (agent_config.middlewares or [])
        if isinstance(item, ContextCompactionMiddleware)
    ]
    if len(agent_config.skills or []) != 1:
        raise RuntimeError("NexAU did not materialize exactly one registered skill")
    if len(compaction) != 1:
        raise RuntimeError("NexAU did not materialize exactly one compaction middleware")
    if agent_config.max_context_tokens != harness["max_context_tokens"]:
        raise RuntimeError("NexAU agent context limit does not match the harness")
    if compaction[0].max_context_tokens != harness["max_context_tokens"]:
        raise RuntimeError("NexAU compaction context limit does not match the harness")

    result = {
        "schema": "evogate.nexau-overlay-smoke/v1",
        "status": "passed",
        "agent_config": str(runtime.agent_config),
        "skill_id": skill_id,
        "skill_type": type(agent_config.skills[0]).__name__,
        "compaction_type": type(compaction[0]).__name__,
        "max_context_tokens": agent_config.max_context_tokens,
        "compaction_strategy": str(compaction[0].compaction_strategy),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
