#!/usr/bin/env python3
"""Summarize final and search-split scores from Adaptive EvoGate run roots."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Iterable


EXPERIMENT_RE = re.compile(
    r"^harnessopt-(.+?)-(?:adaptive|sah_every_round|policy_only|"
    r"context_only|stateless_frozen)-qwen35-seed(\d+)$"
)
PROTOCOL_PATH_RE = re.compile(r"(?:^|_)adaptive_(v[12])(?:_|$)")


def summary_paths(roots: Iterable[Path]) -> list[Path]:
    found: set[Path] = set()
    patterns = (
        "summary.json",
        "runs/*/summary.json",
        "*/runs/*/summary.json",
        "*/*/runs/*/summary.json",
    )
    for root in roots:
        if root.is_file():
            found.add(root.resolve())
            continue
        for pattern in patterns:
            found.update(path.resolve() for path in root.glob(pattern))
    return sorted(found)


def score_row(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    experiment_id = str(payload.get("experiment_id") or "")
    match = EXPERIMENT_RE.match(experiment_id)
    task = match.group(1) if match else path.parent.name
    seed = int(match.group(2)) if match else None
    final = (payload.get("final_evaluations") or {}).get("final") or {}
    decisions = payload.get("decisions") or []
    candidate_scores = [
        float(item["candidate_score"])
        for item in decisions
        if item.get("candidate_score") is not None
    ]
    protocol = None
    campaign: dict[str, Any] = {}
    for parent in path.parents:
        match_protocol = PROTOCOL_PATH_RE.search(parent.name)
        if match_protocol and protocol is None:
            protocol = match_protocol.group(1)
        campaign_summary = parent / "campaign_summary.json"
        if campaign_summary.is_file() and not campaign:
            campaign = json.loads(campaign_summary.read_text(encoding="utf-8"))
    protocol = campaign.get("objective_protocol") or protocol
    budget = campaign.get("budget") or {}
    return {
        "protocol": protocol,
        "rounds": budget.get("rounds"),
        "rollout_repeats": budget.get("rollout_repeats"),
        "task": task,
        "seed": seed,
        "final_objective_score": final.get("objective_score", final.get("score")),
        "final_mean_score": final.get("score"),
        "final_min_score": final.get("min_reward"),
        "final_max_score": final.get("max_reward"),
        "final_repeat_count": final.get("count"),
        "search_outcome_best_on_native_run_split": (
            max(candidate_scores) if candidate_scores else None
        ),
        "summary": str(path),
    }


def render_markdown(rows: list[dict[str, Any]]) -> str:
    headers = (
        "protocol",
        "rounds",
        "rollouts/candidate",
        "task",
        "seed",
        "final objective",
        "final mean",
        "final min",
        "final max",
        "repeats",
        "search-split best",
    )
    lines = [
        "| " + " | ".join(headers) + " |",
        "|" + "|".join("---" for _ in headers) + "|",
    ]
    keys = (
        "protocol",
        "rounds",
        "rollout_repeats",
        "task",
        "seed",
        "final_objective_score",
        "final_mean_score",
        "final_min_score",
        "final_max_score",
        "final_repeat_count",
        "search_outcome_best_on_native_run_split",
    )
    for row in rows:
        values = []
        for key in keys:
            value = row.get(key)
            if isinstance(value, float):
                values.append(f"{value:.12g}")
            else:
                values.append("—" if value is None else str(value))
        lines.append("| " + " | ".join(values) + " |")
    lines.extend(
        [
            "",
            "“search-split best” is a search diagnostic, not a canonical "
            "cross-split score. Compare methods only after the same official "
            "final rescore protocol. For AHC, the campaign final split is a "
            "30-case total; it is not the canonical all-150 rescore.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "roots",
        nargs="*",
        type=Path,
        default=[Path("evolve_harness/runs")],
        help="run root(s), summary.json file(s), or the parent runs directory",
    )
    parser.add_argument("--json", action="store_true", help="emit JSON")
    parser.add_argument("--output", type=Path, help="also write the report here")
    args = parser.parse_args()

    paths = summary_paths(args.roots)
    rows = [score_row(path) for path in paths]
    if not rows:
        parser.error("no Adaptive summary.json files found at the supplied paths")
    output = (
        json.dumps(rows, indent=2, ensure_ascii=False) + "\n"
        if args.json
        else render_markdown(rows)
    )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output, encoding="utf-8")
    print(output, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
