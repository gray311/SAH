from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from evogate.artifacts import ArtifactStore
from evogate.types import AgentState, Checkpoint

from evolve_harness.aime import evaluate_response, extract_answer
from evolve_harness.aime_staged import confirmed_archive, exclusive_json
from evogate.integrations.nexau import NexAUHarnessValidator
from evogate.integrations.workers.nexau_worker import _apply_overlay
from evolve_harness.evogate_open_ended import OpenEndedTaskSource
from evolve_harness.scripts.run_evogate_harnessopt_campaign import (
    CONFIG_ROOT,
    resolved_config,
    task_catalog,
)


def test_aime_answer_extraction_prefers_last_boxed_answer() -> None:
    assert extract_answer(r"First maybe \\boxed{12}, finally \\boxed{007}") == 7
    assert extract_answer("Therefore the final answer is 116.") == 116
    assert extract_answer("no numeric answer") is None
    assert extract_answer("I computed 123 but did not finalize it") is None


def test_aime_exact_match_accepts_leading_zero_format() -> None:
    result = evaluate_response(aime_id="aime-2022-i-01", response=r"\\boxed{116}")
    assert result["correct"] is True
    assert result["combined_score"] == 1.0


def test_thinking_toggle_passes_validator_and_worker_overlay() -> None:
    harness = {"llm": {"enable_thinking": True}, "skills": []}
    NexAUHarnessValidator({}).validate(
        baseline=None,
        candidate=None,
        proposal=None,
        components={"harness": harness},
    )
    llm = SimpleNamespace(
        model="fixture",
        base_url="http://fixture/v1",
        extra_params={
            "extra_body": {"chat_template_kwargs": {"enable_thinking": False}}
        },
    )
    config = SimpleNamespace(llm_config=llm)
    _apply_overlay(config, {}, harness, {})
    assert llm.extra_params["extra_body"]["chat_template_kwargs"] == {
        "enable_thinking": True
    }


def test_confirmed_archive_uses_comparable_two_role_scores(tmp_path) -> None:
    run_dir = tmp_path / "run"
    store = ArtifactStore(run_dir / "artifacts")
    model = store.put_json({"served_model": "fixture"}, kind="model")
    initial_harness = store.put_json({"system_prompt": "initial"}, kind="harness")
    initial = AgentState(components={"model": model, "harness": initial_harness})
    store.put_state(initial)
    candidate_harness = store.put_json({"system_prompt": "candidate"}, kind="harness")
    candidate = AgentState(
        components={"model": model, "harness": candidate_harness},
        parent_id=initial.state_id,
    )
    store.put_state(candidate)
    outcome = store.put_json(
        {
            "schema": "evogate.evaluation-summary/v1",
            "state_id": candidate.state_id,
            "split": "outcome",
            "score": 0.4,
        },
        kind="evaluation.summary",
    )
    promotion = store.put_json(
        {
            "schema": "evogate.evaluation-summary/v1",
            "state_id": candidate.state_id,
            "split": "promotion",
            "score": 0.6,
        },
        kind="evaluation.summary",
    )
    confirmed = Checkpoint(
        state_id=candidate.state_id,
        kind="candidate",
        label="candidate",
        evaluations={"outcome": outcome, "promotion": promotion},
        metadata={"proposal_id": "p0", "promotion_shortlisted": True},
    )
    store.put_checkpoint(confirmed)
    store.update_checkpoint_ref("rounds/000/candidates/000-p0", confirmed.checkpoint_id)
    (run_dir / "summary.json").write_text(
        json.dumps({"initial_state_id": initial.state_id}) + "\n",
        encoding="utf-8",
    )

    initial_row, archive = confirmed_archive(run_dir, 6)

    assert initial_row["state_id"] == initial.state_id
    assert len(archive) == 1
    assert archive[0]["screen_score"] == 0.4
    assert archive[0]["confirmation_score"] == 0.6
    assert archive[0]["two_seed_calibration_score"] == pytest.approx(0.5)


def test_exclusive_json_refuses_overwrite(tmp_path) -> None:
    path = tmp_path / "sealed.json"
    exclusive_json(path, {"value": 1})
    with pytest.raises(FileExistsError):
        exclusive_json(path, {"value": 2})
    assert json.loads(path.read_text()) == {"value": 1}


def test_task_source_honors_row_split_membership_and_unique_ids(tmp_path) -> None:
    task_file = tmp_path / "aime.jsonl"
    rows = [
        {
            "id": "aime-dev-01",
            "input": "dev",
            "metadata": {
                "official_task_id": "aime2024",
                "evaluator_kind": "aime_exact_match",
                "evogate_splits": ["update", "outcome"],
            },
        },
        {
            "id": "aime-final-01",
            "input": "final",
            "metadata": {
                "official_task_id": "aime2024",
                "evaluator_kind": "aime_exact_match",
                "evogate_splits": ["final"],
            },
        },
    ]
    task_file.write_text("".join(json.dumps(row) + "\n" for row in rows))
    source = OpenEndedTaskSource(
        [task_file], base_dir=tmp_path, project_root=tmp_path
    )

    assert [case.task_id for case in source.cases("update")] == [
        "aime2024:aime-dev-01:update"
    ]
    assert [case.task_id for case in source.cases("outcome")] == [
        "aime2024:aime-dev-01:outcome"
    ]
    assert source.cases("promotion") == ()
    assert [case.task_id for case in source.cases("final")] == [
        "aime2024:aime-final-01:final"
    ]


def test_aime_config_scales_episode_budget_by_questions(tmp_path) -> None:
    catalog = task_catalog()
    config = resolved_config(
        template_path=CONFIG_ROOT / "ahc039.json",
        task_id="aime2024",
        task=catalog["aime2024"],
        run_root=tmp_path,
        base_url="http://127.0.0.1:18140/v1",
        served_model="Qwen3.5-4B-Base",
        checkpoint="/data/models/Qwen3.5-4B",
        rounds=2,
        proposals=4,
        allow_unsplit=False,
        rollout_repeats=1,
        feedback_repeats=1,
        method_arm="context_only",
        inner_max_tokens=6144,
        proposer_max_tokens=3072,
        objective_protocol="v2",
        promotion_top_k=2,
    )

    assert config["budgets"]["inner"]["episodes"] == 750
    assert config["metadata"]["budget_derivation"]["task_case_multiplier"] == 30
    assert config["initial_components"]["harness"]["max_iterations"] == 2
    assert config["evaluation"]["outcome_statistic"] == "mean"
    assert config["evaluation"]["promotion_statistic"] == "mean"
    assert config["evaluation"]["final_statistic"] == "mean"
    assert config["plugins"]["config"]["optimizer"]["policy_evolution"][
        "mode"
    ] == "context_only"
    assert "/llm/enable_thinking" not in config["capabilities"]["harness"]["paths"]


def test_aime_agent_disables_hidden_generation_retries() -> None:
    config = json.loads(
        (CONFIG_ROOT / "aime_agent.yaml").read_text(encoding="utf-8")
    )
    assert config["retry_attempts"] == 1
    assert config["llm_config"]["extra_body"]["chat_template_kwargs"][
        "enable_thinking"
    ] is False
