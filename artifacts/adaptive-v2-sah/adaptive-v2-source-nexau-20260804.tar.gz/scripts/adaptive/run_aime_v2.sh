#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -lt 1 || "$#" -gt 4 ]]; then
  echo "usage: $0 SERVING_GPU [SEED [ROUNDS [PORT]]]" >&2
  exit 2
fi

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
source "$ROOT/scripts/adaptive/protocol.sh"
SERVING_GPU=$1
SEED=${2:-23}
ROUNDS=${3:-1}
PORT=${4:-18140}

load_adaptive_protocol v2
# AIME v2 is a frozen-weight, context-only arm. Each logical evaluation
# already averages independent exact-match cases, so it uses one trajectory
# per question rather than four repeats of one continuous objective.
METHOD_ARM=context_only
ROLLOUT_REPEATS=1
FEEDBACK_REPEATS=1
PROMOTION_TOP_K=2
export METHOD_ARM ROLLOUT_REPEATS FEEDBACK_REPEATS PROMOTION_TOP_K

if [[ ! "$SERVING_GPU" =~ ^[0-9]+$ ]] ||
   [[ ! "$SEED" =~ ^[0-9]+$ ]] ||
   [[ ! "$ROUNDS" =~ ^[1-9][0-9]*$ ]] ||
   [[ ! "$PORT" =~ ^[0-9]+$ ]]; then
  echo "GPU, seed, rounds, and port must be numeric" >&2
  exit 3
fi

CAMPAIGN_PYTHON=${CAMPAIGN_PYTHON:-"$ROOT/.venv-nexau/bin/python"}
if [[ -z "${VLLM_PYTHON:-}" ]]; then
  if [[ -x "$ROOT/.venv-adaptive-vllm/bin/python" ]]; then
    VLLM_PYTHON="$ROOT/.venv-adaptive-vllm/bin/python"
  else
    VLLM_PYTHON=/home/nli61/.conda/envs/vllm-serve/bin/python
  fi
fi
if [[ ! -x "$CAMPAIGN_PYTHON" ]] || [[ ! -x "$VLLM_PYTHON" ]]; then
  echo "Adaptive environments are missing; run: ./adaptive.sh setup core" >&2
  exit 4
fi
if [[ ! -f "$ROOT/evolve_harness/configs/benchmarks/harness_only_aime2024_pilot.jsonl" ]] ||
   [[ ! -f "$ROOT/evolve_harness/configs/benchmarks/verifier/aime_2022_2024_answers.json" ]]; then
  echo "AIME manifests are missing; run prepare_aime_benchmark.py" >&2
  exit 4
fi

STAMP=$(date +%Y%m%dT%H%M%S)
RUN_ROOT=${RUN_ROOT:-"$ROOT/evolve_harness/runs/adaptive_v2_context_only_aime2024_seed${SEED}_r${ROUNDS}_${STAMP}"}
SERVICE_DIR=${SERVICE_DIR:-"$RUN_ROOT/vllm_service"}
export MODEL_PATH=${MODEL_PATH:-/data/models/Qwen3.5-4B}
export SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-Qwen3.5-4B-Base}
export CAMPAIGN_PYTHON VLLM_PYTHON

cat <<EOF
Adaptive v2 AIME context-only pilot
run root:        $RUN_ROOT
serving GPU:     $SERVING_GPU
training GPU:    none (weights frozen)
model:           $MODEL_PATH
served name:     $SERVED_MODEL_NAME
seed/rounds:     $SEED/$ROUNDS
questions:       AIME 2022 dev, 2023 promotion, 2024 final
EOF

exec "$ROOT/evolve_harness/scripts/run_evogate_adaptive_task_managed.sh" \
  aime2024-pilot "$SERVING_GPU" none "$PORT" \
  "$RUN_ROOT" "$SERVICE_DIR" "$SEED" "$ROUNDS"
