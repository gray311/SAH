#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -lt 1 || "$#" -gt 4 ]]; then
  echo "usage: $0 SERVING_GPU [SEED [ROUNDS [PORT]]]" >&2
  exit 2
fi

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
source "$ROOT/scripts/adaptive/protocol.sh"
SERVING_GPU=$1
SEED=${2:-23}
ROUNDS=${3:-5}
PORT=${4:-18140}

load_adaptive_protocol v2
METHOD_ARM=context_only
ROLLOUT_REPEATS=1
FEEDBACK_REPEATS=1
PROPOSALS=6
PROMOTION_TOP_K=3
INNER_MAX_TOKENS=8192
PROPOSER_MAX_TOKENS=4096
AIME_STAGED_EVAL=1
export METHOD_ARM ROLLOUT_REPEATS FEEDBACK_REPEATS PROPOSALS
export PROMOTION_TOP_K INNER_MAX_TOKENS PROPOSER_MAX_TOKENS
export AIME_STAGED_EVAL

if [[ ! "$SERVING_GPU" =~ ^[0-9]+$ ]] ||
   [[ ! "$SEED" =~ ^[0-9]+$ ]] ||
   [[ ! "$ROUNDS" =~ ^[1-9][0-9]*$ ]] ||
   [[ ! "$PORT" =~ ^[0-9]+$ ]]; then
  echo "GPU, seed, rounds, and port must be numeric" >&2
  exit 3
fi

CAMPAIGN_PYTHON=${CAMPAIGN_PYTHON:-"$ROOT/.venv-nexau/bin/python"}
if [[ -z "${VLLM_PYTHON:-}" ]]; then
  if [[ -x "$ROOT/.venv-adaptive-vllm/bin/python" ]]; then
    VLLM_PYTHON="$ROOT/.venv-adaptive-vllm/bin/python"
  else
    VLLM_PYTHON=/home/nli61/.conda/envs/vllm-serve/bin/python
  fi
fi
STAMP=$(date +%Y%m%dT%H%M%S)
RUN_ROOT=${RUN_ROOT:-"$ROOT/evolve_harness/runs/adaptive_v2_aime_scaleup_seed${SEED}_r${ROUNDS}_${STAMP}"}
SERVICE_DIR=${SERVICE_DIR:-"$RUN_ROOT/vllm_service"}
export MODEL_PATH=${MODEL_PATH:-/data/models/Qwen3.5-4B}
export SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-Qwen3.5-4B-Base}
export CAMPAIGN_PYTHON VLLM_PYTHON

echo "Adaptive v2 AIME frozen-weight harness-only scale-up"
echo "run root: $RUN_ROOT"
echo "GPU/seed/rounds: $SERVING_GPU/$SEED/$ROUNDS"
echo "search: 2022; select: 2023; final: 2025; 2024 excluded"

exec "$ROOT/evolve_harness/scripts/run_evogate_adaptive_task_managed.sh" \
  aime-harness-search "$SERVING_GPU" none "$PORT" \
  "$RUN_ROOT" "$SERVICE_DIR" "$SEED" "$ROUNDS"
